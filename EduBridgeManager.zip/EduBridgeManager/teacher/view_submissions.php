<?php
// teacher/view_submissions.php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();

// 1) Core includes
define('BASE_PATH', __DIR__ . '/..');
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db_config.php';
require_once __DIR__ . '/../includes/functions.php';


// 2) Must be logged in as teacher
if (!isLoggedIn() || $_SESSION['user_type'] !== 'teacher') {
    header('Location: ../login.php');
    exit;
}

// 3) Get and validate post_id from query
$post_id = isset($_GET['post_id']) ? intval($_GET['post_id']) : 0;
if ($post_id <= 0) {
    header('Location: dashboard.php');
    exit;
}

// 4) Fetch post details
$post = getPostDetails($post_id); // implement in functions.php
if (!$post || $post['post_type'] !== 'assignment') {
    header('Location: dashboard.php');
    exit;
}

// 5) Verify teacher access to this class
if (!verifyClassAccess($post['class_id'], $_SESSION['user_id'], 'teacher')) {
    header('Location: dashboard.php');
    exit;
}

// 6) Fetch submissions for this assignment
$submissions = getAssignmentSubmissions($post_id); // implement this in includes/functions.php

// 7) Render page
include BASE_PATH . '/includes/header.php';
include BASE_PATH . '/includes/teacher_sidebar.php';
?>

<div class="container mt-4">
    <h2>Submissions for: <?= htmlspecialchars($post['title']) ?></h2>
    <?php if (empty($submissions)): ?>
        <p>No submissions yet.</p>
    <?php else: ?>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Student</th>
                    <th>Submission</th>
                    <th>Submitted At</th>
                    <th>Grade</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($submissions as $s): ?>
                <tr>
                    <td><?= htmlspecialchars(getUserName($s['student_id'], 'student')) ?></td>
                    <td>
                        <?php if (!empty($s['file_path'])): ?>
                            <a href="/<?= htmlspecialchars($s['file_path']) ?>" download>Download File</a>
                        <?php else: ?>
                            <?= nl2br(htmlspecialchars($s['content'])) ?>
                        <?php endif; ?>
                    </td>
                    <td><?= htmlspecialchars($s['submitted_at']) ?></td>
                    <td>
                        <form method="post" action="grade_submission.php" class="d-inline">
                            <input type="hidden" name="submission_id" value="<?= intval($s['id']) ?>">
                            <input type="number" name="marks_obtained" min="0" max="<?= intval($post['total_marks']) ?>"
                                   value="<?= htmlspecialchars($s['marks_obtained']) ?>" required style="width:80px;">
                            <button type="submit" class="btn btn-sm btn-primary">Save</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
