<?php
session_start();
require_once('../includes/db_config.php');
require_once('../includes/functions.php');
require_once('../includes/auth.php');

requireTeacher();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pdo = getDbConnection();

    $submissionId = intval($_POST['submission_id']);
    $marksObtained = floatval($_POST['marks_obtained']);
    $feedback = sanitize($_POST['feedback']);

    $stmt = $pdo->prepare("
        UPDATE assignment_submissions
        SET marks_obtained = :marks_obtained, feedback = :feedback
        WHERE id = :submission_id
    ");
    $stmt->execute([
        'marks_obtained' => $marksObtained,
        'feedback' => $feedback,
        'submission_id' => $submissionId
    ]);

    redirect('dashboard.php'); // After grading, go to teacher dashboard or back to stream
}
?>
