<?php
// teacher/people.php
session_start();

// 1) Core includes (header.php brings in your <head> + style.css)
include __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db_config.php';
require_once __DIR__ . '/../includes/functions.php';

// 2) Only teachers may view
requireTeacher();

// 3) Fetch this teacher’s classes & determine selected class
$teacherId       = $_SESSION['user_id'];
$teacherClasses  = getTeacherClasses($teacherId);
$selectedClassId = isset($_GET['class_id'])
    ? intval($_GET['class_id'])
    : (!empty($teacherClasses) ? $teacherClasses[0]['id'] : null);

// 4) Access check
if ($selectedClassId && !isTeacherClass($selectedClassId, $teacherId)) {
    $_SESSION['error'] = "Access Denied.";
    redirect('../dashboard.php');
}

// 5) Load class details and enrolled students
$classDetails = $selectedClassId
    ? getClassDetails($selectedClassId)
    : null;
$students = $selectedClassId
    ? getClassStudents($selectedClassId)
    : [];

// 6) Render sidebar + main layout
include __DIR__ . '/../includes/teacher_sidebar.php';
?>
<div class="container-fluid">
  <div class="row justify-content-center">
    <main class="col-lg-8 col-md-10 px-4">
      <div class="content-wrapper">

        <!-- class‐level nav -->
        <?php include __DIR__ . '/../includes/class_nav.php'; ?>

        <h2 class="section-title">
          <?= htmlspecialchars($classDetails['class_name'] ?? 'People') ?> — People
        </h2>

        <?php if (empty($teacherClasses)): ?>
          <div class="empty-state">No classes assigned.</div>
        <?php else: ?>

          <!-- Class selector -->
          <form method="get" action="people.php" class="mb-4">
            <label for="class_id">Select Class:</label>
            <select
              id="class_id"
              name="class_id"
              class="form-control"
              onchange="this.form.submit()"
            >
              <?php foreach ($teacherClasses as $c): ?>
                <option
                  value="<?= $c['id'] ?>"
                  <?= $c['id'] === $selectedClassId ? 'selected' : '' ?>
                >
                  <?= htmlspecialchars($c['class_name']) ?>
                </option>
              <?php endforeach; ?>
            </select>
          </form>

          <?php if ($classDetails): ?>

            <div class="class-meta mb-4">
              <h3><?= htmlspecialchars($classDetails['class_name']) ?></h3>
            </div>

            <!-- Teacher Info -->
            <h3>Teacher</h3>
            <div class="card-container mb-5">
              <div class="card post-card">
                <p><?= htmlspecialchars(
                      $classDetails['first_name'] . ' ' . $classDetails['last_name']
                    ) ?></p>
              </div>
            </div>

            <!-- Students List -->
            <h3>Students</h3>
            <?php if (empty($students)): ?>
              <div class="empty-state">No students enrolled yet.</div>
            <?php else: ?>
              <div class="card-container">
                <?php foreach ($students as $s): ?>
                  <div class="card post-card">
                    <p><?= htmlspecialchars($s['first_name'] . ' ' . $s['last_name']) ?></p>
                    <p class="text-light"><?= htmlspecialchars($s['email']) ?></p>
                  </div>
                <?php endforeach; ?>
              </div>
            <?php endif; ?>

          <?php endif; ?>
        <?php endif; ?>

      </div><!-- /.content-wrapper -->
    </main>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
