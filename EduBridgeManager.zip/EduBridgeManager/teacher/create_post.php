<?php
session_start();
require_once('../includes/db_config.php');
require_once('../includes/functions.php');
require_once('../includes/auth.php');
require_once '../includes/stream_posts.php';
requireTeacher();

$teacherId = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pdo = getDbConnection();

    $classId = intval($_POST['class_id']);
    $postType = sanitize($_POST['post_type']);
    $title = sanitize($_POST['title']);
    $content = sanitize($_POST['content']);
    $dueDate = !empty($_POST['due_date']) ? $_POST['due_date'] : null;
    $filePath = null;

    // Handle file upload (for materials)
    if ($postType === 'material' && isset($_FILES['material_file']) && $_FILES['material_file']['error'] == 0) {
        $uploadsDir = '../uploads/materials/';
        if (!is_dir($uploadsDir)) {
            mkdir($uploadsDir, 0777, true);
        }
        $fileName = time() . '_' . basename($_FILES['material_file']['name']);
        move_uploaded_file($_FILES['material_file']['tmp_name'], $uploadsDir . $fileName);
        $content .= "\n[Download Material](/uploads/materials/{$fileName})";
    }

    $stmt = $pdo->prepare("
        INSERT INTO stream_posts (class_id, user_id, user_type, post_type, title, content, due_date)
        VALUES (:class_id, :user_id, 'teacher', :post_type, :title, :content, :due_date)
    ");
    $stmt->execute([
        'class_id' => $classId,
        'user_id' => $teacherId,
        'post_type' => $postType,
        'title' => $title,
        'content' => $content,
        'due_date' => $dueDate
    ]);

    redirect('stream.php?class_id=' . $classId);
}
?>

<!-- Simple Create Post Form -->
<?php require_once('../includes/header.php'); ?>
<?php require_once('../includes/teacher_sidebar.php'); ?>

<div class="dashboard-content">
    <main class="main-content">
        <h2>Create Post</h2>
        <form method="post" enctype="multipart/form-data">
            <input type="hidden" name="class_id" value="<?= intval($_GET['class_id']) ?>">

            <label>Post Type:</label>
            <select name="post_type" id="post_type" onchange="toggleMaterialUpload()" required>
                <option value="announcement">Announcement</option>
                <option value="assignment">Assignment</option>
                <option value="material">Material</option>
                <option value="question">Question</option>
            </select>

            <label>Title:</label>
            <input type="text" name="title" required>

            <label>Content:</label>
            <textarea name="content" required></textarea>

            <div id="dueDateField" style="display: none;">
                <label>Due Date:</label>
                <input type="datetime-local" name="due_date">
            </div>

            <div id="materialUploadField" style="display: none;">
                <label>Upload Material File:</label>
                <input type="file" name="material_file">
            </div>

            <button type="submit">Post</button>
        </form>
    </main>
</div>

<script>
function toggleMaterialUpload() {
    var postType = document.getElementById('post_type').value;
    document.getElementById('dueDateField').style.display = (postType === 'assignment') ? 'block' : 'none';
    document.getElementById('materialUploadField').style.display = (postType === 'material') ? 'block' : 'none';
}
</script>

<?php require_once('../includes/footer.php'); ?>
