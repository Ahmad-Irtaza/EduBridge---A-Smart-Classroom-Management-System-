<?php
session_start();
require_once('../includes/db_config.php');
require_once('../includes/functions.php');
require_once('../includes/auth.php');
require_once '../includes/stream_posts.php';
$userId = $_SESSION['user_id'];
$userType = strpos($_SERVER['PHP_SELF'], 'teacher') !== false ? 'teacher' : 'student';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pdo = getDbConnection();
    $postId = intval($_POST['post_id']);
    $comment = sanitize($_POST['comment']);

    $stmt = $pdo->prepare("
        INSERT INTO stream_comments (post_id, user_id, user_type, comment)
        VALUES (:post_id, :user_id, :user_type, :comment)
    ");
    $stmt->execute([
        'post_id' => $postId,
        'user_id' => $userId,
        'user_type' => $userType,
        'comment' => $comment
    ]);

    redirect('stream.php?class_id=' . intval($_GET['class_id']));
}

// If accessed directly
if (isset($_GET['post_id'])):
?>

<form method="post">
    <input type="hidden" name="post_id" value="<?= intval($_GET['post_id']) ?>">
    <textarea name="comment" required placeholder="Write your comment here..."></textarea>
    <button type="submit">Post Comment</button>
</form>

<?php endif; ?>
