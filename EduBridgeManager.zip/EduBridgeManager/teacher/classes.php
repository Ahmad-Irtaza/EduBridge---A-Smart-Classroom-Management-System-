<?php
session_start();
require_once('../includes/db_config.php');
require_once('../includes/functions.php');
require_once('../includes/auth.php');

// Check if user is logged in and is a teacher
if (!isLoggedIn() || $_SESSION['user_type'] !== 'teacher') {
    redirect('../login.php?type=teacher');
}

// Get teacher information
$teacherId = $_SESSION['user_id'];
$teacherName = isset($_SESSION['user_name']) ? $_SESSION['user_name'] : '';

// Get complete teacher information
$teacherInfo = getCurrentUserInfo();
if (!empty($teacherInfo)) {
    $teacherName = $teacherInfo['first_name'] . ' ' . $teacherInfo['last_name'];
}

// Get PDO connection
$pdo = getDbConnection();

// Process class creation
$success = $error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action']) && $_POST['action'] === 'create_class') {
        $className = sanitize($_POST['class_name']);
        $description = sanitize($_POST['description']);
        
        if (empty($className)) {
            $error = "Class name cannot be empty.";
        } else {
            try {
                // Generate a unique class code
                $classCode = generateClassCode();
                $codeExists = true;
                
                // Keep generating until we get a unique code
                while ($codeExists) {
                    $stmt = $pdo->prepare("SELECT id FROM classes WHERE class_code = :class_code");
                    $stmt->execute(['class_code' => $classCode]);
                    
                    if ($stmt->rowCount() === 0) {
                        $codeExists = false;
                    } else {
                        $classCode = generateClassCode();
                    }
                }
                
                // Insert the new class
                $stmt = $pdo->prepare("
                    INSERT INTO classes (class_name, class_code, description, teacher_id)
                    VALUES (:class_name, :class_code, :description, :teacher_id)
                ");
                
                $stmt->execute([
                    'class_name' => $className,
                    'class_code' => $classCode,
                    'description' => $description,
                    'teacher_id' => $teacherId
                ]);
                
                $success = "Class created successfully. Class code: {$classCode}";
            } catch (PDOException $e) {
                $error = "Database error: " . $e->getMessage();
            }
        }
    }
}

// Get teacher's classes
$classes = [];
try {
    $stmt = $pdo->prepare("
        SELECT c.*, 
               (SELECT COUNT(*) FROM class_enrollments WHERE class_id = c.id) AS student_count,
               (SELECT COUNT(*) FROM stream_posts WHERE class_id = c.id) AS post_count,
               MAX(sp.created_at) AS last_activity
        FROM classes c
        LEFT JOIN stream_posts sp ON c.id = sp.class_id
        WHERE c.teacher_id = :teacher_id
        GROUP BY c.id
        ORDER BY c.class_name
    ");
    $stmt->execute(['teacher_id' => $teacherId]);
    $classes = $stmt->fetchAll();
} catch (PDOException $e) {
    $error = "Database error: " . $e->getMessage();
}
include __DIR__ . '/../includes/header.php';

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Classes - EduBridge</title>
    <link rel="stylesheet" href="../css/style.css">
    <script src="../js/main.js" defer></script>
    
    <style>
        /* Initially hide the modal */
        #create-class-form {
            display: none;
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <?php include('../includes/teacher_sidebar.php'); ?>
        
        <main class="dashboard-content">
            <header class="dashboard-header">
                <div class="header-info">
                    <h1>My Classes</h1>
                    <p>Manage your classes and streams</p>
                </div>
                </header>
                <!-- <div class="header-actions">
                    <div class="date-display"><?php echo date('l, F j, Y'); ?></div>
                    <div class="user-profile">
                        <img src="../images/avatars/teacher.png" alt="Profile" class="avatar">
                        <div class="dropdown">
                            <span class="dropdown-toggle"><?php echo htmlspecialchars($teacherName); ?></span>
                            <div class="dropdown-menu">
                                <a href="profile.php">My Profile</a>
                                <a href="../logout.php">Logout</a>
                            </div>
                        </div>
                    </div>
                </div>
             -->
            
            <div class="main-content">
                <?php if ($success): ?>
                    <div class="success-message"><?php echo $success; ?></div>
                <?php endif; ?>
                
                <?php if ($error): ?>
                    <div class="error-message"><?php echo $error; ?></div>
                <?php endif; ?>
                
                <div class="actions-bar">
                    <button id="create-class-btn" class="btn-primary">Create New Class</button>
                </div>
                
                <!-- The Create Class Modal Form -->
                <div id="create-class-form" class="modal">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h3 class="modal-title">Create New Class</h3>
                            <span class="close-modal">&times;</span>
                        </div>
                        <div class="modal-body">
                            <form action="classes.php" method="POST">
                                <input type="hidden" name="action" value="create_class">
                                
                                <div class="form-group">
                                    <label for="class_name">Class Name</label>
                                    <input type="text" id="class_name" name="class_name" required>
                                </div>
                                
                                <div class="form-group">
                                    <label for="description">Description (Optional)</label>
                                    <textarea id="description" name="description" rows="3"></textarea>
                                </div>
                                
                                <div class="form-actions">
                                    <button type="submit" class="btn-primary">Create Class</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                
                <h2 class="section-title">Your Classes</h2>
                
                <?php if (empty($classes)): ?>
                    <div class="empty-state">
                        <p>You haven't created any classes yet.</p>
                        <p>Use the "Create New Class" button to get started.</p>
                    </div>
                <?php else: ?>
                    <div class="class-cards">
                        <?php foreach ($classes as $class): ?>
                            <div class="class-card">
                                <div class="class-header">
                                    <h3><?php echo htmlspecialchars($class['class_name']); ?></h3>
                                    <div class="class-code">Code: <?php echo htmlspecialchars($class['class_code']); ?></div>
                                </div>
                                <div class="class-body">
                                    <?php if (!empty($class['description'])): ?>
                                        <p class="class-description"><?php echo htmlspecialchars($class['description']); ?></p>
                                    <?php endif; ?>
                                    <div class="class-stats">
                                        <span class="student-count"><?php echo $class['student_count']; ?> students</span>
                                        <span class="post-count"><?php echo $class['post_count']; ?> posts</span>
                                        <span class="activity-date">
                                            <?php 
                                            if ($class['last_activity']) {
                                                echo 'Last activity: ' . date('M j, Y', strtotime($class['last_activity']));
                                            } else {
                                                echo 'No activity yet';
                                            }
                                            ?>
                                        </span>
                                    </div>
                                    <div class="class-actions">
                                        <a href="stream.php?class_id=<?php echo $class['id']; ?>" class="class-btn">Open Stream</a>
                                        <a href="roster.php?class_id=<?php echo $class['id']; ?>" class="class-btn">Student Roster</a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </main>
    </div>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Modal functionality
            const modal = document.getElementById('create-class-form');
            const btn = document.getElementById('create-class-btn');
            const closeBtn = document.querySelector('.close-modal');
            
            btn.addEventListener('click', () => {
                modal.style.display = 'block';
            });
            
            closeBtn.addEventListener('click', () => {
                modal.style.display = 'none';
            });
            
            window.addEventListener('click', (e) => {
                if (e.target === modal) {
                    modal.style.display = 'none';
                }
            });
        });
    </script>
</body>
</html>
