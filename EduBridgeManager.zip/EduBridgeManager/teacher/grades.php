<?php
// teacher/grades.php
session_start();

// Core includes
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db_config.php';
require_once __DIR__ . '/../includes/functions.php';
requireTeacher();

// Teacher’s classes & selected
$teacherId       = $_SESSION['user_id'];
$teacherClasses  = getTeacherClasses($teacherId);
$selectedClassId = isset($_GET['class_id'])
    ? intval($_GET['class_id'])
    : (!empty($teacherClasses) ? $teacherClasses[0]['id'] : null);

// Access check
if($selectedClassId && !isTeacherClass($selectedClassId,$teacherId)){
    $_SESSION['error']="Access Denied.";
    redirect('../dashboard.php');
}

// Details & assignments
$classDetails = $selectedClassId ? getClassDetails($selectedClassId) : null;
$pdo = getDbConnection();
$stmt = $pdo->prepare("
  SELECT * FROM stream_posts
  WHERE class_id=:cid AND post_type='assignment'
  ORDER BY created_at DESC
");
$stmt->execute(['cid'=>$selectedClassId]);
$assignments = $stmt->fetchAll(PDO::FETCH_ASSOC);
// Students
$students = $selectedClassId ? getClassStudents($selectedClassId) : [];
// Build grades matrix
$grades = [];
foreach($students as $s){
  foreach($assignments as $a){
    $q = $pdo->prepare("
      SELECT marks_obtained,total_marks
      FROM assignment_submissions
      WHERE post_id=:pid AND student_id=:sid
    ");
    $q->execute(['pid'=>$a['id'],'sid'=>$s['id']]);
    $r=$q->fetch(PDO::FETCH_ASSOC);
    $grades[$s['id']][$a['id']] = $r
      ? "{$r['marks_obtained']}/{$r['total_marks']}"
      : '–';
  }
}

// Render
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/teacher_sidebar.php';
?>
<div class="container-fluid">
  <div class="row">
    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">

      <?php include __DIR__ . '/../includes/class_nav.php'; ?>

      <h2 class="section-title">
        <?= htmlspecialchars($classDetails['class_name'] ?? 'Grades') ?> — Grades
      </h2>

      <?php if(empty($teacherClasses)): ?>
        <div class="empty-state">No classes assigned.</div>
      <?php else: ?>
        <!-- Class selector -->
        <form method="get" action="grades.php" class="mb-4">
          <label for="class_id">Select Class:</label>
          <select id="class_id" name="class_id" onchange="this.form.submit()">
            <?php foreach($teacherClasses as $c): ?>
              <option value="<?= $c['id'] ?>"
                <?= $c['id']===$selectedClassId?'selected':'' ?>>
                <?= htmlspecialchars($c['class_name']) ?>
              </option>
            <?php endforeach; ?>
          </select>
        </form>

        <!-- Horizontal assignments ribbon -->
        <div class="grades-grid mb-4">
          <?php foreach($assignments as $a): ?>
            <div class="grade-card">
              <h4><?= htmlspecialchars($a['title']) ?></h4>
              <small>
                <?= empty($a['due_date'])?'No due date':htmlspecialchars($a['due_date']) ?>
              </small>
              <?php if(!empty($a['total_marks'])): ?>
                <p>Out of <?= htmlspecialchars($a['total_marks']) ?></p>
              <?php endif; ?>
            </div>
          <?php endforeach; ?>
        </div>

        <!-- Grades table -->
        <table class="grades-table">
          <thead>
            <tr>
              <th>Student</th>
              <?php foreach($assignments as $a): ?>
                <th><?= htmlspecialchars($a['title']) ?></th>
              <?php endforeach; ?>
            </tr>
          </thead>
          <tbody>
            <?php foreach($students as $s): ?>
              <tr>
                <td><?= htmlspecialchars($s['first_name'].' '.$s['last_name']) ?></td>
                <?php foreach($assignments as $a): ?>
                  <td><?= htmlspecialchars($grades[$s['id']][$a['id']] ?? '–') ?></td>
                <?php endforeach; ?>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      <?php endif; ?>

    </main>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
