<?php
// teacher/classwork.php
session_start();

// Core includes
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db_config.php';
require_once __DIR__ . '/../includes/functions.php';
requireTeacher();

// 1) Teacher’s classes & selected class
$teacherId       = $_SESSION['user_id'];
$teacherClasses  = getTeacherClasses($teacherId);
$selectedClassId = isset($_GET['class_id'])
    ? intval($_GET['class_id'])
    : (!empty($teacherClasses) ? $teacherClasses[0]['id'] : null);

// 2) Access check
if ($selectedClassId && !isTeacherClass($selectedClassId, $teacherId)) {
    $_SESSION['error']="Access Denied.";
    redirect('../dashboard.php');
}

// 3) Load details & posts
$classDetails = $selectedClassId ? getClassDetails($selectedClassId) : null;
$posts        = $selectedClassId ? getClassStreamPosts($selectedClassId) : [];

// 4) Render
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/teacher_sidebar.php';

?>
<div class="container-fluid">
  <div class="row">
    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">

      <?php include __DIR__ . '/../includes/class_nav.php'; ?>

      <h2 class="section-title">
        <?= htmlspecialchars($classDetails['class_name'] ?? 'Classwork') ?> — Classwork
      </h2>

      <?php if (empty($teacherClasses)): ?>
        <div class="empty-state">No classes assigned.</div>
      <?php else: ?>

        <!-- Class selector -->
        <form method="get" action="classwork.php" class="mb-4">
          <label for="class_id">Select Class:</label>
          <select id="class_id" name="class_id" onchange="this.form.submit()">
            <?php foreach($teacherClasses as $c): ?>
              <option value="<?= $c['id'] ?>"
                <?= $c['id']===$selectedClassId?'selected':'' ?>>
                <?= htmlspecialchars($c['class_name']) ?>
              </option>
            <?php endforeach; ?>
          </select>
        </form>

        <?php if ($classDetails): ?>
          <div class="class-meta mb-4">
            <h3><?= htmlspecialchars($classDetails['class_name']) ?></h3>
          </div>

          <!-- Assignments -->
          <div class="section-title">Assignments</div>
          <div class="card-container">
            <?php
            $hasA=false;
            foreach($posts as $post):
              if($post['post_type']!=='assignment') continue;
              $hasA=true;
            ?>
              <div class="card post-card">
                <h4><?= htmlspecialchars($post['title']) ?></h4>
                <p><?= nl2br(htmlspecialchars($post['content'])) ?></p>
                <?php if(!empty($post['due_date'])): ?>
                  <p><strong>Due:</strong> <?= htmlspecialchars($post['due_date']) ?></p>
                <?php endif; ?>
                <a href="view_submissions.php?post_id=<?= $post['id'] ?>"
                   class="btn-secondary">
                  View Submissions
                </a>
              </div>
            <?php endforeach; ?>
            <?php if(!$hasA): ?>
              <div class="empty-state">No assignments yet.</div>
            <?php endif; ?>
          </div>

          <!-- Materials -->
          <div class="section-title">Study Materials</div>
          <div class="card-container">
            <?php
            $hasM=false;
            foreach($posts as $post):
              if($post['post_type']!=='material') continue;
              $hasM=true;
            ?>
              <div class="card post-card">
                <h4><?= htmlspecialchars($post['title']) ?></h4>
                <p><?= nl2br(htmlspecialchars($post['content'])) ?></p>
                <?php if(!empty($post['file_path'])): ?>
                  <a href="<?= htmlspecialchars($post['file_path']) ?>" class="material-download">
                    View Material
                  </a>
                <?php endif; ?>
              </div>
            <?php endforeach; ?>
            <?php if(!$hasM): ?>
              <div class="empty-state">No materials yet.</div>
            <?php endif; ?>
          </div>
        <?php endif; ?>

      <?php endif; ?>

    </main>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
