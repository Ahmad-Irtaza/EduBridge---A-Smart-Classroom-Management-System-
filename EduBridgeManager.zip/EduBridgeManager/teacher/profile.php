<?php
session_start();
require_once('../includes/db_config.php');
require_once('../includes/functions.php');
require_once('../includes/auth.php');

// Ensure only logged-in teachers can access
if (!isLoggedIn() || $_SESSION['user_type'] !== 'teacher') {
    redirect('../login.php?type=teacher');
}

// Retrieve current teacher ID from session
$teacherId = $_SESSION['user_id'];

// Attempt to fetch teacher record from database
$pdo    = getDbConnection();
$teacher = null;
$error   = '';

try {
    $stmt = $pdo->prepare("SELECT * FROM teachers WHERE id = :id");
    $stmt->execute(['id' => $teacherId]);
    $teacher = $stmt->fetch();
} catch (PDOException $e) {
    $error = "Database error: " . $e->getMessage();
}

// If no teacher record is found, set an error
if (!$teacher && empty($error)) {
    $error = "No teacher record found for your account.";
}

// Construct teacher’s display name
$teacherName = $teacher ? $teacher['first_name'] . ' ' . $teacher['last_name'] : '';

include __DIR__ . '/../includes/header.php';

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile - EduBridge</title>
    <link rel="stylesheet" href="../css/style.css">
    <!-- Inline CSS for profile layout using flex for three columns -->
    <style>
        /* Header overrides */
        .dashboard-header h1 {
            color: #ADD8E6; /* Light Blue */
        }

        /* Global resets remain in effect from your global CSS if any */

        /* Dashboard Layout modifications: profile card details */
        .profile-details {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
        }
        
        /* Each column occupies an equal share */
        .profile-column {
            flex: 1;
            min-width: 280px;
            background-color:rgb(167, 159, 188);  /* Light gray container */
            padding: 15px;
            border: 1px solid #dee2e6;
            border-radius: 6px;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
        }
        
        .profile-column h3 {
            font-size: 18px;
            margin-bottom: 10px;
            color: #2563EB;  /* Light blue for section headings */
        }
        
        .profile-column p {
            font-size: 14px;
            margin-bottom: 6px;
            color:rgb(11, 11, 11);
        }
        
        .profile-column p strong {
            color: #212529;
        }
    </style>
    <!-- Optional scripts -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="../js/charts.js" defer></script>
    <script src="../js/main.js" defer></script>
</head>
<body>
    <div class="dashboard-container">
        <!-- Do not change the sidebar; it is included as before -->
        <?php include('../includes/teacher_sidebar.php'); ?>

        <!-- <main class="dashboard-content">
           
            <header class="dashboard-header">
                <div class="header-info">
                    <h1>Profile</h1>
                    <?php if ($teacherName): ?>
                        <p>Welcome back, <?php echo htmlspecialchars($teacherName); ?>!</p>
                    <?php endif; ?>
                </div>

                <div class="header-actions">
                    <div class="date-display"><?php echo date('l, F j, Y'); ?></div>
                    <div class="user-profile">
                        <img src="../images/avatars/teacher.png" alt="Profile" class="avatar">
                        <div class="dropdown">
                            <span class="dropdown-toggle"><?php echo htmlspecialchars($teacherName); ?></span>
                            <div class="dropdown-menu">
                                <a href="profile.php">My Profile</a>
                                <a href="../logout.php">Logout</a>
                            </div>
                        </div>
                    </div>
                </div>
            </header> -->

            <!-- Main Profile Content -->
            <div class="dashboard-grid">
                <div class="dashboard-card full-width-card">
                    <div class="card-header">
                        <h2>My Profile Information</h2>
                    </div>
                    <div class="card-content">
                        <?php if (!empty($error)): ?>
                            <div class="error-message">
                                <?php echo $error; ?>
                            </div>
                        <?php elseif ($teacher): ?>
                            <div class="profile-details">
                                <!-- Left Column: Personal Information -->
                                <div class="profile-column">
                                    <h3>Personal Information</h3>
                                    <p><strong>First Name:</strong> <?php echo htmlspecialchars($teacher['first_name']); ?></p>
                                    <p><strong>Last Name:</strong> <?php echo htmlspecialchars($teacher['last_name']); ?></p>
                                    <p><strong>Gender:</strong> <?php echo htmlspecialchars($teacher['gender']); ?></p>
                                    <p><strong>Date of Birth:</strong> <?php echo htmlspecialchars($teacher['dob']); ?></p>
                                    <p><strong>CNIC:</strong> <?php echo htmlspecialchars($teacher['cnic']); ?></p>
                                    <p><strong>Father’s Name:</strong> <?php echo htmlspecialchars($teacher['father_name']); ?></p>
                                    <p><strong>Father’s CNIC:</strong> <?php echo htmlspecialchars($teacher['father_cnic']); ?></p>
                                    <p><strong>Nationality:</strong> <?php echo htmlspecialchars($teacher['nationality']); ?></p>
                                    <p><strong>Blood Group:</strong> <?php echo htmlspecialchars($teacher['blood_group']); ?></p>
                                </div>
                                
                                <!-- Middle Column: Academic & Account Information -->
                                <div class="profile-column">
                                    <h3>Academic & Account</h3>
                                    <p><strong>Email:</strong> <?php echo htmlspecialchars($teacher['email']); ?></p>
                                    <p><strong>Username:</strong> <?php echo htmlspecialchars($teacher['username']); ?></p>
                                    <p><strong>Qualification:</strong> <?php echo htmlspecialchars($teacher['qualification']); ?></p>
                                    <p><strong>Department:</strong> <?php echo htmlspecialchars($teacher['department']); ?></p>
                                    <p><strong>Joined On:</strong>
                                        <?php echo !empty($teacher['created_at']) ? date('F j, Y', strtotime($teacher['created_at'])) : 'N/A'; ?>
                                    </p>
                                </div>
                                
                                <!-- Right Column: Contact & Address -->
                                <div class="profile-column">
                                    <h3>Contact & Address</h3>
                                    <p><strong>Phone:</strong> <?php echo htmlspecialchars($teacher['phone']); ?></p>
                                    <p><strong>Address:</strong> <?php echo htmlspecialchars($teacher['address']); ?></p>
                                    <p><strong>City:</strong> <?php echo htmlspecialchars($teacher['city']); ?></p>
                                    <p><strong>Postal Code:</strong> <?php echo htmlspecialchars($teacher['postal_code']); ?></p>
                                    <p><strong>Country:</strong> <?php echo htmlspecialchars($teacher['country']); ?></p>
                                </div>
                            </div>
                        <?php else: ?>
                            <div class="empty-state">
                                <p>No profile data available.</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </main>
    </div>
</body>
</html>
