<?php
session_start();
require_once('../includes/db_config.php');
require_once('../includes/functions.php');
require_once('../includes/auth.php');

// Ensure only logged-in teachers can access
if (!isLoggedIn() || $_SESSION['user_type'] !== 'teacher') {
    redirect('../login.php?type=teacher');
}

$teacherId = $_SESSION['user_id'];
$pdo = getDbConnection();
$error = '';

// Check if a class (subject) is selected
$classId = isset($_GET['class_id']) ? intval($_GET['class_id']) : 0;
$selectedClass = null;

// If no specific class is requested, fetch teacher's classes
if (!$classId) {
    try {
        $stmt = $pdo->prepare("SELECT * FROM classes WHERE teacher_id = :teacher_id ORDER BY class_name ASC");
        $stmt->execute(['teacher_id' => $teacherId]);
        $classes = $stmt->fetchAll();
    } catch (PDOException $e) {
        $error = "Database error: " . $e->getMessage();
    }
} else {
    // Fetch the selected class details
    try {
        $stmt = $pdo->prepare("SELECT * FROM classes WHERE id = :class_id AND teacher_id = :teacher_id");
        $stmt->execute(['class_id' => $classId, 'teacher_id' => $teacherId]);
        $selectedClass = $stmt->fetch();
        if (!$selectedClass) {
            $error = "The requested subject was not found.";
        }
    } catch (PDOException $e) {
        $error = "Database error: " . $e->getMessage();
    }
    
    // Fetch enrolled students along with computed attendance and marks data
    $studentsData = [];
    if (empty($error)) {
        try {
            // Get list of enrolled students (joining with students table)
            $stmt = $pdo->prepare("
                SELECT s.id, s.first_name, s.last_name 
                FROM class_enrollments ce 
                JOIN students s ON ce.student_id = s.id 
                WHERE ce.class_id = :class_id
            ");
            $stmt->execute(['class_id' => $classId]);
            $students = $stmt->fetchAll();
            
            // Prepare arrays for chart data
            $chartLabels = [];
            $attendanceData = [];
            $marksData = [];
            
            foreach ($students as $student) {
                $studentId = $student['id'];
                $fullName = $student['first_name'] . ' ' . $student['last_name'];
                $chartLabels[] = $fullName;
                
                // Calculate attendance for this student in this class
                $stmtAttend = $pdo->prepare("
                    SELECT COUNT(*) as total, 
                           SUM(CASE WHEN status = 'present' THEN 1 ELSE 0 END) as present
                    FROM attendance 
                    WHERE class_id = :class_id AND student_id = :student_id
                ");
                $stmtAttend->execute(['class_id' => $classId, 'student_id' => $studentId]);
                $attendResult = $stmtAttend->fetch();
                
                $totalSessions = $attendResult ? $attendResult['total'] : 0;
                $presentSessions = $attendResult ? $attendResult['present'] : 0;
                $attendancePercent = ($totalSessions > 0) ? round(($presentSessions / $totalSessions) * 100, 1) : 0;
                
                // Calculate average marks (as percentage) for this student in this class
                $stmtMarks = $pdo->prepare("
                    SELECT AVG(marks_obtained * 100.0 / total_marks) as avg_percentage 
                    FROM marks 
                    WHERE class_id = :class_id AND student_id = :student_id
                ");
                $stmtMarks->execute(['class_id' => $classId, 'student_id' => $studentId]);
                $marksResult = $stmtMarks->fetch();
                $avgMarks = $marksResult && $marksResult['avg_percentage'] !== null ? round($marksResult['avg_percentage'], 1) : 0;
                
                $studentsData[] = [
                    'id' => $studentId,
                    'name' => $fullName,
                    'attendance' => $attendancePercent,
                    'marks' => $avgMarks
                ];
                
                // Add to chart arrays
                $attendanceData[] = $attendancePercent;
                $marksData[] = $avgMarks;
            }
        } catch (PDOException $e) {
            $error = "Database error (students): " . $e->getMessage();
        }
    }
}
include __DIR__ . '/../includes/header.php';

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reports - EduBridge</title>
    <link rel="stylesheet" href="../css/style.css">
    <!-- Inline styles specific for reports page -->
    <style>
       .reports-container {
  display: block;
  margin: var(--spacing-lg) var(--spacing-xl);
  padding: var(--spacing-xl);
  background: rgba(255, 255, 255, 0.04);
  border-radius: var(--border-radius-lg);
  backdrop-filter: blur(10px);
  border: 1px solid rgba(255, 255, 255, 0.08);
  box-shadow: var(--shadow-md);
  max-width: 900px;
}

.reports-container h2 {
  color: var(--primary-color);
  margin-bottom: var(--spacing-lg);
  font-size: var(--font-size-xl);
  text-align: left;
  text-shadow: var(--glow-sm);
  padding-left: var(--spacing-sm);
}

.subject-list {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
  gap: var(--spacing-md);
}

.subject-list a {
  display: block;
  padding: var(--spacing-sm) var(--spacing-md);
  background: rgba(255, 255, 255, 0.05);
  border: 1px solid rgba(255, 255, 255, 0.1);
  border-radius: var(--border-radius-md);
  text-align: center;
  color: var(--primary-color);
  text-decoration: none;
  font-weight: bold;
  transition: all 0.2s ease;
  box-shadow: 0 0 0 transparent;
}

.subject-list a:hover {
  background: rgba(145, 70, 255, 0.1);
  transform: translateY(-2px);
  box-shadow: var(--glow-sm);
  color: var(--secondary-color);
}

    </style>
    <!-- Chart.js library -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <!-- Optional Scripts -->
    <script src="../js/main.js" defer></script>
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar (unchanged) -->
        <?php include('../includes/teacher_sidebar.php'); ?>

        <main class="dashboard-content">
            <!-- Header (similar to dashboard) -->
            <header class="dashboard-header">
                <div class="header-info">
                    <h1>Reports</h1>
                    <!-- <p>Monitor student attendance and marks by subject.</p>
                </div>
                <div class="header-actions">
                    <div class="date-display"><?php echo date('l, F j, Y'); ?></div>
                    <div class="user-profile">
                        <img src="../images/avatars/teacher.png" alt="Profile" class="avatar">
                        <div class="dropdown">
                            <span class="dropdown-toggle"><?php echo htmlspecialchars($teacherName); ?></span>
                            <div class="dropdown-menu">
                                <a href="profile.php">My Profile</a>
                                <a href="../logout.php">Logout</a>
                            </div>
                        </div>
                    </div>
                </div> -->
            </header>

            <!-- Main Content of Reports -->
            <div class="reports-container">
                <?php if (!empty($error)): ?>
                    <div class="error-message"><?php echo $error; ?></div>
                <?php else: ?>
                    <?php if (!$classId): ?>
                        <!-- List of subjects (classes) for selection -->
                        <h2>Select a Subject</h2>
                        <div class="subject-list">
                        <?php if (!empty($classes)): ?>
                            <?php foreach ($classes as $class): ?>
                                <div class="subject-item">
                                    <a href="reports.php?class_id=<?php echo $class['id']; ?>">
                                        <?php echo htmlspecialchars($class['class_name']); ?>
                                    </a>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <p>No subjects found.</p>
                        <?php endif; ?>
                        </div>
                    <?php else: ?>
                        <!-- Detailed report for the selected class -->
                        <a class="back-link" href="reports.php">&laquo; Back to Subjects</a>
                        <h2>Subject: <?php echo htmlspecialchars($selectedClass['class_name']); ?></h2>
                        <!-- Report Table -->
                        <table>
                            <thead>
                                <tr>
                                    <th>Student Name</th>
                                    <th>Attendance (%)</th>
                                    <th>Average Marks (%)</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (!empty($studentsData)): ?>
                                    <?php foreach ($studentsData as $s): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($s['name']); ?></td>
                                            <td><?php echo $s['attendance']; ?>%</td>
                                            <td><?php echo $s['marks']; ?>%</td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="3">No students enrolled for this subject.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>

                        <!-- Charts for visual representation -->
                        <div class="chart-container">
                            <canvas id="attendanceChart"></canvas>
                        </div>
                        <div class="chart-container">
                            <canvas id="marksChart"></canvas>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </main>
    </div>
    
    <!-- Chart Rendering Script -->
    <?php if ($classId && empty($error) && !empty($studentsData)): ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Chart data provided by PHP arrays (encoded as JSON)
            const labels = <?php echo json_encode($chartLabels); ?>;
            const attendanceData = <?php echo json_encode($attendanceData); ?>;
            const marksData = <?php echo json_encode($marksData); ?>;
            
            // Attendance Chart
            const ctxAttendance = document.getElementById('attendanceChart').getContext('2d');
            new Chart(ctxAttendance, {
                type: 'bar',
                data: {
                    labels: labels,
                    datasets: [{
                        label: 'Attendance (%)',
                        data: attendanceData,
                        backgroundColor: 'rgba(37, 99, 235, 0.6)',
                        borderColor: 'rgba(37, 99, 235, 1)',
                        borderWidth: 1
                    }]
                },
                options: {
                    scales: {
                        y: { beginAtZero: true, max: 100 }
                    }
                }
            });

            // Marks Chart
            const ctxMarks = document.getElementById('marksChart').getContext('2d');
            new Chart(ctxMarks, {
                type: 'bar',
                data: {
                    labels: labels,
                    datasets: [{
                        label: 'Average Marks (%)',
                        data: marksData,
                        backgroundColor: 'rgba(40, 167, 69, 0.6)',
                        borderColor: 'rgba(40, 167, 69, 1)',
                        borderWidth: 1
                    }]
                },
                options: {
                    scales: {
                        y: { beginAtZero: true, max: 100 }
                    }
                }
            });
        });
    </script>
    <?php endif; ?>
</body>
</html>
