<?php
session_start();
require_once('../includes/db_config.php');
require_once('../includes/functions.php');
require_once('../includes/auth.php');

// Check if user is logged in and is a teacher
if (!isLoggedIn() || $_SESSION['user_type'] !== 'teacher') {
    redirect('../login.php?type=teacher');
}

// Get teacher information
$teacherId = $_SESSION['user_id'];
$teacherName = isset($_SESSION['user_name']) ? $_SESSION['user_name'] : '';

// Get complete teacher information
$teacherInfo = getCurrentUserInfo();
if (!empty($teacherInfo)) {
    $teacherName = $teacherInfo['first_name'] . ' ' . $teacherInfo['last_name'];
}

// Get PDO connection
$pdo = getDbConnection();

// Get classes taught by teacher
$classes = [];
try {
    $stmt = $pdo->prepare("
        SELECT c.id, c.class_name, c.class_code, c.description,
               COUNT(DISTINCT ce.student_id) AS student_count,
               COUNT(DISTINCT sp.id) AS post_count
        FROM classes c
        LEFT JOIN class_enrollments ce ON c.id = ce.class_id
        LEFT JOIN stream_posts sp ON c.id = sp.class_id
        WHERE c.teacher_id = :teacher_id
        GROUP BY c.id, c.class_name, c.class_code, c.description
        ORDER BY c.created_at DESC
    ");
    $stmt->execute(['teacher_id' => $teacherId]);
    $classes = $stmt->fetchAll();
} catch (PDOException $e) {
    $error = "Database error: " . $e->getMessage();
}

// Get recent assignments
$recentAssignments = [];
try {
    $stmt = $pdo->prepare("
        SELECT sp.id, sp.title, sp.due_date, c.class_name, c.id AS class_id,
               COUNT(DISTINCT a.id) AS submission_count,
               COUNT(DISTINCT ce.student_id) AS student_count
        FROM stream_posts sp
        JOIN classes c ON sp.class_id = c.id
        LEFT JOIN assignment_submissions a ON sp.id = a.post_id
        LEFT JOIN class_enrollments ce ON c.id = ce.class_id
        WHERE c.teacher_id = :teacher_id AND sp.post_type = 'assignment'
        GROUP BY sp.id, sp.title, sp.due_date, c.class_name, c.id
        ORDER BY sp.due_date ASC
        LIMIT 5
    ");
    $stmt->execute(['teacher_id' => $teacherId]);
    $recentAssignments = $stmt->fetchAll();
} catch (PDOException $e) {
    $error = "Database error: " . $e->getMessage();
}

// Get students and attendance count
$studentCount = 0;
$attendanceStats = [
    'present' => 0,
    'absent' => 0,
    'late' => 0,
    'total' => 0
];

try {
    // Count total students in all teacher's classes
    $stmt = $pdo->prepare("
        SELECT COUNT(DISTINCT ce.student_id) AS student_count
        FROM class_enrollments ce
        JOIN classes c ON ce.class_id = c.id
        WHERE c.teacher_id = :teacher_id
    ");
    $stmt->execute(['teacher_id' => $teacherId]);
    $result = $stmt->fetch();
    $studentCount = $result ? $result['student_count'] : 0;
    
    // Get attendance statistics
    $stmt = $pdo->prepare("
        SELECT status, COUNT(a.id) AS count
        FROM attendance a
        JOIN classes c ON a.class_id = c.id
        WHERE c.teacher_id = :teacher_id AND a.recorded_by = :teacher_id
        GROUP BY status
    ");
    $stmt->execute(['teacher_id' => $teacherId]);
    
    while ($row = $stmt->fetch()) {
        $attendanceStats[$row['status']] = $row['count'];
        $attendanceStats['total'] += $row['count'];
    }
} catch (PDOException $e) {
    $error = "Database error: " . $e->getMessage();
}

// Calculate class performance metrics
$classPerformance = [];
try {
    $stmt = $pdo->prepare("
        SELECT c.id, c.class_name, c.class_code,
               AVG(m.marks_obtained / m.total_marks * 100) AS avg_performance,
               COUNT(DISTINCT m.student_id) AS student_count_with_marks
        FROM classes c
        LEFT JOIN marks m ON c.id = m.class_id
        WHERE c.teacher_id = :teacher_id
        GROUP BY c.id, c.class_name, c.class_code
        ORDER BY avg_performance DESC
    ");
    $stmt->execute(['teacher_id' => $teacherId]);
    $classPerformance = $stmt->fetchAll();
} catch (PDOException $e) {
    $error = "Database error: " . $e->getMessage();
}

// Count total assignments
$assignmentCount = 0;
try {
    $stmt = $pdo->prepare("
        SELECT COUNT(sp.id) AS assignment_count
        FROM stream_posts sp
        JOIN classes c ON sp.class_id = c.id
        WHERE c.teacher_id = :teacher_id AND sp.post_type = 'assignment'
    ");
    $stmt->execute(['teacher_id' => $teacherId]);
    $result = $stmt->fetch();
    $assignmentCount = $result ? $result['assignment_count'] : 0;
} catch (PDOException $e) {
    $error = "Database error: " . $e->getMessage();
}

// Count pending assignment submissions
$pendingSubmissions = 0;
try {
    $stmt = $pdo->prepare("
        SELECT COUNT(a.id) AS pending_count
        FROM assignment_submissions a
        JOIN stream_posts sp ON a.post_id = sp.id
        JOIN classes c ON sp.class_id = c.id
        WHERE c.teacher_id = :teacher_id AND a.marks_obtained IS NULL
    ");
    $stmt->execute(['teacher_id' => $teacherId]);
    $result = $stmt->fetch();
    $pendingSubmissions = $result ? $result['pending_count'] : 0;
} catch (PDOException $e) {
    $error = "Database error: " . $e->getMessage();
}
include __DIR__ . '/../includes/header.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teacher Dashboard - EduBridge</title>
    <link rel="stylesheet" href="../css/style.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="../js/charts.js" defer></script>
    <script src="../js/main.js" defer></script>
</head>
<body>
    <div class="dashboard-container">
        
        <?php include('../includes/teacher_sidebar.php'); ?>
        
        <main class="dashboard-content">
            <header class="dashboard-header">
                <div class="header-info">
                    <h1>Dashboard</h1>
                    <p>Welcome back, <?php echo htmlspecialchars($teacherName); ?>!</p>
                </div>
<!--                 
                <div class="header-actions">
                    <div class="date-display"><?php echo date('l, F j, Y'); ?></div>
                    <div class="user-profile">
                        <img src="../images/avatars/teacher.png" alt="Profile" class="avatar">
                        <div class="dropdown">
                            <span class="dropdown-toggle"><?php echo htmlspecialchars($teacherName); ?></span>
                            <div class="dropdown-menu">
                                <a href="profile.php">My Profile</a>
                                <a href="../logout.php">Logout</a>
                            </div>
                        </div>
                    </div>
                </div> -->
            </header>
            
            <div class="dashboard-stats">
                <div class="stat-card">
                    <div class="stat-icon students-icon">👨‍🎓</div>
                    <div class="stat-info">
                        <span class="stat-value"><?php echo $studentCount; ?></span>
                        <span class="stat-label">Students</span>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon classes-icon">🏫</div>
                    <div class="stat-info">
                        <span class="stat-value"><?php echo count($classes); ?></span>
                        <span class="stat-label">Classes</span>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon assignments-icon">📝</div>
                    <div class="stat-info">
                        <span class="stat-value"><?php echo $assignmentCount; ?></span>
                        <span class="stat-label">Assignments</span>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon pending-icon">⏳</div>
                    <div class="stat-info">
                        <span class="stat-value"><?php echo $pendingSubmissions; ?></span>
                        <span class="stat-label">Pending Submissions</span>
                    </div>
                </div>
            </div>
            
            <div class="dashboard-grid">
                <!-- Classes Card -->
                <div class="dashboard-card classes-card">
                    <div class="card-header">
                        <h2>My Classes</h2>
                        <a href="classes.php" class="view-all">View All</a>
                    </div>
                    
                    <div class="card-content">
                        <?php if (empty($classes)): ?>
                            <div class="empty-state">
                                <p>You haven't created any classes yet.</p>
                                <a href="classes.php" class="btn-primary">Create a Class</a>
                            </div>
                        <?php else: ?>
                            <div class="class-list">
                                <?php foreach ($classes as $class): ?>
                                    <div class="class-item">
                                        <div class="class-info">
                                            <h3><?php echo htmlspecialchars($class['class_name']); ?></h3>
                                            <p>Code: <?php echo htmlspecialchars($class['class_code']); ?></p>
                                            <p><?php echo $class['student_count']; ?> students · <?php echo $class['post_count']; ?> posts</p>
                                        </div>
                                        <a href="stream.php?class_id=<?php echo $class['id']; ?>" class="btn-secondary">Manage</a>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Attendance Overview Card -->
                <div class="dashboard-card attendance-card">
                    <div class="card-header">
                        <h2>Attendance Overview</h2>
                        <a href="attendance.php" class="view-all">Mark Attendance</a>
                    </div>
                    
                    <div class="card-content">
                        <?php if ($attendanceStats['total'] == 0): ?>
                            <div class="empty-state">
                                <p>No attendance records available.</p>
                            </div>
                        <?php else: ?>
                            <div class="attendance-chart">
                                <canvas id="attendanceChart"></canvas>
                            </div>
                            
                            <div class="attendance-stats">
                                <div class="stat-item present">
                                    <span class="value"><?php echo $attendanceStats['present']; ?></span>
                                    <span class="label">Present</span>
                                </div>
                                <div class="stat-item absent">
                                    <span class="value"><?php echo $attendanceStats['absent']; ?></span>
                                    <span class="label">Absent</span>
                                </div>
                                <div class="stat-item late">
                                    <span class="value"><?php echo $attendanceStats['late']; ?></span>
                                    <span class="label">Late</span>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Assignment Status Card -->
                <div class="dashboard-card assignments-card">
                    <div class="card-header">
                        <h2>Assignment Status</h2>
                    </div>
                    
                    <div class="card-content">
                        <?php if (empty($recentAssignments)): ?>
                            <div class="empty-state">
                                <p>No assignments created yet.</p>
                            </div>
                        <?php else: ?>
                            <div class="assignment-list">
                                <?php foreach ($recentAssignments as $assignment): ?>
                                    <?php 
                                    $submissionRate = ($assignment['student_count'] > 0) ? 
                                        ($assignment['submission_count'] / $assignment['student_count']) * 100 : 0;
                                    
                                    $dueDate = new DateTime($assignment['due_date']);
                                    $now = new DateTime();
                                    $isPast = $now > $dueDate;
                                    $statusClass = $isPast ? 'past-due' : 'upcoming';
                                    ?>
                                    <div class="assignment-item <?php echo $statusClass; ?>">
                                        <div class="assignment-info">
                                            <h3><?php echo htmlspecialchars($assignment['title']); ?></h3>
                                            <p><?php echo htmlspecialchars($assignment['class_name']); ?></p>
                                            <p>Due: <?php echo date('M j, Y', strtotime($assignment['due_date'])); ?></p>
                                            <div class="submission-progress">
                                                <div class="progress-bar" style="width: <?php echo $submissionRate; ?>%"></div>
                                                <span class="progress-text">
                                                    <?php echo $assignment['submission_count']; ?>/<?php echo $assignment['student_count']; ?> submissions
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Class Performance Card -->
                <div class="dashboard-card performance-card">
                    <div class="card-header">
                        <h2>Class Performance</h2>
                        <a href="marks.php" class="view-all">All Marks</a>
                    </div>
                    
                    <div class="card-content">
                        <?php if (empty($classPerformance) || count(array_filter(array_column($classPerformance, 'avg_performance'))) === 0): ?>
                            <div class="empty-state">
                                <p>No performance data available yet.</p>
                            </div>
                        <?php else: ?>
                            <div class="performance-chart">
                                <canvas id="performanceChart"></canvas>
                            </div>
                            
                            <div class="class-performance-list">
                                <?php foreach ($classPerformance as $perf): ?>
                                    <?php if ($perf['student_count_with_marks'] > 0): ?>
                                        <?php 
                                        $perfValue = round($perf['avg_performance'], 1);
                                        $perfClass = $perfValue >= 90 ? 'excellent' : ($perfValue >= 80 ? 'good' : ($perfValue >= 70 ? 'average' : ($perfValue >= 60 ? 'fair' : 'poor')));
                                        ?>
                                        <div class="performance-item">
                                            <div class="performance-label">
                                                <span class="class-name"><?php echo htmlspecialchars($perf['class_name']); ?></span>
                                                <span class="student-count"><?php echo $perf['student_count_with_marks']; ?> students</span>
                                            </div>
                                            <div class="performance-value <?php echo $perfClass; ?>">
                                                <?php echo $perfValue; ?>%
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </main>
    </div>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Attendance chart
            <?php if ($attendanceStats['total'] > 0): ?>
            const attendanceCtx = document.getElementById('attendanceChart').getContext('2d');
            createDoughnutChart('attendanceChart', {
                labels: ['Present', 'Absent', 'Late'],
                datasets: [{
                    data: [
                        <?php echo $attendanceStats['present']; ?>,
                        <?php echo $attendanceStats['absent']; ?>,
                        <?php echo $attendanceStats['late']; ?>
                    ],
                    backgroundColor: ['#4BC0C0', '#FF6384', '#FFCD56']
                }]
            }, {
                cutout: '70%',
                plugins: {
                    legend: {
                        display: false
                    }
                }
            });
            <?php endif; ?>
            
            // Class performance chart
            <?php if (!empty($classPerformance) && count(array_filter(array_column($classPerformance, 'avg_performance'))) > 0): ?>
            const performanceCtx = document.getElementById('performanceChart').getContext('2d');
            createBarChart('performanceChart', {
                labels: [
                    <?php 
                    $chartData = [];
                    foreach ($classPerformance as $perf) {
                        if ($perf['student_count_with_marks'] > 0) {
                            echo "'" . htmlspecialchars($perf['class_code']) . "', ";
                            $chartData[] = round($perf['avg_performance'], 1);
                        }
                    }
                    ?>
                ],
                datasets: [{
                    label: 'Average Performance (%)',
                    data: [<?php echo implode(', ', $chartData); ?>],
                    backgroundColor: '#36A2EB'
                }]
            }, {
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 100
                    }
                }
            });
            <?php endif; ?>
        });
    </script>
</body>
</html>