<?php
// teacher/marks.php
session_start();
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db_config.php';
require_once __DIR__ . '/../includes/functions.php';
requireTeacher();

// 1) Get this teacher’s classes
$teacherId = $_SESSION['user_id'];
$classes   = getTeacherClasses($teacherId);

// 2) Figure out which class & mode we’re in
$selectedClassId = isset($_GET['class_id'])
    ? (int)$_GET['class_id']
    : ($classes[0]['id'] ?? 0);

$action = $_GET['action'] ?? 'view';  // either 'view' or 'add'

// 3) Load enrolled students for this class
$students = $selectedClassId
    ? getClassStudents($selectedClassId)
    : [];

// 4) Handle POST (always record marks, then redirect back into add mode with a success flag)
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $name  = sanitize($_POST['assignment_name'] ?? '');
    $total = floatval($_POST['total_marks'] ?? 0);
    $date  = sanitize($_POST['date'] ?? '');
    $marks = $_POST['marks'] ?? [];

    // filter out only numeric, non‐negative marks
    $valid = array_filter($marks, fn($m)=> is_numeric($m) && $m>=0);

    if ($name && $total>0 && $date && !empty($valid)) {
        $pdo = getDbConnection();
        $pdo->beginTransaction();
        foreach ($valid as $sid => $obtained) {
            // upsert logic
            $stmt = $pdo->prepare("
                SELECT id FROM marks
                 WHERE class_id=:cid
                   AND student_id=:sid
                   AND assignment_name=:an
            ");
            $stmt->execute([
                'cid'=>$selectedClassId,
                'sid'=>$sid,
                'an'=>$name
            ]);
            if ($row = $stmt->fetch()) {
                $u = $pdo->prepare("
                  UPDATE marks
                    SET marks_obtained=:mo,
                        total_marks   =:tm,
                        date          =:d,
                        recorded_by   =:rb
                   WHERE id=:id
                ");
                $u->execute([
                  'mo'=>$obtained,
                  'tm'=>$total,
                  'd'=>$date,
                  'rb'=>$teacherId,
                  'id'=>$row['id']
                ]);
            } else {
                $i = $pdo->prepare("
                  INSERT INTO marks
                    (class_id,student_id,assignment_name,
                     marks_obtained,total_marks,date,recorded_by)
                  VALUES
                    (:cid,:sid,:an,:mo,:tm,:d,:rb)
                ");
                $i->execute([
                  'cid'=>$selectedClassId,
                  'sid'=>$sid,
                  'an'=>$name,
                  'mo'=>$obtained,
                  'tm'=>$total,
                  'd'=>$date,
                  'rb'=>$teacherId
                ]);
            }
        }
        $pdo->commit();

        // back into add mode with a “success” flag
        header("Location: marks.php?class_id={$selectedClassId}&action=add&success=1");
        exit;
    } else {
        $error = "Please fill all required fields and enter at least one mark.";
    }
}

// 5) Show success banner if present
$success = isset($_GET['success']) ? "Marks saved!" : "";

// 6) If in **view** mode, fetch your assessments & stats
$assessments = [];
if ($action==='view' && $selectedClassId) {
    $pdo = getDbConnection();
    $stmt = $pdo->prepare("
      SELECT DISTINCT assignment_name,total_marks,date
      FROM marks
      WHERE class_id=:cid
      ORDER BY date DESC
    ");
    $stmt->execute(['cid'=>$selectedClassId]);
    $assessments = $stmt->fetchAll();
}

?>
<?php include __DIR__ . '/../includes/header.php'; ?> 
<div class="dashboard-container">
  <?php include __DIR__ . '/../includes/teacher_sidebar.php'; ?>
  <main class="dashboard-content">
    <h1>Manage Marks</h1>

    <?php if (!empty($error)): ?>
      <div class="alert alert-error"><?= $error ?></div>
    <?php elseif ($success): ?>
      <div class="alert alert-success"><?= $success ?></div>
    <?php endif; ?>

    <!-- CLASS + MODE SWITCHER -->
    <div class="page-toolbar">
      <label>Select Class:</label>
      <select
        onchange="location.href='marks.php?class_id='+this.value+'&action=<?= $action ?>'"
      >
        <?php foreach($classes as $c): ?>
          <option
            value="<?= $c['id'] ?>"
            <?= $c['id']===$selectedClassId?'selected':'' ?>
          >
            <?= htmlspecialchars($c['class_name']) ?>
          </option>
        <?php endforeach; ?>
      </select>

      <?php if ($action==='view'): ?>
        <a
          href="marks.php?class_id=<?= $selectedClassId ?>&action=add"
          class="btn-primary"
        >Add Marks</a>
      <?php else: /* add mode */ ?>
        <a
          href="marks.php?class_id=<?= $selectedClassId ?>&action=view"
          class="btn-secondary"
        >View Marks</a>
      <?php endif; ?>
    </div>

    <?php if ($action==='add'): ?>
      <!-- ADD MODE: the upload form -->
      <section class="card">
        <h2>Record Marks</h2>
        <form method="post">
          <div class="form-row">
            <label>Assessment Name*</label>
            <input type="text" name="assignment_name" required>
            <label>Total Marks*</label>
            <input type="number" name="total_marks" min="1" step="0.01" required>
            <label>Date*</label>
            <input type="date" name="date" value="<?= date('Y-m-d') ?>" required>
          </div>

          <table class="marks-table">
            <thead>
              <tr><th>Student</th><th>Mark</th></tr>
            </thead>
            <tbody>
              <?php foreach($students as $stu): ?>
                <tr>
                  <td><?= htmlspecialchars($stu['first_name'].' '.$stu['last_name']) ?></td>
                  <td>
                    <input
                      type="number"
                      name="marks[<?= $stu['id'] ?>]"
                      min="0"
                      step="0.01"
                      required
                    >
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>

          <div class="form-actions">
            <button class="btn-primary">Save Marks</button>
          </div>
        </form>
      </section>

    <?php else: ?>
      <!-- VIEW MODE: analytics & list of assessments -->
      <section class="card">
        <h2>Assessments</h2>
        <?php if (empty($assessments)): ?>
          <p>No assessments yet. <a href="?class_id=<?= $selectedClassId ?>&action=add">Add Marks</a>.</p>
        <?php else: ?>
          <ul>
            <?php foreach($assessments as $a): ?>
              <li>
                <?= htmlspecialchars($a['assignment_name']) ?>
                (<?= $a['total_marks'] ?> marks &mdash;
                <?= date('M j, Y',strtotime($a['date'])) ?>)
              </li>
            <?php endforeach; ?>
          </ul>
        <?php endif; ?>
      </section>
    <?php endif; ?>
  </main>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
