<?php
// teacher/stream.php
// ------------------
session_start();

// 1) Pull in your <head> + CSS
include __DIR__ . '/../includes/header.php';

// 2) Core includes
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db_config.php';
require_once __DIR__ . '/../includes/functions.php';

// 3) Must be logged in
if (!isLoggedIn()) {
    redirect('../login.php');
}

// 4) Get & verify class access
$class_id = isset($_GET['class_id']) ? intval($_GET['class_id']) : 0;
if (!verifyClassAccess($class_id, $_SESSION['user_id'], $_SESSION['user_type'])) {
    redirect('../dashboard.php');
}

// 5) Fetch class details and stream posts
$class = getClassDetails($class_id);
$streamPosts = getStreamPosts($class_id);

// 6) Remove demo post if present
$streamPosts = array_filter(
    $streamPosts,
    fn($p) => trim($p['content']) !== 'This is a test post to confirm everything is working!'
);

// 7) Handle “Create Post” action
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'create_post') {
    $post_type = trim($_POST['post_type']);
    $title     = trim($_POST['title']);
    $content   = trim($_POST['content']);
    $due_date  = ($post_type === 'assignment' && !empty($_POST['due_date']))
               ? $_POST['due_date']
               : null;

    // Handle file upload (attachment)
    $file_path = null;
    if (!empty($_FILES['attachment']['name']) && $_FILES['attachment']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = __DIR__ . '/../uploads/class_' . $class_id . '/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }
        $filename = time() . '_' . basename($_FILES['attachment']['name']);
        $destination = $uploadDir . $filename;
        if (move_uploaded_file($_FILES['attachment']['tmp_name'], $destination)) {
          // now absolute from web‐root:
          $file_path = '/uploads/class_' . $class_id . '/' . $filename;
      }
       else {
            $error = 'Error uploading file: ' . $_FILES['attachment']['error'];
        }
    }

    // Insert the post into the database
    if (!isset($error)) {
        $result = createStreamPost(
            $class_id,
            $_SESSION['user_id'], 
            $_SESSION['user_type'], 
            $post_type,
            $title,
            $content,
            $due_date
        );

        if ($result) {
            // If we have an attachment, update file_path separately
            if ($file_path) {
                $pdo = getDbConnection();
                $stmt = $pdo->prepare(
                    'UPDATE stream_posts SET file_path = :file_path WHERE id = :post_id'
                );
                $stmt->execute([
                    'file_path' => $file_path,
                    'post_id'   => $result
                ]);
            }

            echo "<script>window.location.replace('stream.php?class_id=$class_id');</script>";
            exit;
        } else {
            $error = 'Error creating post: Failed to insert into the database.';
        }
    }

    // Show any error
    if (isset($error)) {
        echo '<div class="notification error">' . htmlspecialchars($error) . '</div>';
    }
    redirect('dashboard.php' . $classId);
}

// 8) Handle “Add Comment” action
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'add_comment') {
    $pid     = intval($_POST['post_id']);
    $comment = trim($_POST['comment']);
    if (addPostComment($pid, $_SESSION['user_id'], $_SESSION['user_type'], $comment)) {
        header('Location: stream.php?class_id=' . $class_id);
        exit;
    } else {
        $error = 'Error adding comment.';
    }
}

// 9) Render sidebar and content
include __DIR__ . '/../includes/teacher_sidebar.php';
?>

<div class="class-stream-container">
    <!-- Class navigation -->
    <?php include __DIR__ . '/../includes/class_nav.php'; ?>

    <h2 class="section-title"><?= htmlspecialchars($class['class_name']) ?> — Stream</h2>

    <?php if (!empty($error)): ?>
        <div class="notification error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <?php if ($_SESSION['user_type'] === 'teacher'): ?>
        <button id="show-post-form" class="btn btn-primary mb-4 w-100">Create Post</button>
        <div id="post-form" style="display:none;">
            <form action="stream.php?class_id=<?= $class_id ?>" method="post" enctype="multipart/form-data" class="card card-body mb-5">
                <input type="hidden" name="action" value="create_post">
                <div class="mb-3">
                    <label for="post_type">Post Type</label>
                    <select id="post_type" name="post_type" class="form-control" required>
                        <option value="">Select type</option>
                        <option value="announcement">Announcement</option>
                        <option value="assignment">Assignment</option>
                        <option value="material">Material</option>
                        <option value="question">Question</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label for="title">Title</label>
                    <input id="title" name="title" type="text" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label for="content">Content</label>
                    <textarea id="content" name="content" rows="4" class="form-control" required></textarea>
                </div>
                <div class="mb-3 assignment-options" style="display:none;">
                    <label for="due_date">Due Date</label>
                    <input id="due_date" name="due_date" type="datetime-local" class="form-control">
                </div>
                <div class="mb-3">
                    <label for="attachment">Attachment</label>
                    <input id="attachment" name="attachment" type="file" class="form-control">
                </div>
                <div class="d-flex gap-2">
                    <button type="submit" class="btn btn-primary">Post</button>
                    <button type="button" id="cancel-post" class="btn btn-secondary">Cancel</button>
                </div>
            </form>
        </div>
    <?php endif; ?>

    <?php foreach ($streamPosts as $post): ?>
        <div class="card mb-4">
            <div class="card-header">
                <strong><?= htmlspecialchars($post['author_name']) ?></strong>
                <small class="text-lighter ms-2"><?= htmlspecialchars($post['created_at']) ?></small>
            </div>
            <div class="card-body">
                <h5><?= htmlspecialchars($post['title']) ?></h5>
                <p><?= nl2br(htmlspecialchars($post['content'])) ?></p>
                <?php if ($post['post_type'] === 'assignment'): ?>
                    <div class="text-muted mb-3">
                        <strong>Due:</strong> <?= htmlspecialchars($post['due_date']) ?>
                    </div>
                <?php endif; ?>
                <?php if (!empty($post['file_path'])): ?>
                    <div>
                        <a href="<?= htmlspecialchars($post['file_path']) ?>" target="_blank">Download Attachment</a>
                    </div>
                <?php endif; ?>
            </div>
            <div class="card-footer">
                <?php foreach (getPostComments($post['id']) as $c): ?>
                    <div class="mb-3">
                        <strong><?= htmlspecialchars(getUserName($c['user_id'], $c['user_type'])) ?></strong>
                        <small class="text-lighter ms-2"><?= htmlspecialchars($c['created_at']) ?></small>
                        <div><?= nl2br(htmlspecialchars($c['comment'])) ?></div>
                    </div>
                <?php endforeach; ?>

                <form action="stream.php?class_id=<?= $class_id ?>" method="post" class="d-flex gap-2">
                    <input type="hidden" name="action" value="add_comment">
                    <input type="hidden" name="post_id" value="<?= $post['id'] ?>">
                    <input name="comment" type="text" class="form-control" placeholder="Add comment…" required>
                    <button type="submit" class="btn btn-primary">Comment</button>
                </form>
            </div>
        </div>
    <?php endforeach; ?>
</div>

<script>
// Toggle post form visibility
document.getElementById('show-post-form')?.addEventListener('click', () => {
    document.getElementById('post-form').style.display = 'block';
    document.getElementById('show-post-form').style.display = 'none';
});

document.getElementById('cancel-post')?.addEventListener('click', () => {
    document.getElementById('post-form').style.display = 'none';
    document.getElementById('show-post-form').style.display = 'block';
});

// Show or hide due date field based on post type
document.getElementById('post_type')?.addEventListener('change', function() {
    document.querySelector('.assignment-options').style.display =
        this.value === 'assignment' ? 'block' : 'none';
});
</script>