<?php
session_start();
require_once('../includes/db_config.php');
require_once('../includes/functions.php');
require_once('../includes/auth.php');

// Ensure only logged-in teachers can access this page
if (!isLoggedIn() || $_SESSION['user_type'] !== 'teacher') {
    redirect('../login.php?type=teacher');
}

$teacherId = $_SESSION['user_id'];
$pdo = getDbConnection();
$error = '';
$success = '';

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sanitize input fields
    $examTitle = sanitize($_POST['exam_title']);
    $examDescription = sanitize($_POST['exam_description']);
    $examDate = sanitize($_POST['exam_date']);
    $examDuration = sanitize($_POST['exam_duration']);

    // Validate required fields
    if (empty($examTitle) || empty($examDate) || empty($examDuration)) {
        $error = "Please fill in all required fields.";
    } else {
        try {
            $stmt = $pdo->prepare("
                INSERT INTO exams (teacher_id, exam_title, exam_description, exam_date, exam_duration, created_at)
                VALUES (:teacher_id, :exam_title, :exam_description, :exam_date, :exam_duration, datetime('now'))
            ");
            $stmt->execute([
                'teacher_id' => $teacherId,
                'exam_title' => $examTitle,
                'exam_description' => $examDescription,
                'exam_date' => $examDate,
                'exam_duration' => $examDuration
            ]);
            $success = "Exam created successfully!";
        } catch (PDOException $e) {
            $error = "Database error: " . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exam Creator - EduBridge</title>
    <link rel="stylesheet" href="../css/style.css">
    <!-- Inline styling for the exam creator form -->
    <style>
        .exam-form-container {
            background-color: #ffffff;
            padding: 20px;
            border: 1px solid #dee2e6;
            border-radius: 6px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.05);
            max-width: 800px;
            margin: 20px auto;
        }
        .exam-form-container h2 {
            color: #2563EB;
            margin-bottom: 20px;
        }
        .exam-form-group {
            margin-bottom: 15px;
        }
        .exam-form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        .exam-form-group input,
        .exam-form-group textarea {
            width: 100%;
            padding: 8px;
            border: 1px solid #dee2e6;
            border-radius: 4px;
        }
        .exam-form-group input:focus,
        .exam-form-group textarea:focus {
            outline: none;
            border-color: #2563EB;
        }
        .exam-form-actions {
            text-align: right;
        }
        .exam-form-actions button {
            background-color: #2563EB;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 4px;
            cursor: pointer;
        }
        .exam-form-actions button:hover {
            background-color: #1e4dab;
        }
        .error-message, .success-message {
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 4px;
            font-size: 14px;
        }
        .error-message {
            background-color: #dc3545;
            color: #fff;
        }
        .success-message {
            background-color: #28a745;
            color: #fff;
        }
    </style>
    <!-- Optional Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="../js/charts.js" defer></script>
    <script src="../js/main.js" defer></script>
</head>
<body>
    <div class="dashboard-container">
        <!-- Include teacher sidebar (unchanged) -->
        <?php include('../includes/teacher_sidebar.php'); ?>

        <main class="dashboard-content">
            <!-- Header (similar to other pages) -->
            <header class="dashboard-header">
                <div class="header-info">
                    <h1>Exam Creator</h1>
                    <p>Create and manage your exam details below.</p>
                </div>
                <div class="header-actions">
                    <div class="date-display"><?php echo date('l, F j, Y'); ?></div>
                    <div class="user-profile">
                        <img src="../images/avatars/teacher.png" alt="Profile" class="avatar">
                        <div class="dropdown">
                            <span class="dropdown-toggle"><?php echo htmlspecialchars($teacherName); ?></span>
                            <div class="dropdown-menu">
                                <a href="profile.php">My Profile</a>
                                <a href="../logout.php">Logout</a>
                            </div>
                        </div>
                    </div>
                </div>
            </header>

            <!-- Exam Creator Form -->
            <div class="exam-form-container">
                <h2>Create New Exam</h2>
                <?php if (!empty($error)): ?>
                    <div class="error-message"><?php echo $error; ?></div>
                <?php elseif (!empty($success)): ?>
                    <div class="success-message"><?php echo $success; ?></div>
                <?php endif; ?>
                <form action="exam_creator.php" method="POST">
                    <div class="exam-form-group">
                        <label for="exam_title">Exam Title <span style="color: #dc3545;">*</span></label>
                        <input type="text" id="exam_title" name="exam_title" required>
                    </div>
                    <div class="exam-form-group">
                        <label for="exam_description">Exam Description / Instructions</label>
                        <textarea id="exam_description" name="exam_description" rows="4"></textarea>
                    </div>
                    <div class="exam-form-group">
                        <label for="exam_date">Exam Date <span style="color: #dc3545;">*</span></label>
                        <input type="date" id="exam_date" name="exam_date" required>
                    </div>
                    <div class="exam-form-group">
                        <label for="exam_duration">Exam Duration (in minutes) <span style="color: #dc3545;">*</span></label>
                        <input type="number" id="exam_duration" name="exam_duration" required min="1">
                    </div>
                    <div class="exam-form-actions">
                        <button type="submit">Create Exam</button>
                    </div>
                </form>
            </div>
        </main>
    </div>
</body>
</html>
