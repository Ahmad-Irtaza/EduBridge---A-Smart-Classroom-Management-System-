<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
require_once('../includes/db_config.php');
require_once('../includes/functions.php');
require_once('../includes/auth.php');

requireTeacher();

$teacherId = $_SESSION['user_id'];
$teacherClasses = getTeacherClasses($teacherId);
$selectedClassId = isset($_GET['class_id']) ? intval($_GET['class_id']) : (isset($teacherClasses[0]) ? $teacherClasses[0]['id'] : null);

if ($selectedClassId && !isTeacherClass($selectedClassId, $teacherId)) {
    $_SESSION['error'] = "You do not have access to this class";
    redirect('dashboard.php');
}

$selectedSection = isset($_GET['section']) ? sanitize($_GET['section']) : 'all';
$students = [];
if ($selectedClassId) {
    $students = getClassStudents($selectedClassId, $selectedSection);
}

$selectedDate = isset($_GET['date']) ? sanitize($_GET['date']) : date('Y-m-d');

$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $date = isset($_POST['date']) ? sanitize($_POST['date']) : '';
    $studentStatuses = isset($_POST['status']) ? $_POST['status'] : [];

    if (empty($date) || empty($studentStatuses)) {
        $error = "Please provide valid attendance data";
    } else {
        try {
            $pdo = getDbConnection();
            $pdo->beginTransaction();

            foreach ($studentStatuses as $studentId => $status) {
                $stmt = $pdo->prepare("
                    SELECT id FROM attendance
                    WHERE class_id = :class_id AND student_id = :student_id AND date = :date
                ");
                $stmt->execute([
                    'class_id' => $selectedClassId,
                    'student_id' => $studentId,
                    'date' => $date
                ]);

                $existingAttendance = $stmt->fetch(PDO::FETCH_ASSOC);

                if ($existingAttendance) {
                    $stmt = $pdo->prepare("
                        UPDATE attendance
                        SET status = :status, recorded_by = :recorded_by
                        WHERE id = :id
                    ");
                    $stmt->execute([
                        'status' => $status,
                        'recorded_by' => $teacherId,
                        'id' => $existingAttendance['id']
                    ]);
                } else {
                    $stmt = $pdo->prepare("
                        INSERT INTO attendance (class_id, student_id, date, status, recorded_by)
                        VALUES (:class_id, :student_id, :date, :status, :recorded_by)
                    ");
                    $stmt->execute([
                        'class_id' => $selectedClassId,
                        'student_id' => $studentId,
                        'date' => $date,
                        'status' => $status,
                        'recorded_by' => $teacherId
                    ]);
                }
            }

            $pdo->commit();
            $success = "Attendance marked successfully for " . formatDate($date);
            $selectedDate = $date;
        } catch (PDOException $e) {
            $pdo->rollBack();
            $error = "Database error: " . $e->getMessage();
        }
    }
}

$attendanceRecords = [];
if ($selectedClassId && $selectedDate) {
    try {
        $pdo = getDbConnection();
        $stmt = $pdo->prepare("
            SELECT a.* FROM attendance a
            WHERE a.class_id = :class_id AND a.date = :date
        ");
        $stmt->execute([
            'class_id' => $selectedClassId,
            'date' => $selectedDate
        ]);

        while ($record = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $attendanceRecords[$record['student_id']] = $record['status'];
        }
    } catch (PDOException $e) {
        $error = "Error retrieving attendance: " . $e->getMessage();
    }
}

$pageTitle = "Attendance Management - EduBridge";
$pageDescription = "Manage student attendance - EduBridge";

include __DIR__ . '/../includes/header.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?></title>
    <meta name="description" content="<?php echo $pageDescription; ?>">
   
</head>
<body>

    <!-- <header class="dashboard-header">
        <h1>EduBridge</h1>
    </header> -->

    <!-- <div id="dashboard-content-attendance"> -->
        <?php include('../includes/teacher_sidebar.php'); ?>
        <main class="main-content">
            <h2 class="dashboard-title">Attendance Management</h2>

            <?php if (!empty($success)): ?>
                <div class="success-message">
                    <?php echo $success; ?>
                </div>
            <?php endif; ?>

            <?php if (!empty($error)): ?>
                <div class="error-message">
                    <?php echo $error; ?>
                </div>
            <?php endif; ?>

            <div class="class-selector">
  <form method="get" action="attendance.php">
    <div class="form-group">
      <label for="class_id">Select Subject:</label>
      <select id="class_id" name="class_id" onchange="this.form.submit()">
        <option value="">-- Select Subject --</option>
        <?php foreach ($teacherClasses as $class): ?>
          <option value="<?= $class['id'] ?>"
            <?= $selectedClassId == $class['id'] ? 'selected' : '' ?>>
            <?= htmlspecialchars($class['class_name']) ?>
          </option>
        <?php endforeach; ?>
      </select>
    </div>

    <?php if ($selectedClassId): ?>
      <?php $sections = getSectionsForClass($selectedClassId); ?>
      <?php if (!empty($sections)): ?>
        <div class="form-group">
          <label for="section">Select Section:</label>
          <select id="section" name="section" onchange="this.form.submit()">
            <option value="all">-- All Sections --</option>
            <?php foreach ($sections as $section): ?>
              <option value="<?= htmlspecialchars($section) ?>"
                <?= $selectedSection === $section ? 'selected' : '' ?>>
                <?= htmlspecialchars($section) ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>
      <?php endif; ?>
    <?php endif; ?>

    <?php if ($selectedClassId): ?>
      <div class="form-group">
        <label for="date">Select Date:</label>
        <input
          type="date"
          id="date"
          name="date"
          value="<?= htmlspecialchars($selectedDate) ?>"
          onchange="this.form.submit()"
          class="form-control"
        >
      </div>
    <?php endif; ?>
  </form>
</div>


            <?php if ($selectedClassId): ?>
                <?php if (empty($students)): ?>
                    <div class="info-card">
                        <div class="empty-state">
                            <p>No students enrolled in this subject and section yet.</p>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="attendance-form">
                        <h3>Mark Attendance for <?php echo formatDate($selectedDate); ?></h3>

                        <form method="post" action="attendance.php?class_id=<?php echo $selectedClassId; ?><?php if (isset($selectedSection)): ?>&section=<?php echo htmlspecialchars($selectedSection); ?><?php endif; ?>&date=<?php echo $selectedDate; ?>">
                            <input type="hidden" name="date" value="<?php echo $selectedDate; ?>">

                            <table class="attendance-table">
                                <thead>
                                    <tr>
                                        <th>Student</th>
                                        <th>Present</th>
                                        <th>Late</th>
                                        <th>Absent</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($students as $student): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($student['first_name'] . ' ' . $student['last_name']); ?></td>
                                            <td>
                                                <button type="button" class="attendance-btn <?php echo (isset($attendanceRecords[$student['id']]) && $attendanceRecords[$student['id']] === 'present') ? 'active' : ''; ?>"
                                                        data-student-id="<?php echo $student['id']; ?>"
                                                        data-class-id="<?php echo $selectedClassId; ?>"
                                                        data-status="present"
                                                        data-date="<?php echo $selectedDate; ?>"
                                                        onclick="setAttendance(this, <?php echo $student['id']; ?>, 'present')">
                                                    Present
                                                </button>
                                            </td>
                                            <td>
                                                <button type="button" class="attendance-btn <?php echo (isset($attendanceRecords[$student['id']]) && $attendanceRecords[$student['id']] === 'late') ? 'active' : ''; ?>"
                                                        data-student-id="<?php echo $student['id']; ?>"
                                                        data-class-id="<?php echo $selectedClassId; ?>"
                                                        data-status="late"
                                                        data-date="<?php echo $selectedDate; ?>"
                                                        onclick="setAttendance(this, <?php echo $student['id']; ?>, 'late')">
                                                    Late
                                                </button>
                                            </td>
                                            <td>
                                                <button type="button" class="attendance-btn <?php echo (isset($attendanceRecords[$student['id']]) && $attendanceRecords[$student['id']] === 'absent') ? 'active' : ''; ?>"
                                                        data-student-id="<?php echo $student['id']; ?>"
                                                        data-class-id="<?php echo $selectedClassId; ?>"
                                                        data-status="absent"
                                                        data-date="<?php echo $selectedDate; ?>"
                                                        onclick="setAttendance(this, <?php echo $student['id']; ?>, 'absent')">
                                                    Absent
                                                </button>
                                            </td>
                                            <td>
                                                <span class="attendance-status <?php echo isset($attendanceRecords[$student['id']]) ? $attendanceRecords[$student['id']] : ''; ?>"
                                                        data-student-id="<?php echo $student['id']; ?>"
                                                        data-date="<?php echo $selectedDate; ?>">
                                                    <?php
                                                        if (isset($attendanceRecords[$student['id']])) {
                                                            echo ucfirst($attendanceRecords[$student['id']]);
                                                        } else {
                                                            echo 'Not marked';
                                                        }
                                                    ?>
                                                </span>
                                                <input type="hidden" name="status[<?php echo $student['id']; ?>]" id="status_<?php echo $student['id']; ?>"
                                                       value="<?php echo isset($attendanceRecords[$student['id']]) ? $attendanceRecords[$student['id']] : ''; ?>">
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>

                            <div class="form-actions" style="margin-top: 15px;">
                                <button type="submit" class="btn-primary">Save Attendance</button>
                            </div>
                        </form>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </main>
    </div>

    <footer class="footer">
        <p>© <?php echo date('Y'); ?> EduBridge - A Smart Classroom Management System</p>
    </footer>

    <script>
        function setAttendance(button, studentId, status) {
            const buttons = document.querySelectorAll(`.attendance-btn[data-student-id="${studentId}"][data-date="${button.getAttribute('data-date')}"]`);
            buttons.forEach(btn => {
                btn.classList.remove('active');
            });

            button.classList.add('active');
            document.getElementById(`status_${studentId}`).value = status;

            const statusText = document.querySelector(`.attendance-status[data-student-id="${studentId}"][data-date="${button.getAttribute('data-date')}"]`);
            if (statusText) {
                statusText.textContent = status.charAt(0).toUpperCase() + status.slice(1);
                statusText.className = 'attendance-status ' + status;
            }
        }
    </script>
</body>
</html>