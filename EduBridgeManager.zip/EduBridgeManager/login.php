<?php
session_start();
require_once('includes/db_config.php');
require_once('includes/functions.php');
require_once('includes/auth.php');

// Check if already logged in
if (isLoggedIn()) {
    $userType = $_SESSION['user_type'];
    redirect($userType . '/dashboard.php');
}

// Get user type from URL parameter
$userType = isset($_GET['type']) ? sanitize($_GET['type']) : 'student';
$userType = ($userType === 'teacher') ? 'teacher' : 'student';

$error = '';

// Process login form
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = sanitize($_POST['username']);
    $password = $_POST['password'];
    
    if (empty($username) || empty($password)) {
        $error = "Username and password are required";
    } else {
        try {
            $pdo = getDbConnection();
            $stmt = $pdo->prepare("SELECT id, username, password, first_name, last_name FROM {$userType}s WHERE username = :username OR email = :email");
            $stmt->execute([
                'username' => $username,
                'email' => $username
            ]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($user && password_verify($password, $user['password'])) {
                // Login successful
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['name'] = $user['first_name'] . ' ' . $user['last_name'];
                $_SESSION['user_type'] = $userType;
                
                redirect($userType . '/dashboard.php');
            } else {
                $error = "Invalid username or password";
            }
        } catch (PDOException $e) {
            $error = "Database error: " . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo ucfirst($userType); ?> Login - EduBridge</title>
    <link rel="stylesheet" href="css/style.css">
    <meta name="description" content="Login to your EduBridge <?php echo $userType; ?> account">
</head>
<body>
    <div class="auth-container">
        <header>
            <div class="logo-container">
                <h1>EduBridge</h1>
            </div>
            <p class="tagline">A Smart Classroom Management System</p>
        </header>
        
        <main class="auth-form-container">
            <section class="auth-image">
                <?php if ($userType === 'student'): ?>
                    <img src="https://images.unsplash.com/photo-1514369118554-e20d93546b30" alt="Student studying" class="responsive-img">
                <?php else: ?>
                    <img src="https://images.unsplash.com/photo-1524178232363-1fb2b075b655" alt="Teacher at classroom" class="responsive-img">
                <?php endif; ?>
            </section>
            
            <section class="auth-form">
                <h2><?php echo ucfirst($userType); ?> Login</h2>
                
                <?php if (!empty($error)): ?>
                    <div class="error-message">
                        <?php echo $error; ?>
                    </div>
                <?php endif; ?>
                
                <form method="post" action="login.php?type=<?php echo $userType; ?>">
                    <div class="form-group">
                        <label for="username">Email / Username</label>
                        <input type="text" id="username" name="username" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="password">Password</label>
                        <input type="password" id="password" name="password" required>
                    </div>
                    
                    <div class="form-actions">
                        <button type="submit" class="btn-primary">Login</button>
                    </div>
                </form>
                
                <div class="auth-links">
                    <p>Don't have an account? <a href="signup.php?type=<?php echo $userType; ?>">Sign Up</a></p>
                    <p><a href="portal.html">Back to Portal Selection</a></p>
                </div>
            </section>
        </main>
        
        <footer>
            <p>&copy; 2023 EduBridge - A Smart Classroom Management System</p>
        </footer>
    </div>
    
    <script src="js/main.js"></script>
</body>
</html>
