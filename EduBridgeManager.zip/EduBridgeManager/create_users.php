<?php
/**
 * Script to create dummy users for testing directly via command line
 */

require_once('includes/db_config.php');
require_once('includes/functions.php');

// Create dummy student user
function createDummyStudent() {
    try {
        $pdo = getDbConnection();
        
        // Check if the user already exists
        $stmt = $pdo->prepare("SELECT id FROM students WHERE username = :username OR email = :email");
        $stmt->execute([
            'username' => 'student1',
            'email' => 'student1@example.com'
        ]);
        
        if ($stmt->rowCount() > 0) {
            echo "Dummy student already exists!\n";
            return;
        }
        
        // Hash the password
        $hashedPassword = password_hash('password123', PASSWORD_DEFAULT);
        
        // Insert new user
        $stmt = $pdo->prepare(
            "INSERT INTO students (
                first_name, last_name, gender, dob, cnic, nationality, 
                email, username, password, qualification, department, 
                address, phone, postal_code, city, country, 
                father_name, father_cnic, blood_group
            ) VALUES (
                :first_name, :last_name, :gender, :dob, :cnic, :nationality, 
                :email, :username, :password, :qualification, :department, 
                :address, :phone, :postal_code, :city, :country, 
                :father_name, :father_cnic, :blood_group
            )"
        );
        
        $stmt->execute([
            'first_name' => 'Test',
            'last_name' => 'Student',
            'gender' => 'Male',
            'dob' => '2000-01-01',
            'cnic' => '12345-1234567-1',
            'nationality' => 'Pakistani',
            'email' => 'student1@example.com',
            'username' => 'student1',
            'password' => $hashedPassword,
            'qualification' => 'BS',
            'department' => 'Computer Science',
            'address' => '123 Test Street',
            'phone' => '123-456-7890',
            'postal_code' => '12345',
            'city' => 'Karachi',
            'country' => 'Pakistan',
            'father_name' => 'Father Name',
            'father_cnic' => '12345-1234567-2',
            'blood_group' => 'A+'
        ]);
        
        echo "Dummy student created successfully!\n";
    } catch (PDOException $e) {
        echo "Error creating dummy student: " . $e->getMessage() . "\n";
    }
}

// Create dummy teacher user
function createDummyTeacher() {
    try {
        $pdo = getDbConnection();
        
        // Check if the user already exists
        $stmt = $pdo->prepare("SELECT id FROM teachers WHERE username = :username OR email = :email");
        $stmt->execute([
            'username' => 'teacher1',
            'email' => 'teacher1@example.com'
        ]);
        
        if ($stmt->rowCount() > 0) {
            echo "Dummy teacher already exists!\n";
            return;
        }
        
        // Hash the password
        $hashedPassword = password_hash('password123', PASSWORD_DEFAULT);
        
        // Insert new user
        $stmt = $pdo->prepare(
            "INSERT INTO teachers (
                first_name, last_name, gender, dob, cnic, nationality, 
                email, username, password, qualification, department, 
                address, phone, postal_code, city, country, 
                father_name, father_cnic, blood_group
            ) VALUES (
                :first_name, :last_name, :gender, :dob, :cnic, :nationality, 
                :email, :username, :password, :qualification, :department, 
                :address, :phone, :postal_code, :city, :country, 
                :father_name, :father_cnic, :blood_group
            )"
        );
        
        $stmt->execute([
            'first_name' => 'Test',
            'last_name' => 'Teacher',
            'gender' => 'Female',
            'dob' => '1980-01-01',
            'cnic' => '12345-7654321-1',
            'nationality' => 'Pakistani',
            'email' => 'teacher1@example.com',
            'username' => 'teacher1',
            'password' => $hashedPassword,
            'qualification' => 'PhD',
            'department' => 'Computer Science',
            'address' => '456 Faculty Housing',
            'phone' => '987-654-3210',
            'postal_code' => '54321',
            'city' => 'Lahore',
            'country' => 'Pakistan',
            'father_name' => 'Teacher Father',
            'father_cnic' => '12345-7654321-2',
            'blood_group' => 'B+'
        ]);
        
        echo "Dummy teacher created successfully!\n";
    } catch (PDOException $e) {
        echo "Error creating dummy teacher: " . $e->getMessage() . "\n";
    }
}

// Create a class for the teacher
function createDummyClass() {
    try {
        $pdo = getDbConnection();
        
        // Get the teacher ID
        $stmt = $pdo->prepare("SELECT id FROM teachers WHERE username = :username");
        $stmt->execute(['username' => 'teacher1']);
        $teacher = $stmt->fetch();
        
        if (!$teacher) {
            echo "Teacher not found. Create a teacher first.\n";
            return;
        }
        
        // Check if the class already exists
        $stmt = $pdo->prepare("SELECT id FROM classes WHERE class_code = :class_code");
        $stmt->execute(['class_code' => 'CS101']);
        
        if ($stmt->rowCount() > 0) {
            echo "Dummy class already exists!\n";
            return;
        }
        
        // Insert new class
        $stmt = $pdo->prepare(
            "INSERT INTO classes (
                teacher_id, class_name, class_code, description, created_at
            ) VALUES (
                :teacher_id, :class_name, :class_code, :description, :created_at
            )"
        );
        
        $stmt->execute([
            'teacher_id' => $teacher['id'],
            'class_name' => 'Introduction to Computer Science',
            'class_code' => 'CS101',
            'description' => 'An introductory course to computer science principles',
            'created_at' => date('Y-m-d H:i:s')
        ]);
        
        echo "Dummy class created successfully!\n";
    } catch (PDOException $e) {
        echo "Error creating dummy class: " . $e->getMessage() . "\n";
    }
}

// Create student enrollment in class
function enrollStudentInClass() {
    try {
        $pdo = getDbConnection();
        
        // Get the student ID
        $stmt = $pdo->prepare("SELECT id FROM students WHERE username = :username");
        $stmt->execute(['username' => 'student1']);
        $student = $stmt->fetch();
        
        if (!$student) {
            echo "Student not found. Create a student first.\n";
            return;
        }
        
        // Get the class ID
        $stmt = $pdo->prepare("SELECT id FROM classes WHERE class_code = :class_code");
        $stmt->execute(['class_code' => 'CS101']);
        $class = $stmt->fetch();
        
        if (!$class) {
            echo "Class not found. Create a class first.\n";
            return;
        }
        
        // Check if the enrollment already exists
        $stmt = $pdo->prepare("SELECT id FROM class_enrollments WHERE class_id = :class_id AND student_id = :student_id");
        $stmt->execute([
            'class_id' => $class['id'],
            'student_id' => $student['id']
        ]);
        
        if ($stmt->rowCount() > 0) {
            echo "Student already enrolled in this class!\n";
            return;
        }
        
        // Insert new enrollment
        $stmt = $pdo->prepare(
            "INSERT INTO class_enrollments (
                class_id, student_id, enrolled_at
            ) VALUES (
                :class_id, :student_id, :enrolled_at
            )"
        );
        
        $stmt->execute([
            'class_id' => $class['id'],
            'student_id' => $student['id'],
            'enrolled_at' => date('Y-m-d H:i:s')
        ]);
        
        echo "Student enrolled in class successfully!\n";
    } catch (PDOException $e) {
        echo "Error enrolling student: " . $e->getMessage() . "\n";
    }
}

// Create some attendance records
function createAttendanceRecords() {
    try {
        $pdo = getDbConnection();
        
        // Get the student ID
        $stmt = $pdo->prepare("SELECT id FROM students WHERE username = :username");
        $stmt->execute(['username' => 'student1']);
        $student = $stmt->fetch();
        
        if (!$student) {
            echo "Student not found. Create a student first.\n";
            return;
        }
        
        // Get the class ID
        $stmt = $pdo->prepare("SELECT id FROM classes WHERE class_code = :class_code");
        $stmt->execute(['class_code' => 'CS101']);
        $class = $stmt->fetch();
        
        if (!$class) {
            echo "Class not found. Create a class first.\n";
            return;
        }
        
        // Get the teacher ID
        $stmt = $pdo->prepare("SELECT id FROM teachers WHERE username = :username");
        $stmt->execute(['username' => 'teacher1']);
        $teacher = $stmt->fetch();
        
        if (!$teacher) {
            echo "Teacher not found. Create a teacher first.\n";
            return;
        }
        
        // Create attendance for past 5 days
        $statuses = ['present', 'present', 'absent', 'late', 'present'];
        $count = 0;
        
        for ($i = 5; $i >= 1; $i--) {
            $date = date('Y-m-d', strtotime("-$i days"));
            
            // Check if attendance already exists for this date
            $stmt = $pdo->prepare("SELECT id FROM attendance WHERE class_id = :class_id AND student_id = :student_id AND date = :date");
            $stmt->execute([
                'class_id' => $class['id'],
                'student_id' => $student['id'],
                'date' => $date
            ]);
            
            if ($stmt->rowCount() > 0) {
                continue;
            }
            
            // Insert attendance record
            $stmt = $pdo->prepare(
                "INSERT INTO attendance (
                    class_id, student_id, date, status, recorded_by
                ) VALUES (
                    :class_id, :student_id, :date, :status, :recorded_by
                )"
            );
            
            $stmt->execute([
                'class_id' => $class['id'],
                'student_id' => $student['id'],
                'date' => $date,
                'status' => $statuses[$i - 1],
                'recorded_by' => $teacher['id']
            ]);
            
            $count++;
        }
        
        echo "$count attendance records created successfully!\n";
    } catch (PDOException $e) {
        echo "Error creating attendance records: " . $e->getMessage() . "\n";
    }
}

// Create some marks records
function createMarksRecords() {
    try {
        $pdo = getDbConnection();
        
        // Get the student ID
        $stmt = $pdo->prepare("SELECT id FROM students WHERE username = :username");
        $stmt->execute(['username' => 'student1']);
        $student = $stmt->fetch();
        
        if (!$student) {
            echo "Student not found. Create a student first.\n";
            return;
        }
        
        // Get the class ID
        $stmt = $pdo->prepare("SELECT id FROM classes WHERE class_code = :class_code");
        $stmt->execute(['class_code' => 'CS101']);
        $class = $stmt->fetch();
        
        if (!$class) {
            echo "Class not found. Create a class first.\n";
            return;
        }
        
        // Get the teacher ID
        $stmt = $pdo->prepare("SELECT id FROM teachers WHERE username = :username");
        $stmt->execute(['username' => 'teacher1']);
        $teacher = $stmt->fetch();
        
        if (!$teacher) {
            echo "Teacher not found. Create a teacher first.\n";
            return;
        }
        
        // Assignment data
        $assignments = [
            ['Quiz 1', 18, 20, '2025-04-01'],
            ['Assignment 1', 23, 25, '2025-04-05'],
            ['Midterm Exam', 38, 50, '2025-04-07'],
            ['Quiz 2', 15, 20, '2025-04-10']
        ];
        
        $count = 0;
        
        foreach ($assignments as $assignment) {
            // Check if mark already exists
            $stmt = $pdo->prepare("SELECT id FROM marks WHERE class_id = :class_id AND student_id = :student_id AND assignment_name = :assignment_name");
            $stmt->execute([
                'class_id' => $class['id'],
                'student_id' => $student['id'],
                'assignment_name' => $assignment[0]
            ]);
            
            if ($stmt->rowCount() > 0) {
                continue;
            }
            
            // Insert mark record
            $stmt = $pdo->prepare(
                "INSERT INTO marks (
                    class_id, student_id, assignment_name, marks_obtained, total_marks, date, recorded_by
                ) VALUES (
                    :class_id, :student_id, :assignment_name, :marks_obtained, :total_marks, :date, :recorded_by
                )"
            );
            
            $stmt->execute([
                'class_id' => $class['id'],
                'student_id' => $student['id'],
                'assignment_name' => $assignment[0],
                'marks_obtained' => $assignment[1],
                'total_marks' => $assignment[2],
                'date' => $assignment[3],
                'recorded_by' => $teacher['id']
            ]);
            
            $count++;
        }
        
        echo "$count marks records created successfully!\n";
    } catch (PDOException $e) {
        echo "Error creating marks records: " . $e->getMessage() . "\n";
    }
}

// Create some stream posts
function createStreamPosts() {
    try {
        $pdo = getDbConnection();
        
        // Get the class ID
        $stmt = $pdo->prepare("SELECT id FROM classes WHERE class_code = :class_code");
        $stmt->execute(['class_code' => 'CS101']);
        $class = $stmt->fetch();
        
        if (!$class) {
            echo "Class not found. Create a class first.\n";
            return;
        }
        
        // Get the teacher ID
        $stmt = $pdo->prepare("SELECT id FROM teachers WHERE username = :username");
        $stmt->execute(['username' => 'teacher1']);
        $teacher = $stmt->fetch();
        
        if (!$teacher) {
            echo "Teacher not found. Create a teacher first.\n";
            return;
        }
        
        // Post data
        $posts = [
            [
                'teacher_id' => $teacher['id'],
                'user_type' => 'teacher',
                'post_type' => 'announcement',
                'title' => 'Welcome to CS101',
                'content' => 'Welcome to Introduction to Computer Science! This course will cover the basic principles of computer science, algorithms, and programming.',
                'due_date' => null
            ],
            [
                'teacher_id' => $teacher['id'],
                'user_type' => 'teacher',
                'post_type' => 'assignment',
                'title' => 'Assignment 1: Algorithm Design',
                'content' => 'Design and analyze an efficient algorithm for finding the maximum value in an array. Submit a document explaining your approach and its time complexity.',
                'due_date' => date('Y-m-d H:i:s', strtotime('+7 days'))
            ],
            [
                'teacher_id' => $teacher['id'],
                'user_type' => 'teacher',
                'post_type' => 'material',
                'title' => 'Lecture Notes: Introduction to Algorithms',
                'content' => 'Attached are the lecture notes from our first class session on introduction to algorithms and their analysis.',
                'due_date' => null
            ]
        ];
        
        $count = 0;
        
        foreach ($posts as $post) {
            // Check if similar post already exists
            $stmt = $pdo->prepare("SELECT id FROM stream_posts WHERE class_id = :class_id AND title = :title");
            $stmt->execute([
                'class_id' => $class['id'],
                'title' => $post['title']
            ]);
            
            if ($stmt->rowCount() > 0) {
                continue;
            }
            
            // Insert post record
            $stmt = $pdo->prepare(
                "INSERT INTO stream_posts (
                    class_id, user_id, user_type, post_type, title, content, created_at, due_date
                ) VALUES (
                    :class_id, :user_id, :user_type, :post_type, :title, :content, :created_at, :due_date
                )"
            );
            
            $stmt->execute([
                'class_id' => $class['id'],
                'user_id' => $post['teacher_id'],
                'user_type' => $post['user_type'],
                'post_type' => $post['post_type'],
                'title' => $post['title'],
                'content' => $post['content'],
                'created_at' => date('Y-m-d H:i:s', strtotime('-' . rand(1, 5) . ' days')),
                'due_date' => $post['due_date']
            ]);
            
            $count++;
        }
        
        echo "$count stream posts created successfully!\n";
    } catch (PDOException $e) {
        echo "Error creating stream posts: " . $e->getMessage() . "\n";
    }
}

// Create an exam preparation entry
function createExamPreparation() {
    try {
        $pdo = getDbConnection();
        
        // Get the student ID
        $stmt = $pdo->prepare("SELECT id FROM students WHERE username = :username");
        $stmt->execute(['username' => 'student1']);
        $student = $stmt->fetch();
        
        if (!$student) {
            echo "Student not found. Create a student first.\n";
            return;
        }
        
        // Check if exam prep already exists
        $stmt = $pdo->prepare("SELECT id FROM exam_preparation WHERE student_id = :student_id AND title = :title");
        $stmt->execute([
            'student_id' => $student['id'],
            'title' => 'Midterm Preparation'
        ]);
        
        if ($stmt->rowCount() > 0) {
            echo "Exam preparation already exists!\n";
            return;
        }
        
        // Sample checkpoints as JSON
        $checkpoints = json_encode([
            ['title' => 'Algorithm Basics', 'completed' => true],
            ['title' => 'Data Structures Overview', 'completed' => true],
            ['title' => 'Time Complexity Analysis', 'completed' => false],
            ['title' => 'Sorting Algorithms', 'completed' => false],
            ['title' => 'Graph Algorithms', 'completed' => false]
        ]);
        
        // Insert exam preparation record
        $stmt = $pdo->prepare(
            "INSERT INTO exam_preparation (
                student_id, title, content, checkpoints, created_at
            ) VALUES (
                :student_id, :title, :content, :checkpoints, :created_at
            )"
        );
        
        $stmt->execute([
            'student_id' => $student['id'],
            'title' => 'Midterm Preparation',
            'content' => 'My notes for the upcoming midterm exam, covering algorithms, data structures, and complexity analysis.',
            'checkpoints' => $checkpoints,
            'created_at' => date('Y-m-d H:i:s')
        ]);
        
        echo "Exam preparation created successfully!\n";
    } catch (PDOException $e) {
        echo "Error creating exam preparation: " . $e->getMessage() . "\n";
    }
}

// Execute all functions to create the test data
echo "Creating dummy users and data...\n";
createDummyStudent();
createDummyTeacher();
createDummyClass();
enrollStudentInClass();
createAttendanceRecords();
createMarksRecords();
createStreamPosts();
createExamPreparation();
echo "Done!\n";

?>