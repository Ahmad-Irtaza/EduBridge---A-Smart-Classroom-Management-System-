<?php
/**
 * Script to create dummy users for testing
 */

require_once('includes/db_config.php');
require_once('includes/functions.php');

// Create dummy student user
function createDummyStudent() {
    try {
        $pdo = getDbConnection();
        
        // Check if the user already exists
        $stmt = $pdo->prepare("SELECT id FROM students WHERE username = :username OR email = :email");
        $stmt->execute([
            'username' => 'student1',
            'email' => 'student1@example.com'
        ]);
        
        if ($stmt->rowCount() > 0) {
            echo "<p>Dummy student already exists!</p>";
            return;
        }
        
        // Hash the password
        $hashedPassword = password_hash('password123', PASSWORD_DEFAULT);
        
        // Insert new user
        $stmt = $pdo->prepare(
            "INSERT INTO students (
                first_name, last_name, gender, dob, cnic, nationality, 
                email, username, password, qualification, department, 
                address, phone, postal_code, city, country, 
                father_name, father_cnic, blood_group
            ) VALUES (
                :first_name, :last_name, :gender, :dob, :cnic, :nationality, 
                :email, :username, :password, :qualification, :department, 
                :address, :phone, :postal_code, :city, :country, 
                :father_name, :father_cnic, :blood_group
            )"
        );
        
        $stmt->execute([
            'first_name' => 'Test',
            'last_name' => 'Student',
            'gender' => 'Male',
            'dob' => '2000-01-01',
            'cnic' => '12345-1234567-1',
            'nationality' => 'Pakistani',
            'email' => 'student1@example.com',
            'username' => 'student1',
            'password' => $hashedPassword,
            'qualification' => 'BS',
            'department' => 'Computer Science',
            'address' => '123 Test Street',
            'phone' => '123-456-7890',
            'postal_code' => '12345',
            'city' => 'Karachi',
            'country' => 'Pakistan',
            'father_name' => 'Father Name',
            'father_cnic' => '12345-1234567-2',
            'blood_group' => 'A+'
        ]);
        
        echo "<p>Dummy student created successfully!</p>";
    } catch (PDOException $e) {
        echo "<p>Error creating dummy student: " . $e->getMessage() . "</p>";
    }
}

// Create dummy teacher user
function createDummyTeacher() {
    try {
        $pdo = getDbConnection();
        
        // Check if the user already exists
        $stmt = $pdo->prepare("SELECT id FROM teachers WHERE username = :username OR email = :email");
        $stmt->execute([
            'username' => 'teacher1',
            'email' => 'teacher1@example.com'
        ]);
        
        if ($stmt->rowCount() > 0) {
            echo "<p>Dummy teacher already exists!</p>";
            return;
        }
        
        // Hash the password
        $hashedPassword = password_hash('password123', PASSWORD_DEFAULT);
        
        // Insert new user
        $stmt = $pdo->prepare(
            "INSERT INTO teachers (
                first_name, last_name, gender, dob, cnic, nationality, 
                email, username, password, qualification, department, 
                address, phone, postal_code, city, country, 
                father_name, father_cnic, blood_group
            ) VALUES (
                :first_name, :last_name, :gender, :dob, :cnic, :nationality, 
                :email, :username, :password, :qualification, :department, 
                :address, :phone, :postal_code, :city, :country, 
                :father_name, :father_cnic, :blood_group
            )"
        );
        
        $stmt->execute([
            'first_name' => 'Test',
            'last_name' => 'Teacher',
            'gender' => 'Female',
            'dob' => '1980-01-01',
            'cnic' => '12345-7654321-1',
            'nationality' => 'Pakistani',
            'email' => 'teacher1@example.com',
            'username' => 'teacher1',
            'password' => $hashedPassword,
            'qualification' => 'PhD',
            'department' => 'Computer Science',
            'address' => '456 Faculty Housing',
            'phone' => '987-654-3210',
            'postal_code' => '54321',
            'city' => 'Lahore',
            'country' => 'Pakistan',
            'father_name' => 'Teacher Father',
            'father_cnic' => '12345-7654321-2',
            'blood_group' => 'B+'
        ]);
        
        echo "<p>Dummy teacher created successfully!</p>";
    } catch (PDOException $e) {
        echo "<p>Error creating dummy teacher: " . $e->getMessage() . "</p>";
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Dummy Users - EduBridge</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        .dummy-container {
            max-width: 800px;
            margin: 2rem auto;
            padding: 2rem;
            background-color: #fff;
            border-radius: 0.5rem;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        .result {
            margin: 1rem 0;
            padding: 1rem;
            border-radius: 0.5rem;
            background-color: #f8f9fa;
        }
    </style>
</head>
<body>
    <div class="dummy-container">
        <h2>Create Dummy Users</h2>
        
        <div class="result">
            <h3>Create Dummy Student</h3>
            <?php 
            if (isset($_GET['create_student'])) {
                createDummyStudent();
            } else {
                echo '<p><a href="?create_student=1" class="btn-primary">Create Dummy Student</a></p>';
            }
            ?>
        </div>
        
        <div class="result">
            <h3>Create Dummy Teacher</h3>
            <?php 
            if (isset($_GET['create_teacher'])) {
                createDummyTeacher();
            } else {
                echo '<p><a href="?create_teacher=1" class="btn-primary">Create Dummy Teacher</a></p>';
            }
            ?>
        </div>
        
        <div>
            <p><a href="index.html" class="btn-primary">Back to Home</a></p>
        </div>
    </div>
</body>
</html>