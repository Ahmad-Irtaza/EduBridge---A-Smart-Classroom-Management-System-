<?php
/**
 * API endpoint for marks management
 */

session_start();
require_once('../includes/db_config.php');
require_once('../includes/functions.php');
require_once('../includes/auth.php');

// Ensure the user is logged in
if (!isLoggedIn()) {
    header('Content-Type: application/json');
    echo json_encode([
        'success' => false,
        'message' => 'Authentication required'
    ]);
    exit;
}

// Determine the action to perform
$action = isset($_GET['action']) ? $_GET['action'] : (isset($_POST['action']) ? $_POST['action'] : 'get');

switch ($action) {
    case 'get':
        getMarks();
        break;
    case 'add':
        addMarks();
        break;
    case 'update':
        updateMarks();
        break;
    case 'delete':
        deleteMarks();
        break;
    case 'get_student_marks':
        getStudentMarks();
        break;
    default:
        header('Content-Type: application/json');
        echo json_encode([
            'success' => false,
            'message' => 'Invalid action'
        ]);
        break;
}

/**
 * Get all marks for a class
 */
function getMarks() {
    if (!isTeacher()) {
        header('Content-Type: application/json');
        echo json_encode([
            'success' => false,
            'message' => 'Access denied'
        ]);
        return;
    }
    
    $classId = isset($_GET['class_id']) ? intval($_GET['class_id']) : 0;
    
    if ($classId <= 0) {
        header('Content-Type: application/json');
        echo json_encode([
            'success' => false,
            'message' => 'Invalid class ID'
        ]);
        return;
    }
    
    // Check if the class belongs to the teacher
    if (!isTeacherClass($classId, $_SESSION['user_id'])) {
        header('Content-Type: application/json');
        echo json_encode([
            'success' => false,
            'message' => 'You do not have access to this class'
        ]);
        return;
    }
    
    try {
        $pdo = getDbConnection();
        $stmt = $pdo->prepare("
            SELECT m.*, s.first_name, s.last_name
            FROM marks m
            JOIN students s ON m.student_id = s.id
            WHERE m.class_id = :class_id
            ORDER BY m.date DESC, s.last_name, s.first_name
        ");
        $stmt->execute(['class_id' => $classId]);
        
        $marks = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Format the marks data
        foreach ($marks as &$mark) {
            $mark['student_name'] = $mark['first_name'] . ' ' . $mark['last_name'];
            $mark['percentage'] = ($mark['marks_obtained'] / $mark['total_marks']) * 100;
            $mark['formatted_date'] = formatDate($mark['date']);
            
            // Remove unnecessary fields
            unset($mark['first_name'], $mark['last_name']);
        }
        
        header('Content-Type: application/json');
        echo json_encode([
            'success' => true,
            'marks' => $marks
        ]);
    } catch (PDOException $e) {
        header('Content-Type: application/json');
        echo json_encode([
            'success' => false,
            'message' => 'Database error: ' . $e->getMessage()
        ]);
    }
}

/**
 * Add marks for a student
 */
function addMarks() {
    if (!isTeacher()) {
        header('Content-Type: application/json');
        echo json_encode([
            'success' => false,
            'message' => 'Access denied'
        ]);
        return;
    }
    
    $classId = isset($_POST['class_id']) ? intval($_POST['class_id']) : 0;
    $studentId = isset($_POST['student_id']) ? intval($_POST['student_id']) : 0;
    $assignmentName = isset($_POST['assignment_name']) ? sanitize($_POST['assignment_name']) : '';
    $marksObtained = isset($_POST['marks_obtained']) ? floatval($_POST['marks_obtained']) : 0;
    $totalMarks = isset($_POST['total_marks']) ? floatval($_POST['total_marks']) : 0;
    $date = isset($_POST['date']) ? sanitize($_POST['date']) : date('Y-m-d');
    
    // Validate input
    if ($classId <= 0 || $studentId <= 0 || empty($assignmentName) || $marksObtained < 0 || $totalMarks <= 0) {
        header('Content-Type: application/json');
        echo json_encode([
            'success' => false,
            'message' => 'Invalid input data'
        ]);
        return;
    }
    
    // Check if marks obtained is greater than total marks
    if ($marksObtained > $totalMarks) {
        header('Content-Type: application/json');
        echo json_encode([
            'success' => false,
            'message' => 'Marks obtained cannot be greater than total marks'
        ]);
        return;
    }
    
    // Check if the class belongs to the teacher
    if (!isTeacherClass($classId, $_SESSION['user_id'])) {
        header('Content-Type: application/json');
        echo json_encode([
            'success' => false,
            'message' => 'You do not have access to this class'
        ]);
        return;
    }
    
    // Check if the student is enrolled in the class
    if (!isStudentEnrolled($classId, $studentId)) {
        header('Content-Type: application/json');
        echo json_encode([
            'success' => false,
            'message' => 'Student is not enrolled in this class'
        ]);
        return;
    }
    
    try {
        $pdo = getDbConnection();
        $stmt = $pdo->prepare("
            INSERT INTO marks (class_id, student_id, assignment_name, marks_obtained, total_marks, date, recorded_by)
            VALUES (:class_id, :student_id, :assignment_name, :marks_obtained, :total_marks, :date, :recorded_by)
        ");
        
        $result = $stmt->execute([
            'class_id' => $classId,
            'student_id' => $studentId,
            'assignment_name' => $assignmentName,
            'marks_obtained' => $marksObtained,
            'total_marks' => $totalMarks,
            'date' => $date,
            'recorded_by' => $_SESSION['user_id']
        ]);
        
        if ($result) {
            // Get the marks table HTML to return
            ob_start();
            $allMarks = getAllMarks($classId);
            if (empty($allMarks)) {
                echo '<tr><td colspan="7" class="empty-table">No marks recorded yet</td></tr>';
            } else {
                foreach ($allMarks as $mark) {
                    $percentage = ($mark['marks_obtained'] / $mark['total_marks']) * 100;
                    ?>
                    <tr>
                        <td><?php echo htmlspecialchars($mark['first_name'] . ' ' . $mark['last_name']); ?></td>
                        <td><?php echo htmlspecialchars($mark['assignment_name']); ?></td>
                        <td><?php echo number_format($mark['marks_obtained'], 2); ?></td>
                        <td><?php echo number_format($mark['total_marks'], 2); ?></td>
                        <td class="<?php echo ($percentage < 60) ? 'text-danger' : 'text-success'; ?>">
                            <?php echo number_format($percentage, 2); ?>%
                        </td>
                        <td><?php echo formatDate($mark['date']); ?></td>
                        <td>
                            <div class="table-actions">
                                <button class="table-btn" data-modal="editMarksModal" 
                                        data-id="<?php echo $mark['id']; ?>"
                                        data-student="<?php echo $mark['student_id']; ?>"
                                        data-assignment="<?php echo htmlspecialchars($mark['assignment_name']); ?>"
                                        data-obtained="<?php echo $mark['marks_obtained']; ?>"
                                        data-total="<?php echo $mark['total_marks']; ?>"
                                        data-date="<?php echo $mark['date']; ?>">
                                    Edit
                                </button>
                                <button class="table-btn table-btn-danger" data-modal="deleteMarksModal" data-id="<?php echo $mark['id']; ?>">
                                    Delete
                                </button>
                            </div>
                        </td>
                    </tr>
                    <?php
                }
            }
            $marksHtml = ob_get_clean();
            
            header('Content-Type: application/json');
            echo json_encode([
                'success' => true,
                'message' => 'Marks added successfully',
                'marksHtml' => $marksHtml
            ]);
        } else {
            header('Content-Type: application/json');
            echo json_encode([
                'success' => false,
                'message' => 'Failed to add marks'
            ]);
        }
    } catch (PDOException $e) {
        header('Content-Type: application/json');
        echo json_encode([
            'success' => false,
            'message' => 'Database error: ' . $e->getMessage()
        ]);
    }
}

/**
 * Update marks for a student
 */
function updateMarks() {
    if (!isTeacher()) {
        header('Content-Type: application/json');
        echo json_encode([
            'success' => false,
            'message' => 'Access denied'
        ]);
        return;
    }
    
    $markId = isset($_POST['mark_id']) ? intval($_POST['mark_id']) : 0;
    $studentId = isset($_POST['student_id']) ? intval($_POST['student_id']) : 0;
    $assignmentName = isset($_POST['assignment_name']) ? sanitize($_POST['assignment_name']) : '';
    $marksObtained = isset($_POST['marks_obtained']) ? floatval($_POST['marks_obtained']) : 0;
    $totalMarks = isset($_POST['total_marks']) ? floatval($_POST['total_marks']) : 0;
    $date = isset($_POST['date']) ? sanitize($_POST['date']) : date('Y-m-d');
    
    // Validate input
    if ($markId <= 0 || $studentId <= 0 || empty($assignmentName) || $marksObtained < 0 || $totalMarks <= 0) {
        header('Content-Type: application/json');
        echo json_encode([
            'success' => false,
            'message' => 'Invalid input data'
        ]);
        return;
    }
    
    // Check if marks obtained is greater than total marks
    if ($marksObtained > $totalMarks) {
        header('Content-Type: application/json');
        echo json_encode([
            'success' => false,
            'message' => 'Marks obtained cannot be greater than total marks'
        ]);
        return;
    }
    
    try {
        $pdo = getDbConnection();
        
        // First, get the mark to check if it belongs to a class taught by this teacher
        $stmt = $pdo->prepare("
            SELECT m.class_id, c.teacher_id 
            FROM marks m
            JOIN classes c ON m.class_id = c.id
            WHERE m.id = :mark_id
        ");
        $stmt->execute(['mark_id' => $markId]);
        $mark = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$mark) {
            header('Content-Type: application/json');
            echo json_encode([
                'success' => false,
                'message' => 'Mark not found'
            ]);
            return;
        }
        
        // Check if the teacher is authorized to update this mark
        if ($mark['teacher_id'] != $_SESSION['user_id']) {
            header('Content-Type: application/json');
            echo json_encode([
                'success' => false,
                'message' => 'You are not authorized to update this mark'
            ]);
            return;
        }
        
        // Check if the student is enrolled in the class
        if (!isStudentEnrolled($mark['class_id'], $studentId)) {
            header('Content-Type: application/json');
            echo json_encode([
                'success' => false,
                'message' => 'Student is not enrolled in this class'
            ]);
            return;
        }
        
        // Update the mark
        $stmt = $pdo->prepare("
            UPDATE marks
            SET student_id = :student_id,
                assignment_name = :assignment_name,
                marks_obtained = :marks_obtained,
                total_marks = :total_marks,
                date = :date
            WHERE id = :mark_id
        ");
        
        $result = $stmt->execute([
            'student_id' => $studentId,
            'assignment_name' => $assignmentName,
            'marks_obtained' => $marksObtained,
            'total_marks' => $totalMarks,
            'date' => $date,
            'mark_id' => $markId
        ]);
        
        if ($result) {
            header('Content-Type: application/json');
            echo json_encode([
                'success' => true,
                'message' => 'Marks updated successfully'
            ]);
        } else {
            header('Content-Type: application/json');
            echo json_encode([
                'success' => false,
                'message' => 'Failed to update marks'
            ]);
        }
    } catch (PDOException $e) {
        header('Content-Type: application/json');
        echo json_encode([
            'success' => false,
            'message' => 'Database error: ' . $e->getMessage()
        ]);
    }
}

/**
 * Delete marks
 */
function deleteMarks() {
    if (!isTeacher()) {
        header('Content-Type: application/json');
        echo json_encode([
            'success' => false,
            'message' => 'Access denied'
        ]);
        return;
    }
    
    $markId = isset($_POST['mark_id']) ? intval($_POST['mark_id']) : 0;
    
    if ($markId <= 0) {
        header('Content-Type: application/json');
        echo json_encode([
            'success' => false,
            'message' => 'Invalid mark ID'
        ]);
        return;
    }
    
    try {
        $pdo = getDbConnection();
        
        // First, get the mark to check if it belongs to a class taught by this teacher
        $stmt = $pdo->prepare("
            SELECT m.class_id, c.teacher_id 
            FROM marks m
            JOIN classes c ON m.class_id = c.id
            WHERE m.id = :mark_id
        ");
        $stmt->execute(['mark_id' => $markId]);
        $mark = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$mark) {
            header('Content-Type: application/json');
            echo json_encode([
                'success' => false,
                'message' => 'Mark not found'
            ]);
            return;
        }
        
        // Check if the teacher is authorized to delete this mark
        if ($mark['teacher_id'] != $_SESSION['user_id']) {
            header('Content-Type: application/json');
            echo json_encode([
                'success' => false,
                'message' => 'You are not authorized to delete this mark'
            ]);
            return;
        }
        
        // Delete the mark
        $stmt = $pdo->prepare("DELETE FROM marks WHERE id = :mark_id");
        $result = $stmt->execute(['mark_id' => $markId]);
        
        if ($result) {
            header('Content-Type: application/json');
            echo json_encode([
                'success' => true,
                'message' => 'Mark deleted successfully'
            ]);
        } else {
            header('Content-Type: application/json');
            echo json_encode([
                'success' => false,
                'message' => 'Failed to delete mark'
            ]);
        }
    } catch (PDOException $e) {
        header('Content-Type: application/json');
        echo json_encode([
            'success' => false,
            'message' => 'Database error: ' . $e->getMessage()
        ]);
    }
}

/**
 * Get marks for a specific student
 */
function getStudentMarks() {
    if (!isLoggedIn()) {
        header('Content-Type: application/json');
        echo json_encode([
            'success' => false,
            'message' => 'Authentication required'
        ]);
        return;
    }
    
    $classId = isset($_GET['class_id']) ? intval($_GET['class_id']) : 0;
    $studentId = isset($_GET['student_id']) ? intval($_GET['student_id']) : 0;
    
    // If no student ID is provided, use the current user's ID (only for students)
    if ($studentId <= 0 && isStudent()) {
        $studentId = $_SESSION['user_id'];
    }
    
    if ($classId <= 0 || $studentId <= 0) {
        header('Content-Type: application/json');
        echo json_encode([
            'success' => false,
            'message' => 'Invalid class ID or student ID'
        ]);
        return;
    }
    
    // Check if the user is authorized to view these marks
    $isAuthorized = false;
    
    if (isStudent() && $studentId == $_SESSION['user_id'] && isStudentEnrolled($classId, $studentId)) {
        $isAuthorized = true; // Student viewing their own marks
    } else if (isTeacher() && isTeacherClass($classId, $_SESSION['user_id']) && isStudentEnrolled($classId, $studentId)) {
        $isAuthorized = true; // Teacher viewing marks of a student in their class
    }
    
    if (!$isAuthorized) {
        header('Content-Type: application/json');
        echo json_encode([
            'success' => false,
            'message' => 'You are not authorized to view these marks'
        ]);
        return;
    }
    
    try {
        $marks = getStudentMarksForClass($classId, $studentId);
        $summary = getStudentTotalMarks($classId, $studentId);
        
        header('Content-Type: application/json');
        echo json_encode([
            'success' => true,
            'marks' => $marks,
            'summary' => $summary
        ]);
    } catch (PDOException $e) {
        header('Content-Type: application/json');
        echo json_encode([
            'success' => false,
            'message' => 'Database error: ' . $e->getMessage()
        ]);
    }
}

/**
 * Helper function to get all marks for a class
 * 
 * @param int $classId Class ID
 * @return array Marks data
 */
function getAllMarks($classId) {
    try {
        $pdo = getDbConnection();
        $stmt = $pdo->prepare("
            SELECT m.*, s.first_name, s.last_name
            FROM marks m
            JOIN students s ON m.student_id = s.id
            WHERE m.class_id = :class_id
            ORDER BY m.date DESC, s.last_name, s.first_name
        ");
        $stmt->execute(['class_id' => $classId]);
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        return [];
    }
}

/**
 * Helper function to get marks for a specific student in a class
 * 
 * @param int $classId Class ID
 * @param int $studentId Student ID
 * @return array Marks data
 */
function getStudentMarksForClass($classId, $studentId) {
    try {
        $pdo = getDbConnection();
        $stmt = $pdo->prepare("
            SELECT * FROM marks
            WHERE class_id = :class_id AND student_id = :student_id
            ORDER BY date DESC
        ");
        $stmt->execute([
            'class_id' => $classId,
            'student_id' => $studentId
        ]);
        
        $marks = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Add additional info to each mark
        foreach ($marks as &$mark) {
            $mark['percentage'] = ($mark['marks_obtained'] / $mark['total_marks']) * 100;
            $mark['formatted_date'] = formatDate($mark['date']);
        }
        
        return $marks;
    } catch (PDOException $e) {
        return [];
    }
}
