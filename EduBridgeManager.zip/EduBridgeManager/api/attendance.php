<?php
/**
 * API endpoint for attendance management
 */

session_start();
require_once('../includes/db_config.php');
require_once('../includes/functions.php');
require_once('../includes/auth.php');

// Ensure the user is logged in
if (!isLoggedIn()) {
    header('Content-Type: application/json');
    echo json_encode([
        'success' => false,
        'message' => 'Authentication required'
    ]);
    exit;
}

// Determine the action to perform
$action = isset($_GET['action']) ? $_GET['action'] : (isset($_POST['action']) ? $_POST['action'] : '');

// Default action is mark attendance if POST request with student_id is sent
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['student_id']) && empty($action)) {
    $action = 'mark';
}

switch ($action) {
    case 'mark':
        markAttendance();
        break;
    case 'get':
        getAttendance();
        break;
    case 'get_class_attendance':
        getClassAttendance();
        break;
    case 'get_student_attendance':
        getStudentAttendance();
        break;
    case 'delete':
        deleteAttendance();
        break;
    default:
        header('Content-Type: application/json');
        echo json_encode([
            'success' => false,
            'message' => 'Invalid action'
        ]);
        break;
}

/**
 * Mark attendance for a student
 */
function markAttendance() {
    if (!isTeacher()) {
        header('Content-Type: application/json');
        echo json_encode([
            'success' => false,
            'message' => 'Access denied'
        ]);
        return;
    }
    
    $studentId = isset($_POST['student_id']) ? intval($_POST['student_id']) : 0;
    $classId = isset($_POST['class_id']) ? intval($_POST['class_id']) : 0;
    $status = isset($_POST['status']) ? sanitize($_POST['status']) : '';
    $date = isset($_POST['date']) ? sanitize($_POST['date']) : date('Y-m-d');
    
    // Validate input
    if ($studentId <= 0 || $classId <= 0 || empty($status)) {
        header('Content-Type: application/json');
        echo json_encode([
            'success' => false,
            'message' => 'Invalid input data'
        ]);
        return;
    }
    
    // Validate status
    if (!in_array($status, ['present', 'absent', 'late'])) {
        header('Content-Type: application/json');
        echo json_encode([
            'success' => false,
            'message' => 'Invalid status. Must be present, absent, or late.'
        ]);
        return;
    }
    
    // Check if the class belongs to the teacher
    if (!isTeacherClass($classId, $_SESSION['user_id'])) {
        header('Content-Type: application/json');
        echo json_encode([
            'success' => false,
            'message' => 'You do not have access to this class'
        ]);
        return;
    }
    
    // Check if the student is enrolled in the class
    if (!isStudentEnrolled($classId, $studentId)) {
        header('Content-Type: application/json');
        echo json_encode([
            'success' => false,
            'message' => 'Student is not enrolled in this class'
        ]);
        return;
    }
    
    try {
        $pdo = getDbConnection();
        
        // Check if attendance already exists for this student on this date
        $stmt = $pdo->prepare("
            SELECT id FROM attendance
            WHERE class_id = :class_id AND student_id = :student_id AND date = :date
        ");
        $stmt->execute([
            'class_id' => $classId,
            'student_id' => $studentId,
            'date' => $date
        ]);
        
        $existingAttendance = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($existingAttendance) {
            // Update existing attendance
            $stmt = $pdo->prepare("
                UPDATE attendance
                SET status = :status, recorded_by = :recorded_by
                WHERE id = :id
            ");
            
            $result = $stmt->execute([
                'status' => $status,
                'recorded_by' => $_SESSION['user_id'],
                'id' => $existingAttendance['id']
            ]);
        } else {
            // Insert new attendance
            $stmt = $pdo->prepare("
                INSERT INTO attendance (class_id, student_id, date, status, recorded_by)
                VALUES (:class_id, :student_id, :date, :status, :recorded_by)
            ");
            
            $result = $stmt->execute([
                'class_id' => $classId,
                'student_id' => $studentId,
                'date' => $date,
                'status' => $status,
                'recorded_by' => $_SESSION['user_id']
            ]);
        }
        
        if ($result) {
            header('Content-Type: application/json');
            echo json_encode([
                'success' => true,
                'message' => 'Attendance marked successfully',
                'student_id' => $studentId,
                'status' => $status,
                'date' => $date
            ]);
        } else {
            header('Content-Type: application/json');
            echo json_encode([
                'success' => false,
                'message' => 'Failed to mark attendance'
            ]);
        }
    } catch (PDOException $e) {
        header('Content-Type: application/json');
        echo json_encode([
            'success' => false,
            'message' => 'Database error: ' . $e->getMessage()
        ]);
    }
}

/**
 * Get attendance for a class on a specific date
 */
function getAttendance() {
    if (!isTeacher()) {
        header('Content-Type: application/json');
        echo json_encode([
            'success' => false,
            'message' => 'Access denied'
        ]);
        return;
    }
    
    $classId = isset($_GET['class_id']) ? intval($_GET['class_id']) : 0;
    $date = isset($_GET['date']) ? sanitize($_GET['date']) : date('Y-m-d');
    
    if ($classId <= 0) {
        header('Content-Type: application/json');
        echo json_encode([
            'success' => false,
            'message' => 'Invalid class ID'
        ]);
        return;
    }
    
    // Check if the class belongs to the teacher
    if (!isTeacherClass($classId, $_SESSION['user_id'])) {
        header('Content-Type: application/json');
        echo json_encode([
            'success' => false,
            'message' => 'You do not have access to this class'
        ]);
        return;
    }
    
    try {
        $pdo = getDbConnection();
        
        // Get all students enrolled in the class
        $stmt = $pdo->prepare("
            SELECT s.id, s.first_name, s.last_name
            FROM students s
            JOIN class_enrollments e ON s.id = e.student_id
            WHERE e.class_id = :class_id
            ORDER BY s.last_name, s.first_name
        ");
        $stmt->execute(['class_id' => $classId]);
        $students = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Get attendance records for the selected date
        $stmt = $pdo->prepare("
            SELECT a.student_id, a.status
            FROM attendance a
            WHERE a.class_id = :class_id AND a.date = :date
        ");
        $stmt->execute([
            'class_id' => $classId,
            'date' => $date
        ]);
        
        // Create a lookup array for attendance status
        $attendanceStatus = [];
        while ($record = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $attendanceStatus[$record['student_id']] = $record['status'];
        }
        
        // Combine student and attendance data
        $result = [];
        foreach ($students as $student) {
            $result[] = [
                'student_id' => $student['id'],
                'student_name' => $student['first_name'] . ' ' . $student['last_name'],
                'status' => isset($attendanceStatus[$student['id']]) ? $attendanceStatus[$student['id']] : null
            ];
        }
        
        header('Content-Type: application/json');
        echo json_encode([
            'success' => true,
            'date' => $date,
            'attendance' => $result
        ]);
    } catch (PDOException $e) {
        header('Content-Type: application/json');
        echo json_encode([
            'success' => false,
            'message' => 'Database error: ' . $e->getMessage()
        ]);
    }
}

/**
 * Get attendance for a class across all dates
 */
function getClassAttendance() {
    if (!isTeacher()) {
        header('Content-Type: application/json');
        echo json_encode([
            'success' => false,
            'message' => 'Access denied'
        ]);
        return;
    }
    
    $classId = isset($_GET['class_id']) ? intval($_GET['class_id']) : 0;
    
    if ($classId <= 0) {
        header('Content-Type: application/json');
        echo json_encode([
            'success' => false,
            'message' => 'Invalid class ID'
        ]);
        return;
    }
    
    // Check if the class belongs to the teacher
    if (!isTeacherClass($classId, $_SESSION['user_id'])) {
        header('Content-Type: application/json');
        echo json_encode([
            'success' => false,
            'message' => 'You do not have access to this class'
        ]);
        return;
    }
    
    try {
        $pdo = getDbConnection();
        
        // Get all attendance records for the class
        $stmt = $pdo->prepare("
            SELECT a.*, s.first_name, s.last_name
            FROM attendance a
            JOIN students s ON a.student_id = s.id
            WHERE a.class_id = :class_id
            ORDER BY a.date DESC, s.last_name, s.first_name
        ");
        $stmt->execute(['class_id' => $classId]);
        $attendance = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Format attendance data
        $formattedAttendance = [];
        foreach ($attendance as $record) {
            $formattedAttendance[] = [
                'id' => $record['id'],
                'student_id' => $record['student_id'],
                'student_name' => $record['first_name'] . ' ' . $record['last_name'],
                'date' => $record['date'],
                'formatted_date' => formatDate($record['date']),
                'status' => $record['status']
            ];
        }
        
        // Get attendance summary
        $stmt = $pdo->prepare("
            SELECT 
                COUNT(CASE WHEN status = 'present' THEN 1 END) as present_count,
                COUNT(CASE WHEN status = 'late' THEN 1 END) as late_count,
                COUNT(CASE WHEN status = 'absent' THEN 1 END) as absent_count,
                COUNT(*) as total_count
            FROM attendance
            WHERE class_id = :class_id
        ");
        $stmt->execute(['class_id' => $classId]);
        $summary = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // Get attendance by date
        $stmt = $pdo->prepare("
            SELECT date,
                COUNT(CASE WHEN status = 'present' THEN 1 END) as present_count,
                COUNT(CASE WHEN status = 'late' THEN 1 END) as late_count,
                COUNT(CASE WHEN status = 'absent' THEN 1 END) as absent_count,
                COUNT(*) as total_count
            FROM attendance
            WHERE class_id = :class_id
            GROUP BY date
            ORDER BY date DESC
        ");
        $stmt->execute(['class_id' => $classId]);
        $byDate = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Format date in the result
        foreach ($byDate as &$day) {
            $day['formatted_date'] = formatDate($day['date']);
        }
        
        header('Content-Type: application/json');
        echo json_encode([
            'success' => true,
            'attendance' => $formattedAttendance,
            'summary' => $summary,
            'by_date' => $byDate
        ]);
    } catch (PDOException $e) {
        header('Content-Type: application/json');
        echo json_encode([
            'success' => false,
            'message' => 'Database error: ' . $e->getMessage()
        ]);
    }
}

/**
 * Get attendance for a specific student
 */
function getStudentAttendance() {
    if (!isLoggedIn()) {
        header('Content-Type: application/json');
        echo json_encode([
            'success' => false,
            'message' => 'Authentication required'
        ]);
        return;
    }
    
    $classId = isset($_GET['class_id']) ? intval($_GET['class_id']) : 0;
    $studentId = isset($_GET['student_id']) ? intval($_GET['student_id']) : 0;
    
    // If no student ID is provided, use the current user's ID (only for students)
    if ($studentId <= 0 && isStudent()) {
        $studentId = $_SESSION['user_id'];
    }
    
    if ($classId <= 0 || $studentId <= 0) {
        header('Content-Type: application/json');
        echo json_encode([
            'success' => false,
            'message' => 'Invalid class ID or student ID'
        ]);
        return;
    }
    
    // Check if the user is authorized to view this attendance
    $isAuthorized = false;
    
    if (isStudent() && $studentId == $_SESSION['user_id'] && isStudentEnrolled($classId, $studentId)) {
        $isAuthorized = true; // Student viewing their own attendance
    } else if (isTeacher() && isTeacherClass($classId, $_SESSION['user_id']) && isStudentEnrolled($classId, $studentId)) {
        $isAuthorized = true; // Teacher viewing attendance of a student in their class
    }
    
    if (!$isAuthorized) {
        header('Content-Type: application/json');
        echo json_encode([
            'success' => false,
            'message' => 'You are not authorized to view this attendance'
        ]);
        return;
    }
    
    try {
        $pdo = getDbConnection();
        
        // Get all attendance records for the student in the class
        $stmt = $pdo->prepare("
            SELECT * FROM attendance
            WHERE class_id = :class_id AND student_id = :student_id
            ORDER BY date DESC
        ");
        $stmt->execute([
            'class_id' => $classId,
            'student_id' => $studentId
        ]);
        $attendance = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Format attendance data
        $formattedAttendance = [];
        foreach ($attendance as $record) {
            $formattedAttendance[] = [
                'id' => $record['id'],
                'date' => $record['date'],
                'formatted_date' => formatDate($record['date']),
                'status' => $record['status']
            ];
        }
        
        // Get attendance summary
        $summary = getStudentAttendanceSummary($classId, $studentId);
        
        header('Content-Type: application/json');
        echo json_encode([
            'success' => true,
            'attendance' => $formattedAttendance,
            'summary' => $summary
        ]);
    } catch (PDOException $e) {
        header('Content-Type: application/json');
        echo json_encode([
            'success' => false,
            'message' => 'Database error: ' . $e->getMessage()
        ]);
    }
}

/**
 * Delete attendance record
 */
function deleteAttendance() {
    if (!isTeacher()) {
        header('Content-Type: application/json');
        echo json_encode([
            'success' => false,
            'message' => 'Access denied'
        ]);
        return;
    }
    
    $attendanceId = isset($_POST['attendance_id']) ? intval($_POST['attendance_id']) : 0;
    
    if ($attendanceId <= 0) {
        header('Content-Type: application/json');
        echo json_encode([
            'success' => false,
            'message' => 'Invalid attendance ID'
        ]);
        return;
    }
    
    try {
        $pdo = getDbConnection();
        
        // First, get the attendance record to check if it belongs to a class taught by this teacher
        $stmt = $pdo->prepare("
            SELECT a.class_id, c.teacher_id 
            FROM attendance a
            JOIN classes c ON a.class_id = c.id
            WHERE a.id = :attendance_id
        ");
        $stmt->execute(['attendance_id' => $attendanceId]);
        $attendance = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$attendance) {
            header('Content-Type: application/json');
            echo json_encode([
                'success' => false,
                'message' => 'Attendance record not found'
            ]);
            return;
        }
        
        // Check if the teacher is authorized to delete this attendance record
        if ($attendance['teacher_id'] != $_SESSION['user_id']) {
            header('Content-Type: application/json');
            echo json_encode([
                'success' => false,
                'message' => 'You are not authorized to delete this attendance record'
            ]);
            return;
        }
        
        // Delete the attendance record
        $stmt = $pdo->prepare("DELETE FROM attendance WHERE id = :attendance_id");
        $result = $stmt->execute(['attendance_id' => $attendanceId]);
        
        if ($result) {
            header('Content-Type: application/json');
            echo json_encode([
                'success' => true,
                'message' => 'Attendance record deleted successfully'
            ]);
        } else {
            header('Content-Type: application/json');
            echo json_encode([
                'success' => false,
                'message' => 'Failed to delete attendance record'
            ]);
        }
    } catch (PDOException $e) {
        header('Content-Type: application/json');
        echo json_encode([
            'success' => false,
            'message' => 'Database error: ' . $e->getMessage()
        ]);
    }
}
