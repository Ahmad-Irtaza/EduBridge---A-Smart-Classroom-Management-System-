<?php
/**
 * Database connection test page
 */

require_once('includes/db_config.php');

// Try connecting to the database
try {
    $pdo = getDbConnection();
    $status = '<span style="color: green;">Connected to database successfully!</span>';
    
    // Check if tables exist
    $result = $pdo->query("SELECT EXISTS (
        SELECT FROM information_schema.tables 
        WHERE table_name = 'students'
    )");
    $tablesExist = $result->fetchColumn();
    
    if ($tablesExist) {
        $tables = '<span style="color: green;">Tables already exist</span>';
    } else {
        // Initialize database
        initializeDatabase($pdo);
        $tables = '<span style="color: blue;">Tables created successfully</span>';
    }
    
    // Get list of tables
    $stmt = $pdo->query("SELECT table_name FROM information_schema.tables WHERE table_schema = 'public'");
    $tableList = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
} catch (PDOException $e) {
    $status = '<span style="color: red;">Database connection failed: ' . $e->getMessage() . '</span>';
    $tables = '<span style="color: red;">Could not check or create tables</span>';
    $tableList = [];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Database Test - EduBridge</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        .test-container {
            max-width: 800px;
            margin: 2rem auto;
            padding: 2rem;
            background-color: #fff;
            border-radius: 0.5rem;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        .test-section {
            margin-bottom: 2rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid #eee;
        }
        h3 {
            margin-top: 0;
        }
        .table-list {
            list-style: none;
            padding: 0;
        }
        .table-list li {
            margin-bottom: 0.5rem;
            padding: 0.5rem;
            background-color: #f8f9fa;
            border-radius: 0.25rem;
        }
    </style>
</head>
<body>
    <div class="test-container">
        <h2>EduBridge Database Test</h2>
        
        <div class="test-section">
            <h3>Connection Status</h3>
            <p><?php echo $status; ?></p>
        </div>
        
        <div class="test-section">
            <h3>Tables Status</h3>
            <p><?php echo $tables; ?></p>
        </div>
        
        <?php if (!empty($tableList)): ?>
            <div class="test-section">
                <h3>Database Tables</h3>
                <ul class="table-list">
                    <?php foreach ($tableList as $table): ?>
                        <li><?php echo htmlspecialchars($table); ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>
        
        <div class="test-section">
            <a href="index.html" class="btn-primary">Back to Home</a>
        </div>
    </div>
</body>
</html>