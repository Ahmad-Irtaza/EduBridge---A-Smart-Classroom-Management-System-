<?php
/**
 * Stream Posts Management Module for EduBridge
 */

require_once __DIR__ . '/db.php';

/**
 * Create a new stream post
 *
 * @param int         $classId  ID of the class
 * @param int         $userId   ID of the user creating the post
 * @param string      $userType 'student' or 'teacher'
 * @param string      $postType One of: 'announcement', 'assignment', 'material', 'question'
 * @param string      $title    Post title
 * @param string      $content  Post content (HTML or plain text)
 * @param string|null $dueDate  Due date for assignments (or null)
 * @param string|null $filePath Path to uploaded attachment (or null)
 *
 * @return int|false Inserted post ID on success, false on failure
 */
function createStreamPost(
    int $classId,
    int $userId,
    string $userType,
    string $postType,
    string $title,
    string $content,
    ?string $dueDate = null,
    ?string $filePath = null
) {
    try {
        $pdo = getDbConnection();

        $sql = <<<SQL
INSERT INTO stream_posts
    (class_id, user_id, user_type, post_type, title, content, due_date, file_path)
VALUES
    (:class_id, :user_id, :user_type, :post_type, :title, :content, :due_date, :file_path)
SQL;

        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            'class_id'  => $classId,
            'user_id'   => $userId,
            'user_type' => $userType,
            'post_type' => $postType,
            'title'     => $title,
            'content'   => $content,
            'due_date'  => $dueDate,
            'file_path' => $filePath,
        ]);

        return (int)$pdo->lastInsertId();
    } catch (PDOException $e) {
        error_log('Error creating stream post: ' . $e->getMessage());
        return false;
    }
}

/**
 * Get all posts for a specific class
 * 
 * @param int $classId The ID of the class
 * @param string|null $postType Filter by post type (optional)
 * @param int $limit Number of posts to retrieve (optional)
 * @param int $offset Offset for pagination (optional)
 * @return array Array of posts
 */
function getClassPosts($classId, $postType = null, $limit = 10, $offset = 0) {
    try {
        $pdo = getDbConnection();
        
        $params = ['class_id' => $classId];
        $sql = "SELECT sp.*, 
                CASE 
                    WHEN sp.user_type = 'teacher' THEN 
                        (SELECT CONCAT(first_name, ' ', last_name) FROM teachers WHERE id = sp.user_id)
                    WHEN sp.user_type = 'student' THEN 
                        (SELECT CONCAT(first_name, ' ', last_name) FROM students WHERE id = sp.user_id)
                END as author_name
                FROM stream_posts sp
                WHERE sp.class_id = :class_id";
        
        if ($postType) {
            $sql .= " AND sp.post_type = :post_type";
            $params['post_type'] = $postType;
        }
        
        $sql .= " ORDER BY sp.created_at DESC LIMIT :limit OFFSET :offset";
        
        $stmt = $pdo->prepare($sql);
        
        // Bind limits separately to ensure they're treated as integers
        foreach ($params as $key => $value) {
            $stmt->bindValue($key, $value);
        }
        $stmt->bindValue(':limit', (int)$limit, PDO::PARAM_INT);
        $stmt->bindValue(':offset', (int)$offset, PDO::PARAM_INT);
        
        $stmt->execute();
        $posts = $stmt->fetchAll();
        
        // Get comment counts for each post
        foreach ($posts as &$post) {
            $post['comment_count'] = getCommentCount($post['id']);
            if ($post['post_type'] === 'assignment') {
                $post['submission_count'] = getSubmissionCount($post['id']);
            }
        }
        
        return $posts;
    } catch (PDOException $e) {
        error_log("Error retrieving class posts: " . $e->getMessage());
        return [];
    }
}

/**
 * Get a specific post by ID
 * 
 * @param int $postId The ID of the post
 * @return array|false Post details or false if not found
 */
function getPostById($postId) {
    try {
        $pdo = getDbConnection();
        
        $sql = "SELECT sp.*, 
                CASE 
                    WHEN sp.user_type = 'teacher' THEN 
                        (SELECT CONCAT(first_name, ' ', last_name) FROM teachers WHERE id = sp.user_id)
                    WHEN sp.user_type = 'student' THEN 
                        (SELECT CONCAT(first_name, ' ', last_name) FROM students WHERE id = sp.user_id)
                END as author_name
                FROM stream_posts sp
                WHERE sp.id = :post_id";
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute(['post_id' => $postId]);
        
        $post = $stmt->fetch();
        if ($post) {
            $post['comments'] = getPostComments($postId);
            if ($post['post_type'] === 'assignment') {
                $post['submissions'] = getAssignmentSubmissions($postId);
            }
        }
        
        return $post;
    } catch (PDOException $e) {
        error_log("Error retrieving post: " . $e->getMessage());
        return false;
    }
}

/**
 * Update an existing post
 * 
 * @param int $postId The ID of the post to update
 * @param string $title The updated title
 * @param string $content The updated content
 * @param string|null $dueDate The updated due date (for assignments)
 * @return bool True on success, false on failure
 */
function updatePost($postId, $title, $content, $dueDate = null) {
    try {
        $pdo = getDbConnection();
        
        $sql = "UPDATE stream_posts 
                SET title = :title, content = :content, due_date = :due_date
                WHERE id = :post_id";
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            'post_id' => $postId,
            'title' => $title,
            'content' => $content,
            'due_date' => $dueDate
        ]);
        
        return $stmt->rowCount() > 0;
    } catch (PDOException $e) {
        error_log("Error updating post: " . $e->getMessage());
        return false;
    }
}

/**
 * Delete a post
 * 
 * @param int $postId The ID of the post to delete
 * @param int $userId The ID of the user attempting to delete
 * @param string $userType The type of user ('student' or 'teacher')
 * @return bool True on success, false on failure
 */
function deletePost($postId, $userId, $userType) {
    try {
        $pdo = getDbConnection();
        
        // Begin transaction
        $pdo->beginTransaction();
        
        // First check if user has permission to delete the post
        $sql = "SELECT * FROM stream_posts WHERE id = :post_id";
        $stmt = $pdo->prepare($sql);
        $stmt->execute(['post_id' => $postId]);
        $post = $stmt->fetch();
        
        if (!$post) {
            $pdo->rollBack();
            return false;
        }
        
        // Only the creator or a teacher can delete a post
        if ($post['user_id'] != $userId && ($userType != 'teacher' || $post['user_type'] == 'teacher')) {
            $pdo->rollBack();
            return false;
        }
        
        // Delete related comments
        $stmt = $pdo->prepare("DELETE FROM stream_comments WHERE post_id = :post_id");
        $stmt->execute(['post_id' => $postId]);
        
        // Delete related assignment submissions if it's an assignment
        if ($post['post_type'] == 'assignment') {
            $stmt = $pdo->prepare("DELETE FROM assignment_submissions WHERE post_id = :post_id");
            $stmt->execute(['post_id' => $postId]);
        }
        
        // Delete the post
        $stmt = $pdo->prepare("DELETE FROM stream_posts WHERE id = :post_id");
        $stmt->execute(['post_id' => $postId]);
        
        // Commit transaction
        $pdo->commit();
        
        return true;
    } catch (PDOException $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        error_log("Error deleting post: " . $e->getMessage());
        return false;
    }
}

/**
 * Add a comment to a post
 * 
 * @param int $postId The ID of the post
 * @param int $userId The ID of the user adding the comment
 * @param string $userType The type of user ('student' or 'teacher')
 * @param string $comment The comment text
 * @return int|false The ID of the newly created comment or false on failure
 */
function addComment($postId, $userId, $userType, $comment) {
    try {
        $pdo = getDbConnection();
        
        $sql = "INSERT INTO stream_comments (post_id, user_id, user_type, comment) 
                VALUES (:post_id, :user_id, :user_type, :comment)";
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            'post_id' => $postId,
            'user_id' => $userId,
            'user_type' => $userType,
            'comment' => $comment
        ]);
        
        return $pdo->lastInsertId();
    } catch (PDOException $e) {
        error_log("Error adding comment: " . $e->getMessage());
        return false;
    }
}

/**
 * Get comments for a specific post
 * 
 * @param int $postId The ID of the post
 * @return array Array of comments
 */
function getPostComments($postId) {
    try {
        $pdo = getDbConnection();
        
        $sql = "SELECT sc.*, 
                CASE 
                    WHEN sc.user_type = 'teacher' THEN 
                        (SELECT CONCAT(first_name, ' ', last_name) FROM teachers WHERE id = sc.user_id)
                    WHEN sc.user_type = 'student' THEN 
                        (SELECT CONCAT(first_name, ' ', last_name) FROM students WHERE id = sc.user_id)
                END as author_name
                FROM stream_comments sc
                WHERE sc.post_id = :post_id
                ORDER BY sc.created_at ASC";
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute(['post_id' => $postId]);
        
        return $stmt->fetchAll();
    } catch (PDOException $e) {
        error_log("Error retrieving comments: " . $e->getMessage());
        return [];
    }
}

/**
 * Get comment count for a post
 * 
 * @param int $postId The ID of the post
 * @return int Number of comments
 */
function getCommentCount($postId) {
    try {
        $pdo = getDbConnection();
        
        $sql = "SELECT COUNT(*) FROM stream_comments WHERE post_id = :post_id";
        $stmt = $pdo->prepare($sql);
        $stmt->execute(['post_id' => $postId]);
        
        return (int)$stmt->fetchColumn();
    } catch (PDOException $e) {
        error_log("Error counting comments: " . $e->getMessage());
        return 0;
    }
}

/**
 * Delete a comment
 * 
 * @param int $commentId The ID of the comment to delete
 * @param int $userId The ID of the user attempting to delete
 * @param string $userType The type of user ('student' or 'teacher')
 * @return bool True on success, false on failure
 */
function deleteComment($commentId, $userId, $userType) {
    try {
        $pdo = getDbConnection();
        
        // First check if user has permission to delete the comment
        $sql = "SELECT * FROM stream_comments WHERE id = :comment_id";
        $stmt = $pdo->prepare($sql);
        $stmt->execute(['comment_id' => $commentId]);
        $comment = $stmt->fetch();
        
        if (!$comment) {
            return false;
        }
        
        // Check if user is the comment author or a teacher
        if ($comment['user_id'] != $userId && $userType != 'teacher') {
            return false;
        }
        
        // Delete the comment
        $stmt = $pdo->prepare("DELETE FROM stream_comments WHERE id = :comment_id");
        $stmt->execute(['comment_id' => $commentId]);
        
        return $stmt->rowCount() > 0;
    } catch (PDOException $e) {
        error_log("Error deleting comment: " . $e->getMessage());
        return false;
    }
}

/**
 * Add an assignment submission
 * 
 * @param int $postId The ID of the assignment post
 * @param int $studentId The ID of the student submitting
 * @param string $content The submission content
 * @return int|false The ID of the new submission or false on failure
 */
function addAssignmentSubmission($postId, $studentId, $content) {
    try {
        $pdo = getDbConnection();
        
        // Check if this is actually an assignment
        $stmt = $pdo->prepare("SELECT post_type FROM stream_posts WHERE id = :post_id");
        $stmt->execute(['post_id' => $postId]);
        $postType = $stmt->fetchColumn();
        
        if ($postType !== 'assignment') {
            return false;
        }
        
        // Check if student has already submitted (update if they have)
        $stmt = $pdo->prepare("SELECT id FROM assignment_submissions 
                              WHERE post_id = :post_id AND student_id = :student_id");
        $stmt->execute([
            'post_id' => $postId,
            'student_id' => $studentId
        ]);
        $existingId = $stmt->fetchColumn();
        
        if ($existingId) {
            $stmt = $pdo->prepare("UPDATE assignment_submissions 
                                  SET content = :content, submitted_at = CURRENT_TIMESTAMP 
                                  WHERE id = :id");
            $stmt->execute([
                'content' => $content,
                'id' => $existingId
            ]);
            
            return $existingId;
        } else {
            $stmt = $pdo->prepare("INSERT INTO assignment_submissions (post_id, student_id, content) 
                                  VALUES (:post_id, :student_id, :content)");
            $stmt->execute([
                'post_id' => $postId,
                'student_id' => $studentId,
                'content' => $content
            ]);
            
            return $pdo->lastInsertId();
        }
    } catch (PDOException $e) {
        error_log("Error adding assignment submission: " . $e->getMessage());
        return false;
    }
}

/**
 * Get student assignment submissions for a post
 * 
 * @param int $postId The ID of the assignment post
 * @return array Array of submissions
 */
function getAssignmentSubmissions($postId) {
    try {
        $pdo = getDbConnection();
        
        $sql = "SELECT as.*, CONCAT(s.first_name, ' ', s.last_name) as student_name
                FROM assignment_submissions as
                JOIN students s ON as.student_id = s.id
                WHERE as.post_id = :post_id
                ORDER BY as.submitted_at DESC";
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute(['post_id' => $postId]);
        
        return $stmt->fetchAll();
    } catch (PDOException $e) {
        error_log("Error retrieving assignment submissions: " . $e->getMessage());
        return [];
    }
}

/**
 * Get submission count for an assignment
 * 
 * @param int $postId The ID of the assignment post
 * @return int Number of submissions
 */
function getSubmissionCount($postId) {
    try {
        $pdo = getDbConnection();
        
        $sql = "SELECT COUNT(*) FROM assignment_submissions WHERE post_id = :post_id";
        $stmt = $pdo->prepare($sql);
        $stmt->execute(['post_id' => $postId]);
        
        return (int)$stmt->fetchColumn();
    } catch (PDOException $e) {
        error_log("Error counting submissions: " . $e->getMessage());
        return 0;
    }
}

/**
 * Grade an assignment submission
 * 
 * @param int $submissionId The ID of the submission
 * @param float $marksObtained The marks awarded
 * @param float $totalMarks The total possible marks
 * @param string $feedback Feedback for the student
 * @return bool True on success, false on failure
 */
function gradeSubmission($submissionId, $marksObtained, $totalMarks, $feedback) {
    try {
        $pdo = getDbConnection();
        
        $sql = "UPDATE assignment_submissions 
                SET marks_obtained = :marks_obtained, 
                    total_marks = :total_marks, 
                    feedback = :feedback
                WHERE id = :submission_id";
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            'submission_id' => $submissionId,
            'marks_obtained' => $marksObtained,
            'total_marks' => $totalMarks,
            'feedback' => $feedback
        ]);
        
        return $stmt->rowCount() > 0;
    } catch (PDOException $e) {
        error_log("Error grading submission: " . $e->getMessage());
        return false;
    }
}

/**
 * Get student's assignment submission
 * 
 * @param int $postId The ID of the assignment post
 * @param int $studentId The ID of the student
 * @return array|false Submission details or false if not found
 */
function getStudentSubmission($postId, $studentId) {
    try {
        $pdo = getDbConnection();
        
        $sql = "SELECT * FROM assignment_submissions 
                WHERE post_id = :post_id AND student_id = :student_id";
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            'post_id' => $postId,
            'student_id' => $studentId
        ]);
        
        return $stmt->fetch();
    } catch (PDOException $e) {
        error_log("Error retrieving student submission: " . $e->getMessage());
        return false;
    }
}

/**
 * Get a count of posts by type for a specific class
 * 
 * @param int $classId The ID of the class
 * @return array Counts by post type
 */
function getClassPostCounts($classId) {
    try {
        $pdo = getDbConnection();
        
        $sql = "SELECT post_type, COUNT(*) as count 
                FROM stream_posts 
                WHERE class_id = :class_id 
                GROUP BY post_type";
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute(['class_id' => $classId]);
        
        $results = $stmt->fetchAll();
        $counts = [
            'announcement' => 0,
            'assignment' => 0,
            'material' => 0,
            'question' => 0
        ];
        
        foreach ($results as $row) {
            $counts[$row['post_type']] = (int)$row['count'];
        }
        
        return $counts;
    } catch (PDOException $e) {
        error_log("Error counting posts: " . $e->getMessage());
        return [
            'announcement' => 0,
            'assignment' => 0,
            'material' => 0,
            'question' => 0
        ];
    }
}