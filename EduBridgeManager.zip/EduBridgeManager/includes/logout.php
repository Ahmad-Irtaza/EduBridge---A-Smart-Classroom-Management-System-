<?php
session_start();
require_once('functions.php');

// Unset all session variables
$_SESSION = [];

// Destroy the session
session_destroy();

// Redirect to the home page
redirect('../index.html');
    