        <footer class="dashboard-footer">
            <p>&copy; 2025 EduBridge - A Smart Classroom Management System</p>
        </footer>
    </div>
    
    <script src="../js/main.js"></script>
</body>
</html>
