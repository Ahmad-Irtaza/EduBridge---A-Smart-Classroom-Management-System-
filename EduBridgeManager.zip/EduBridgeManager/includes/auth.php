<?php
// auth.php

// bring in your global helpers (where redirect() lives)
require_once __DIR__ . '/functions.php';

/**
 * Check if user is logged in
 * 
 * @return bool User is logged in
 */
function isLoggedIn() {
    return isset($_SESSION['user_id']) && isset($_SESSION['user_type']);
}

/**
 * Check if user is a student
 * 
 * @return bool User is a student
 */
function isStudent() {
    return isLoggedIn() && $_SESSION['user_type'] === 'student';
}

/**
 * Check if user is a teacher
 * 
 * @return bool User is a teacher
 */
function isTeacher() {
    return isLoggedIn() && $_SESSION['user_type'] === 'teacher';
}

/**
 * Ensure user is logged in, redirect if not
 */
function requireLogin() {
    if (!isLoggedIn()) {
        $_SESSION['error'] = "You must be logged in to access that page";
        redirect('../login.php');
    }
}

/**
 * Ensure user is a student, redirect if not
 */
function requireStudent() {
    requireLogin();
    
    if (!isStudent()) {
        $_SESSION['error'] = "You must be a student to access that page";
        redirect('../login.php');
    }
}

/**
 * Ensure user is a teacher, redirect if not
 */
function requireTeacher() {
    requireLogin();
    
    if (!isTeacher()) {
        $_SESSION['error'] = "You must be a teacher to access that page";
        redirect('../login.php');
    }
}

/**
 * Log out user
 */
function logout() {
    // Unset all session variables
    $_SESSION = [];
    
    // Destroy the session
    session_destroy();
    
    // Redirect to login page
    redirect('../index.html');
}

/**
 * Get full user information based on session data
 * 
 * @return array User data or empty array if not found
 */
function getCurrentUserInfo() {
    if (!isLoggedIn()) {
        return [];
    }

    try {
        $pdo = getDbConnection();
        $userType = $_SESSION['user_type'];
        $userId = $_SESSION['user_id'];
        $table = $userType . 's'; // students or teachers
        
        $stmt = $pdo->prepare("SELECT * FROM {$table} WHERE id = :id");
        $stmt->execute(['id' => $userId]);
        return $stmt->fetch();
    } catch (PDOException $e) {
        error_log("Error fetching user info: " . $e->getMessage());
        return [];
    }
}
