<?php
// Start session and setup
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once('../includes/db_config.php');
require_once('../includes/functions.php');
require_once('../includes/auth.php');

// Get current page
$currentPage = basename($_SERVER['PHP_SELF']);

// Highlight active page in the sidebar
function isActive($page) {
    global $currentPage;
    return $currentPage === $page ? 'active' : '';
}

// Create default test post if stream is empty
if (isset($selectedClassId, $teacherId) && empty($streamPosts)) {
    $pdo = getDbConnection();
    $stmt = $pdo->prepare("
        INSERT INTO stream_posts (class_id, user_id, user_type, post_type, title, content, created_at)
        VALUES (:class_id, :user_id, :user_type, :post_type, :title, :content, datetime('now'))
    ");
    $stmt->execute([
        'class_id' => $selectedClassId,
        'user_id' => $teacherId,
        'user_type' => 'teacher',
        'post_type' => 'announcement',
        'title' => '🚀 Welcome to the Class!',
        'content' => 'This is a test post to confirm everything is working!'
    ]);

    // Re-fetch updated posts
    $streamPosts = getClassStreamPosts($selectedClassId);
}

// Display notifications
if (isset($_SESSION['success'])) {
    echo '<div class="notification success animate-fade-in">' . $_SESSION['success'] . '</div>';
    unset($_SESSION['success']);
}
if (isset($_SESSION['error'])) {
    echo '<div class="notification error animate-fade-in">' . $_SESSION['error'] . '</div>';
    unset($_SESSION['error']);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $pageTitle ?? 'EduBridge'; ?></title>
    <meta name="description" content="<?= $pageDescription ?? 'EduBridge - A Smart Classroom Management System'; ?>">
    <link rel="stylesheet" href="../css/style.css">
    <!-- Font Awesome is now optional to avoid conflicts -->
    <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"> -->
    <?php
      $p = basename($_SERVER['PHP_SELF']);
      if ($p === 'attendance.php' && ($_SESSION['user_type'] ?? '') === 'teacher') {
        echo '<link rel="stylesheet" href="../css/teacher-dark.css">';
      }
    ?>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        /* Header and Navigation Styles Only - Avoid affecting content */
        .dashboard-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1rem 2rem;
            background: linear-gradient(135deg,rgb(120, 86, 224) 0%,hsl(120, 86, 224) 100%);
            color: #ffffff;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }

        .logo-container {
            display: flex;
            align-items: center;
        }

        .logo-container h1 {
            font-size: 1.8rem;
            font-weight: 700;
            margin: 0;
            color: #ffffff;
            text-shadow: 0 1px 2px rgba(0,0,0,0.2);
            letter-spacing: 0.5px;
        }

        .logo-container h1:before {
            content: '📚';
            margin-right: 8px;
        }

        .user-menu {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .user-name {
            font-weight: 500;
        }

        .dropdown {
            position: relative;
            display: inline-block;
        }

        .dropdown-btn {
            background-color: rgba(255, 255, 255, 0.2);
            color: white;
            border: none;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .dropdown-btn:hover {
            background-color: rgba(255, 255, 255, 0.3);
        }

        .dropdown-content {
            display: none;
            position: absolute;
            right: 0;
            background-color: white;
            min-width: 180px;
            box-shadow: 0 10px 15px rgba(0,0,0,0.1);
            border-radius: 8px;
            overflow: hidden;
            z-index: 1;
        }

        .dropdown:hover .dropdown-content {
            display: block;
        }

        .dropdown-content a {
            color: #212529;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
        }

        .dropdown-content a:hover {
            background-color: #f5f7ff;
        }

        /* Notification styles - positioned relative to container */
        .notification {
            margin: 15px 0;
            padding: 12px 20px;
            border-radius: 8px;
            color: white;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }

        .success {
            background: #06d6a0;
            border-left: 4px solid #00896f;
        }

        .error {
            background: #ff6b6b;
            border-left: 4px solid #c0392b;
        }

        /* Responsive adjustments */
        @media (max-width: 768px) {
            .user-name {
                display: none;
            }

            .logo-container h1 {
                font-size: 1.5rem;
            }
        }
    </style>
</head>
<body>
    <header class="dashboard-header">
        <div class="logo-container">
            <h1>EduBridge</h1>
        </div>
        
        <div class="user-menu">
            <?php if (isset($_SESSION['name'])): ?>
                <span class="user-name">Hello, <?= htmlspecialchars($_SESSION['name']); ?></span>
            <?php endif; ?>
                
            <div class="dropdown">
                <button class="dropdown-btn">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                        <circle cx="12" cy="7" r="4"></circle>
                    </svg>
                </button>
                <div class="dropdown-content">
                    <a href="dashboard.php">Dashboard</a>
                    <a href="../includes/logout.php">Logout</a>
                </div>
            </div>
        </div>
    </header>
    <div class="dashboard-container">
        <!-- Original content will be displayed properly now -->