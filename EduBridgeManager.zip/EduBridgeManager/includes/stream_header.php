<?php
  if (session_status()===PHP_SESSION_NONE) session_start();
  // You must have $classDetails, $selectedClassId and $activeTab set before including
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title><?= htmlspecialchars($pageTitle ?? 'EduBridge') ?></title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <link rel="stylesheet" href="/assets/css/classroom.css">
</head>
<body>
  <div class="gc-container">
    <?php include __DIR__.'/sidebar.php'; ?>

    <div class="gc-main">
      <header class="gc-banner">
        <div class="gc-course-title">
          <?= htmlspecialchars($classDetails['class_name'] ?? 'Classroom') ?>
        </div>
        <div class="gc-course-code">
          Code: <?= htmlspecialchars($classDetails['class_code'] ?? '') ?>
        </div>
      </header>

      <nav class="gc-tabs">
        <a href="stream.php?class_id=<?= $selectedClassId ?>"
           class="<?= $activeTab==='stream'    ? 'active' : '' ?>">Stream</a>
        <a href="classwork.php?class_id=<?= $selectedClassId ?>"
           class="<?= $activeTab==='classwork' ? 'active' : '' ?>">Classwork</a>
        <a href="people.php?class_id=<?= $selectedClassId ?>"
           class="<?= $activeTab==='people'    ? 'active' : '' ?>">People</a>
        <a href="grades.php?class_id=<?= $selectedClassId ?>"
           class="<?= $activeTab==='grades'    ? 'active' : '' ?>">Grades</a>
      </nav>
