<?php
  $cid  = htmlspecialchars($_GET['class_id'] ?? '');
  $self = basename($_SERVER['PHP_SELF']);
?>
<nav class="class-nav">
  <a href="stream.php?class_id=<?= $cid ?>"
     class="<?= $self==='stream.php'?'active':'' ?>">
    Stream
  </a>
  <a href="classwork.php?class_id=<?= $cid ?>"
     class="<?= $self==='classwork.php'?'active':'' ?>">
    Classwork
  </a>
  <a href="people.php?class_id=<?= $cid ?>"
     class="<?= $self==='people.php'?'active':'' ?>">
    People
  </a>
  <a href="grades.php?class_id=<?= $cid ?>"
     class="<?= $self==='grades.php'?'active':'' ?>">
    Grades
  </a>
</nav>
