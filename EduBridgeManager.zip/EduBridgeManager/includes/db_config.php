<?php
/**
 * Database configuration and connection management
 */

// Define SQLite database file
define('DB_FILE', __DIR__ . '/../edubridge.db');

// PostgreSQL connection details from environment variables
$host = getenv('PGHOST');
$port = getenv('PGPORT');
$dbname = getenv('PGDATABASE');
$user = getenv('PGUSER');
$password = getenv('PGPASSWORD');

// Flag to determine which database to use
$usePostgres = (!empty($host) && !empty($port) && !empty($dbname) && !empty($user) && !empty($password));

/**
 * Get PDO database connection
 * 
 * @return PDO Database connection
 */
function getDbConnection() {
    static $pdo = null;
    
    if ($pdo === null) {
        global $usePostgres, $host, $port, $dbname, $user, $password;
        
        try {
            // Try PostgreSQL first if credentials are provided
            if ($usePostgres) {
                try {
                    // Create PostgreSQL PDO connection with SSL required
                    $dsn = "pgsql:host=$host;port=$port;dbname=$dbname;sslmode=require";
                    $pdo = new PDO($dsn, $user, $password);
                    
                    // Check if tables exist, if not create them
                    if (!pgTablesExist($pdo)) {
                        initializePgDatabase($pdo);
                    }
                } catch (PDOException $e) {
                    // If PostgreSQL fails, fall back to SQLite
                    error_log("PostgreSQL connection failed: " . $e->getMessage() . ". Falling back to SQLite.");
                    $pdo = null;
                }
            }
            
            // If PostgreSQL connection failed or not configured, use SQLite
            if ($pdo === null) {
                $createSchema = !file_exists(DB_FILE);
                $pdo = new PDO('sqlite:' . DB_FILE);
                
                // Set error mode
                $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
                
                // Create schema if database is new
                if ($createSchema) {
                    initializeSqliteDatabase($pdo);
                }
            }
        } catch (PDOException $e) {
            // Handle connection error
            die("Database connection failed: " . $e->getMessage());
        }
    }
    
    return $pdo;
}

/**
 * Check if tables exist in PostgreSQL database
 * 
 * @param PDO $pdo Database connection
 * @return bool True if tables exist, false otherwise
 */
function pgTablesExist($pdo) {
    try {
        $result = $pdo->query("SELECT EXISTS (
            SELECT FROM information_schema.tables 
            WHERE table_name = 'students'
        )");
        return $result->fetchColumn();
    } catch (PDOException $e) {
        return false;
    }
}

/**
 * Check if SQLite tables exist in the database
 * 
 * @param PDO $pdo Database connection
 * @return bool True if tables exist, false otherwise
 */
function tableExists($pdo, $tableName) {
    $stmt = $pdo->prepare("SELECT name FROM sqlite_master WHERE type='table' AND name=:tableName");
    $stmt->execute(['tableName' => $tableName]);
    return $stmt->fetchColumn() !== false;
}

/**
 * Initialize SQLite database with schema
 * 
 * @param PDO $pdo Database connection
 */
function initializeSqliteDatabase($pdo) {
    try {
        // Enable foreign key constraints
        $pdo->exec('PRAGMA foreign_keys = ON');
        
        // Create students table
        $pdo->exec("
            CREATE TABLE students (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                first_name TEXT NOT NULL,
                last_name TEXT NOT NULL,
                gender TEXT NOT NULL,
                dob TEXT NOT NULL,
                cnic TEXT NOT NULL,
                nationality TEXT NOT NULL,
                email TEXT NOT NULL UNIQUE,
                username TEXT NOT NULL UNIQUE,
                password TEXT NOT NULL,
                qualification TEXT NOT NULL,
                department TEXT NOT NULL,
                address TEXT NOT NULL,
                phone TEXT,
                postal_code TEXT NOT NULL,
                city TEXT NOT NULL,
                country TEXT NOT NULL,
                father_name TEXT NOT NULL,
                father_cnic TEXT NOT NULL,
                blood_group TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ");
        
        // Create teachers table
        $pdo->exec("
            CREATE TABLE teachers (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                first_name TEXT NOT NULL,
                last_name TEXT NOT NULL,
                gender TEXT NOT NULL,
                dob TEXT NOT NULL,
                cnic TEXT NOT NULL,
                nationality TEXT NOT NULL,
                email TEXT NOT NULL UNIQUE,
                username TEXT NOT NULL UNIQUE,
                password TEXT NOT NULL,
                qualification TEXT NOT NULL,
                department TEXT NOT NULL,
                address TEXT NOT NULL,
                phone TEXT,
                postal_code TEXT NOT NULL,
                city TEXT NOT NULL,
                country TEXT NOT NULL,
                father_name TEXT NOT NULL,
                father_cnic TEXT NOT NULL,
                blood_group TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ");
        
        // Create classes table
        $pdo->exec("
            CREATE TABLE classes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                teacher_id INTEGER NOT NULL,
                class_name TEXT NOT NULL,
                class_code TEXT NOT NULL UNIQUE,
                description TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (teacher_id) REFERENCES teachers(id)
            )
        ");
        
        // Create class_enrollments table
        $pdo->exec("
            CREATE TABLE class_enrollments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                class_id INTEGER NOT NULL,
                student_id INTEGER NOT NULL,
                enrolled_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (class_id) REFERENCES classes(id),
                FOREIGN KEY (student_id) REFERENCES students(id),
                UNIQUE(class_id, student_id)
            )
        ");
        
        // Create attendance table
        $pdo->exec("
            CREATE TABLE attendance (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                class_id INTEGER NOT NULL,
                student_id INTEGER NOT NULL,
                date TEXT NOT NULL,
                status TEXT NOT NULL CHECK(status IN ('present', 'absent', 'late')),
                recorded_by INTEGER NOT NULL,
                FOREIGN KEY (class_id) REFERENCES classes(id),
                FOREIGN KEY (student_id) REFERENCES students(id),
                FOREIGN KEY (recorded_by) REFERENCES teachers(id),
                UNIQUE(class_id, student_id, date)
            )
        ");
        
       // ... continued from earlier in initializePgDatabase()

        // Create marks table
        $pdo->exec("
            CREATE TABLE marks (
                id SERIAL PRIMARY KEY,
                class_id INTEGER NOT NULL,
                student_id INTEGER NOT NULL,
                assignment_name VARCHAR(100) NOT NULL,
                marks_obtained REAL NOT NULL,
                total_marks REAL NOT NULL,
                date DATE NOT NULL,
                recorded_by INTEGER NOT NULL,
                FOREIGN KEY (class_id) REFERENCES classes(id),
                FOREIGN KEY (student_id) REFERENCES students(id),
                FOREIGN KEY (recorded_by) REFERENCES teachers(id)
            )
        ");

        // Create stream_posts table
        $pdo->exec("
            CREATE TABLE stream_posts (
                id SERIAL PRIMARY KEY,
                class_id INTEGER NOT NULL,
                user_id INTEGER NOT NULL,
                user_type VARCHAR(10) NOT NULL CHECK(user_type IN ('student', 'teacher')),
                post_type VARCHAR(20) NOT NULL CHECK(post_type IN ('announcement', 'assignment', 'material', 'question')),
                title TEXT NOT NULL,
                content TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                due_date TIMESTAMP,
                FOREIGN KEY (class_id) REFERENCES classes(id)
            )
        ");

        // Create stream_comments table
        $pdo->exec("
            CREATE TABLE stream_comments (
                id SERIAL PRIMARY KEY,
                post_id INTEGER NOT NULL,
                user_id INTEGER NOT NULL,
                user_type VARCHAR(10) NOT NULL CHECK(user_type IN ('student', 'teacher')),
                comment TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (post_id) REFERENCES stream_posts(id)
            )
        ");

        // Create assignment_submissions table
        $pdo->exec("
            CREATE TABLE assignment_submissions (
                id SERIAL PRIMARY KEY,
                post_id INTEGER NOT NULL,
                student_id INTEGER NOT NULL,
                content TEXT NOT NULL,
                submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                marks_obtained REAL,
                total_marks REAL,
                feedback TEXT,
                FOREIGN KEY (post_id) REFERENCES stream_posts(id),
                FOREIGN KEY (student_id) REFERENCES students(id)
            )
        ");

        // Create exam_preparation table
        $pdo->exec("
            CREATE TABLE exam_preparation (
                id SERIAL PRIMARY KEY,
                student_id INTEGER NOT NULL,
                title TEXT NOT NULL,
                content TEXT NOT NULL,
                file_path TEXT,
                checkpoints TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (student_id) REFERENCES students(id)
            )
        ");
    } catch (PDOException $e) {
        die("PostgreSQL database initialization failed: " . $e->getMessage());
    }
}

 

/**
 * Initialize PostgreSQL database with schema
 * 
 * @param PDO $pdo Database connection
 */
function initializePgDatabase($pdo) {

    
    try {
        // Create students table
        $pdo->exec("
            CREATE TABLE students (
                id SERIAL PRIMARY KEY,
                first_name VARCHAR(100) NOT NULL,
                last_name VARCHAR(100) NOT NULL,
                gender VARCHAR(20) NOT NULL,
                dob DATE NOT NULL,
                cnic VARCHAR(20) NOT NULL,
                nationality VARCHAR(50) NOT NULL,
                email VARCHAR(100) NOT NULL UNIQUE,
                username VARCHAR(50) NOT NULL UNIQUE,
                password VARCHAR(255) NOT NULL,
                qualification VARCHAR(100) NOT NULL,
                department VARCHAR(100) NOT NULL,
                address TEXT NOT NULL,
                phone VARCHAR(20),
                postal_code VARCHAR(20) NOT NULL,
                city VARCHAR(50) NOT NULL,
                country VARCHAR(50) NOT NULL,
                father_name VARCHAR(100) NOT NULL,
                father_cnic VARCHAR(20) NOT NULL,
                blood_group VARCHAR(5) NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ");
        
        // Create teachers table
        $pdo->exec("
            CREATE TABLE teachers (
                id SERIAL PRIMARY KEY,
                first_name VARCHAR(100) NOT NULL,
                last_name VARCHAR(100) NOT NULL,
                gender VARCHAR(20) NOT NULL,
                dob DATE NOT NULL,
                cnic VARCHAR(20) NOT NULL,
                nationality VARCHAR(50) NOT NULL,
                email VARCHAR(100) NOT NULL UNIQUE,
                username VARCHAR(50) NOT NULL UNIQUE,
                password VARCHAR(255) NOT NULL,
                qualification VARCHAR(100) NOT NULL,
                department VARCHAR(100) NOT NULL,
                address TEXT NOT NULL,
                phone VARCHAR(20),
                postal_code VARCHAR(20) NOT NULL,
                city VARCHAR(50) NOT NULL,
                country VARCHAR(50) NOT NULL,
                father_name VARCHAR(100) NOT NULL,
                father_cnic VARCHAR(20) NOT NULL,
                blood_group VARCHAR(5) NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ");
        
        // Create classes table
        $pdo->exec("
            CREATE TABLE classes (
                id SERIAL PRIMARY KEY,
                teacher_id INTEGER NOT NULL,
                class_name VARCHAR(100) NOT NULL,
                class_code VARCHAR(20) NOT NULL UNIQUE,
                description TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (teacher_id) REFERENCES teachers(id)
            )
        ");
        
        // Create class_enrollments table
        $pdo->exec("
            CREATE TABLE class_enrollments (
                id SERIAL PRIMARY KEY,
                class_id INTEGER NOT NULL,
                student_id INTEGER NOT NULL,
                enrolled_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (class_id) REFERENCES classes(id),
                FOREIGN KEY (student_id) REFERENCES students(id),
                UNIQUE(class_id, student_id)
            )
        ");
        
        // Create attendance table
        $pdo->exec("
            CREATE TABLE attendance (
                id SERIAL PRIMARY KEY,
                class_id INTEGER NOT NULL,
                student_id INTEGER NOT NULL,
                date DATE NOT NULL,
                status VARCHAR(10) NOT NULL CHECK(status IN ('present', 'absent', 'late')),
                recorded_by INTEGER NOT NULL,
                FOREIGN KEY (class_id) REFERENCES classes(id),
                FOREIGN KEY (student_id) REFERENCES students(id),
                FOREIGN KEY (recorded_by) REFERENCES teachers(id),
                UNIQUE(class_id, student_id, date)
            )
        ");
        
        // Create marks table
        $pdo->exec("
            CREATE TABLE marks (
                id SERIAL PRIMARY KEY,
                class_id INTEGER NOT NULL,
                student_id INTEGER NOT NULL,
                assignment_name VARCHAR(100) NOT NULL,
                marks_obtained NUMERIC(10,2) NOT NULL,
                total_marks NUMERIC(10,2) NOT NULL,
                date DATE NOT NULL,
                recorded_by INTEGER NOT NULL,
                FOREIGN KEY (class_id) REFERENCES classes(id),
                FOREIGN KEY (student_id) REFERENCES students(id),
                FOREIGN KEY (recorded_by) REFERENCES teachers(id)
            )
        ");
        
        // Create stream_posts table
        $pdo->exec("
            CREATE TABLE stream_posts (
                id SERIAL PRIMARY KEY,
                class_id INTEGER NOT NULL,
                user_id INTEGER NOT NULL,
                user_type VARCHAR(10) NOT NULL CHECK(user_type IN ('student', 'teacher')),
                post_type VARCHAR(20) NOT NULL CHECK(post_type IN ('announcement', 'assignment', 'material', 'question')),
                title VARCHAR(200) NOT NULL,
                content TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                due_date TIMESTAMP,
                FOREIGN KEY (class_id) REFERENCES classes(id)
            )
        ");
        
        // Create stream_comments table
        $pdo->exec("
            CREATE TABLE stream_comments (
                id SERIAL PRIMARY KEY,
                post_id INTEGER NOT NULL,
                user_id INTEGER NOT NULL,
                user_type VARCHAR(10) NOT NULL CHECK(user_type IN ('student', 'teacher')),
                comment TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (post_id) REFERENCES stream_posts(id)
            )
        ");
        
        // Create assignment_submissions table
        $pdo->exec("
            CREATE TABLE assignment_submissions (
                id SERIAL PRIMARY KEY,
                post_id INTEGER NOT NULL,
                student_id INTEGER NOT NULL,
                content TEXT NOT NULL,
                submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                marks_obtained NUMERIC(10,2),
                total_marks NUMERIC(10,2),
                feedback TEXT,
                FOREIGN KEY (post_id) REFERENCES stream_posts(id),
                FOREIGN KEY (student_id) REFERENCES students(id)
            )
        ");
        
        // Create exam_preparation table
        $pdo->exec("
            CREATE TABLE exam_preparation (
                id SERIAL PRIMARY KEY,
                student_id INTEGER NOT NULL,
                title VARCHAR(200) NOT NULL,
                content TEXT NOT NULL,
                file_path VARCHAR(255),
                checkpoints TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (student_id) REFERENCES students(id)
            )


            
        ");
    } catch (PDOException $e) {
        die("Database initialization failed: " . $e->getMessage());
    }
}
