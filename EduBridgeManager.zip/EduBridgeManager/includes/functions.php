<?php
/**
 * Helper functions for EduBridge classroom functionalities
 */

/**
 * Check if class exists and user has access
 * 
 * @param int $class_id Class ID
 * @param int $user_id User ID
 * @param string $user_type User type (student or teacher)
 * @return bool True if has access, false otherwise
 */
function verifyClassAccess($class_id, $user_id, $user_type) {
    if ($class_id <= 0) {
        return false;
    }
    
    $pdo = getDbConnection();
    
    if ($user_type === 'teacher') {
        // Check if teacher owns the class
        $stmt = $pdo->prepare("SELECT id FROM classes WHERE id = ? AND teacher_id = ?");
        $stmt->execute([$class_id, $user_id]);
    } else {
        // Check if student is enrolled in the class
        $stmt = $pdo->prepare("
            SELECT ce.id 
            FROM class_enrollments ce
            WHERE ce.class_id = ? AND ce.student_id = ?
        ");
        $stmt->execute([$class_id, $user_id]);
    }
    
    return $stmt->fetch() !== false;
}

/**
 * Get class details
 * 
 * @param int $class_id Class ID
 * @return array|false Class details or false if not found
 */
function getClassDetails($class_id) {
    $pdo = getDbConnection();
    
    $stmt = $pdo->prepare("
        SELECT c.*, t.first_name, t.last_name
        FROM classes c
        JOIN teachers t ON c.teacher_id = t.id
        WHERE c.id = ?
    ");
    $stmt->execute([$class_id]);
    
    return $stmt->fetch();
}

/**
 * Create a new stream post
 * 
 * @param int $class_id Class ID
 * @param int $user_id User ID
 * @param string $user_type User type
 * @param string $post_type Post type (announcement, assignment, material, question)
 * @param string $title Post title
 * @param string $content Post content
 * @param string|null $due_date Due date for assignments
 * @param string|null $file_path Path to attached file
 * @return int|false Post ID or false on failure
 */function createStreamPost(
    int    $class_id,
    int    $user_id,
    string $user_type,
    string $post_type,
    string $title,
    string $content,
    ?string $due_date = null,
    ?string $file_path = null
): false|int {
    $pdo = getDbConnection();

    try {
        $pdo->beginTransaction();

        // We now insert file_path (which may be NULL) in one shot
        $stmt = $pdo->prepare(
            "INSERT INTO stream_posts
                (class_id, user_id, user_type, post_type, title, content, due_date, file_path)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
        );

        $stmt->execute([
            $class_id,
            $user_id,
            $user_type,
            $post_type,
            $title,
            $content,
            $due_date,
            $file_path
        ]);

        $post_id = (int)$pdo->lastInsertId();
        $pdo->commit();

        return $post_id;
    } catch (PDOException $e) {
        $pdo->rollBack();
        error_log("Error creating stream post: " . $e->getMessage());
        return false;
    }
}


/**
 * Add a comment to a post
 * 
 * @param int $post_id Post ID
 * @param int $user_id User ID
 * @param string $user_type User type
 * @param string $comment Comment text
 * @return bool Success status
 */
function addPostComment($post_id, $user_id, $user_type, $comment) {
    $pdo = getDbConnection();
    
    try {
        $stmt = $pdo->prepare("
            INSERT INTO stream_comments (post_id, user_id, user_type, comment)
            VALUES (?, ?, ?, ?)
        ");
        $stmt->execute([$post_id, $user_id, $user_type, $comment]);
        
        return true;
    } catch (PDOException $e) {
        error_log("Error adding comment: " . $e->getMessage());
        return false;
    }
}

/**
 * Get all posts for a class
 * 
 * @param int $class_id Class ID
 * @return array Array of posts
 */
function getStreamPosts($class_id) {
    $pdo = getDbConnection();
    
    $stmt = $pdo->prepare("
        SELECT p.*, (
            SELECT COUNT(*) FROM assignment_submissions 
            WHERE post_id = p.id
        ) as submission_count
        FROM stream_posts p
        WHERE p.class_id = ?
        ORDER BY p.created_at DESC
    ");
    $stmt->execute([$class_id]);
    
    return $stmt->fetchAll();
}

/**
 * Get comments for a post
 * 
 * @param int $post_id Post ID
 * @return array Comments
 */
function getPostComments($post_id) {
    $pdo = getDbConnection();
    
    $stmt = $pdo->prepare("
        SELECT c.*
        FROM stream_comments c
        WHERE c.post_id = ?
        ORDER BY c.created_at ASC
    ");
    $stmt->execute([$post_id]);
    
    return $stmt->fetchAll();
}

/**
 * Format date for display
 * 
 * @param string $date Date string
 * @return string Formatted date
 */
function formatDate($date) {
    $timestamp = strtotime($date);
    $now = time();
    $diff = $now - $timestamp;
    
    if ($diff < 60) {
        return "Just now";
    } elseif ($diff < 3600) {
        $mins = floor($diff / 60);
        return $mins . " minute" . ($mins > 1 ? "s" : "") . " ago";
    } elseif ($diff < 86400) {
        $hours = floor($diff / 3600);
        return $hours . " hour" . ($hours > 1 ? "s" : "") . " ago";
    } elseif ($diff < 172800) { // Less than 2 days
        return "Yesterday at " . date("g:i A", $timestamp);
    } elseif ($diff < 604800) { // Less than a week
        return date("l", $timestamp) . " at " . date("g:i A", $timestamp);
    } else {
        return date("M j, Y", $timestamp) . " at " . date("g:i A", $timestamp);
    }
}

/**
 * Get user name from ID and type
 * 
 * @param int $user_id User ID
 * @param string $user_type User type
 * @return string User's full name
 */
function getUserName($user_id, $user_type) {
    $pdo = getDbConnection();
    
    $table = ($user_type === 'teacher') ? 'teachers' : 'students';
    
    $stmt = $pdo->prepare("
        SELECT first_name, last_name
        FROM $table
        WHERE id = ?
    ");
    $stmt->execute([$user_id]);
    
    $user = $stmt->fetch();
    
    return $user ? $user['first_name'] . ' ' . $user['last_name'] : 'Unknown User';
}

/**
 * Get assignment submission status
 * 
 * @param int $post_id Post ID
 * @param int $student_id Student ID
 * @return array|false Submission details or false if not submitted
 */
// function getSubmissionStatus($post_id, $student_id) {
//     $pdo = getDbConnection();
    
//     $stmt = $pdo->prepare("
//         SELECT *
//         FROM assignment_submissions
//         WHERE post_id = ? AND student_id = ?
//         LIMIT 1
//     ");
//     $stmt->execute([$post_id, $student_id]);
    
//     return $stmt->fetch();
// }

/**
 * Generate a random class code
 * 
 * @return string Class code
 */
function generateClassCode() {
    $characters = '123456789ABCDEFGHIJKLMNPQRSTUVWXYZ';
    $code = '';
    
    for ($i = 0; $i < 6; $i++) {
        $code .= $characters[rand(0, strlen($characters) - 1)];
    }
    
    return $code;
}

/**
 * Check if class code is unique
 * 
 * @param string $code Class code
 * @return bool True if unique, false otherwise
 */
function isClassCodeUnique($code) {
    $pdo = getDbConnection();
    
    $stmt = $pdo->prepare("SELECT id FROM classes WHERE class_code = ?");
    $stmt->execute([$code]);
    
    return $stmt->fetch() === false;
}

/**
 * Create a new class
 * 
 * @param int $teacher_id Teacher ID
 * @param string $class_name Class name
 * @param string $description Class description
 * @return int|false Class ID or false on failure
 */
function createClass($teacher_id, $class_name, $description) {
    $pdo = getDbConnection();
    
    // Generate unique class code
    do {
        $class_code = generateClassCode();
    } while (!isClassCodeUnique($class_code));
    
    try {
        $stmt = $pdo->prepare("
            INSERT INTO classes (teacher_id, class_name, class_code, description)
            VALUES (?, ?, ?, ?)
        ");
        $stmt->execute([$teacher_id, $class_name, $class_code, $description]);
        
        return $pdo->lastInsertId();
    } catch (PDOException $e) {
        error_log("Error creating class: " . $e->getMessage());
        return false;
    }
}

/**
 * Enroll student in a class
 * 
 * @param int $class_id Class ID
 * @param int $student_id Student ID
 * @return bool Success status
 */
function enrollStudent($class_id, $student_id) {
    $pdo = getDbConnection();
    
    try {
        $stmt = $pdo->prepare("
            INSERT INTO class_enrollments (class_id, student_id)
            VALUES (?, ?)
        ");
        $stmt->execute([$class_id, $student_id]);
        
        return true;
    } catch (PDOException $e) {
        // Ignore duplicate enrollments
        if ($e->getCode() !== '23000') { // Not a duplicate entry error
            error_log("Error enrolling student: " . $e->getMessage());
        }
        return false;
    }
}

/**
 * Submit assignment
 * 
 * @param int $post_id Post ID
 * @param int $student_id Student ID
 * @param string $content Submission content
 * @param string|null $file_path Path to submitted file
 * @return bool Success status
 */
// function submitAssignment($post_id, $student_id, $content, $file_path = null) {
//     $pdo = getDbConnection();
    
//     try {
//         $stmt = $pdo->prepare("
//             INSERT INTO assignment_submissions (post_id, student_id, content, file_path)
//             VALUES (?, ?, ?, ?)
//         ");
//         $stmt->execute([$post_id, $student_id, $content, $file_path]);
        
//         return true;
//     } catch (PDOException $e) {
//         error_log("Error submitting assignment: " . $e->getMessage());
//         return false;
//     }
// }

/**
 * Get submissions for an assignment
 * 
 * @param int $post_id Post ID
 * @return array Submissions
 */
// function getAssignmentSubmissions($post_id) {
//     $pdo = getDbConnection();
    
//     $stmt = $pdo->prepare("
//         SELECT s.*, st.first_name, st.last_name
//         FROM assignment_submissions s
//         JOIN students st ON s.student_id = st.id
//         WHERE s.post_id = ?
//         ORDER BY s.submitted_at DESC
//     ");
//     $stmt->execute([$post_id]);
    
//     return $stmt->fetchAll();
// }

/**
 * Grade assignment submission
 * 
 * @param int $submission_id Submission ID
 * @param float $marks_obtained Marks obtained
 * @param float $total_marks Total marks
 * @param string $feedback Feedback
 * @return bool Success status
 */
function gradeSubmission($submission_id, $marks_obtained, $total_marks, $feedback) {
    $pdo = getDbConnection();
    
    try {
        $stmt = $pdo->prepare("
            UPDATE assignment_submissions
            SET marks_obtained = ?, total_marks = ?, feedback = ?
            WHERE id = ?
        ");
        $stmt->execute([$marks_obtained, $total_marks, $feedback, $submission_id]);
        
        return true;
    } catch (PDOException $e) {
        error_log("Error grading submission: " . $e->getMessage());
        return false;
    }
}
/**
 * Helper functions for the application
 */

/**
 * Sanitize user input
 *
 * @param string $input User input to sanitize
 * @return string Sanitized input
 */
function sanitize($input) {
    $input = trim($input);
    $input = stripslashes($input);
    $input = htmlspecialchars($input, ENT_QUOTES, 'UTF-8');
    return $input;
}

/**
 * Redirect to a specified location
 *
 * @param string $location Location to redirect to
 */
function redirect($location) {
    header("Location: $location");
    exit;
}

/**
 * Generate a random string
 *
 * @param int $length Length of the string to generate
 * @return string Random string
 */
function generateRandomString($length = 6) {
    $characters = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}

/**
 * Format date for display
 *
 * @param string $date Date string to format
 * @param string $format Format to use
 * @return string Formatted date
 */
// function formatDate($date, $format = 'd M, Y') {
//     $dateObj = new DateTime($date);
//     return $dateObj->format($format);
// }

/**
 * Calculate percentage
 *
 * @param float $obtained Value obtained
 * @param float $total Total value
 * @return float Percentage
 */
function calculatePercentage($obtained, $total) {
    if ($total == 0) {
        return 0;
    }
    return round(($obtained / $total) * 100, 2);
}

/**
 * Get user details
 *
 * @param int $userId User ID
 * @param string $userType User type (student or teacher)
 * @return array|null User details
 */
function getUserDetails($userId, $userType) {
    try {
        $pdo = getDbConnection();
        $stmt = $pdo->prepare("SELECT * FROM {$userType}s WHERE id = :id");
        $stmt->execute(['id' => $userId]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        return null;
    }
}

/**
 * Get classes for a teacher
 *
 * @param int $teacherId Teacher ID
 * @return array Classes
 */
function getTeacherClasses($teacherId) {
    try {
        $pdo = getDbConnection();
        $stmt = $pdo->prepare("
            SELECT * FROM classes
            WHERE teacher_id = :teacher_id
            ORDER BY created_at DESC
        ");
        $stmt->execute(['teacher_id' => $teacherId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        return [];
    }
}

/**
 * Get enrolled classes for a student
 *
 * @param int $studentId Student ID
 * @return array Classes
 */
function getStudentClasses($studentId) {
    try {
        $pdo = getDbConnection();
        $stmt = $pdo->prepare("
            SELECT c.* FROM classes c
            JOIN class_enrollments e ON c.id = e.class_id
            WHERE e.student_id = :student_id
            ORDER BY e.enrolled_at DESC
        ");
        $stmt->execute(['student_id' => $studentId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        return [];
    }
}

/**
 * Get enrolled students for a class, optionally filtered by section
 *
 * @param int $classId Class ID
 * @param string $section Optional section to filter by (default 'all')
 * @return array Students
 */
function getClassStudents($classId, $section = 'all') {
    try {
        $pdo = getDbConnection();
        $sql = "
            SELECT s.id, s.first_name, s.last_name, s.email, e.enrolled_at
            FROM students s
            JOIN class_enrollments e ON s.id = e.student_id
            WHERE e.class_id = :class_id
        ";
        if ($section !== 'all' && !empty($section)) {
            $sql .= " AND e.section = :section";
            $stmt = $pdo->prepare($sql);
            $stmt->bindParam(':section', $section, PDO::PARAM_STR);
        } else {
            $stmt = $pdo->prepare($sql);
        }
        $stmt->bindParam(':class_id', $classId, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        return [];
    }
}

/**
 * Get attendance for a student in a class
 *
 * @param int $classId Class ID
 * @param int $studentId Student ID
 * @return array Attendance records
 */
function getStudentAttendance($classId, $studentId) {
    try {
        $pdo = getDbConnection();
        $stmt = $pdo->prepare("
            SELECT * FROM attendance
            WHERE class_id = :class_id AND student_id = :student_id
            ORDER BY date DESC
        ");
        $stmt->execute([
            'class_id'   => $classId,
            'student_id' => $studentId
        ]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        return [];
    }
}

/**
 * Get marks for a student in a class
 *
 * @param int $classId Class ID
 * @param int $studentId Student ID
 * @return array Marks records
 */
function getStudentMarks($classId, $studentId) {
    try {
        $pdo = getDbConnection();
        $stmt = $pdo->prepare("
            SELECT * FROM marks
            WHERE class_id = :class_id AND student_id = :student_id
            ORDER BY date DESC
        ");
        $stmt->execute([
            'class_id'   => $classId,
            'student_id' => $studentId
        ]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        return [];
    }
}

/**
 * Get total marks and obtained marks for a student in a class
 *
 * @param int $classId Class ID
 * @param int $studentId Student ID
 * @return array Total and obtained marks
 */
function getStudentTotalMarks($classId, $studentId) {
    try {
        $pdo = getDbConnection();
        $stmt = $pdo->prepare("
            SELECT SUM(marks_obtained) as obtained, SUM(total_marks) as total
            FROM marks
            WHERE class_id = :class_id AND student_id = :student_id
        ");
        $stmt->execute([
            'class_id'   => $classId,
            'student_id' => $studentId
        ]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return [
            'obtained'   => (float) ($result['obtained'] ?? 0),
            'total'      => (float) ($result['total']    ?? 0),
            'percentage' => calculatePercentage(
                (float) ($result['obtained'] ?? 0),
                (float) ($result['total']    ?? 0)
            )
        ];
    } catch (PDOException $e) {
        return ['obtained'=>0,'total'=>0,'percentage'=>0];
    }
}

/**
 * Get attendance summary for a student in a class
 *
 * @param int $classId Class ID
 * @param int $studentId Student ID
 * @return array Attendance summary
 */
function getStudentAttendanceSummary($classId, $studentId) {
    try {
        $pdo = getDbConnection();

        // Present count
        $stmt = $pdo->prepare("
            SELECT COUNT(*) FROM attendance
            WHERE class_id = :class_id
              AND student_id = :student_id
              AND status = 'present'
        ");
        $stmt->execute([
            'class_id'   => $classId,
            'student_id' => $studentId
        ]);
        $presentCount = (int)$stmt->fetchColumn();

        // Late count
        $stmt = $pdo->prepare("
            SELECT COUNT(*) FROM attendance
            WHERE class_id = :class_id
              AND student_id = :student_id
              AND status = 'late'
        ");
        $stmt->execute([
            'class_id'   => $classId,
            'student_id' => $studentId
        ]);
        $lateCount = (int)$stmt->fetchColumn();

        // Absent count
        $stmt = $pdo->prepare("
            SELECT COUNT(*) FROM attendance
            WHERE class_id = :class_id
              AND student_id = :student_id
              AND status = 'absent'
        ");
        $stmt->execute([
            'class_id'   => $classId,
            'student_id' => $studentId
        ]);
        $absentCount = (int)$stmt->fetchColumn();

        $totalCount = $presentCount + $lateCount + $absentCount;
        $presentPct = $totalCount ? round($presentCount / $totalCount * 100,2) : 0;
        $latePct    = $totalCount ? round($lateCount    / $totalCount * 100,2) : 0;
        $absentPct  = $totalCount ? round($absentCount  / $totalCount * 100,2) : 0;

        return [
            'present'          => $presentCount,
            'late'             => $lateCount,
            'absent'           => $absentCount,
            'total'            => $totalCount,
            'presentPercentage'=> $presentPct,
            'latePercentage'   => $latePct,
            'absentPercentage' => $absentPct
        ];
    } catch (PDOException $e) {
        return ['present'=>0,'late'=>0,'absent'=>0,'total'=>0,'presentPercentage'=>0,'latePercentage'=>0,'absentPercentage'=>0];
    }
}

/**
 * Get class details
 *
 * @param int $classId Class ID
 * @return array|null Class details
 */
// function getClassDetails($classId) {
//     try {
//         $pdo = getDbConnection();
//         $stmt = $pdo->prepare("
//             SELECT c.*, t.first_name, t.last_name
//             FROM classes c
//             JOIN teachers t ON c.teacher_id = t.id
//             WHERE c.id = :class_id
//         ");
//         $stmt->execute(['class_id' => $classId]);
//         return $stmt->fetch(PDO::FETCH_ASSOC);
//     } catch (PDOException $e) {
//         return null;
//     }
// }

/**
 * Get stream posts for a class
 *
 * @param int $classId Class ID
 * @return array Stream posts
 */
function getClassStreamPosts($classId) {
    try {
        $pdo = getDbConnection();
        $stmt = $pdo->prepare("
            SELECT sp.*,
              CASE
                WHEN sp.user_type='teacher'
                  THEN (SELECT first_name||' '||last_name FROM teachers WHERE id=sp.user_id)
                WHEN sp.user_type='student'
                  THEN (SELECT first_name||' '||last_name FROM students WHERE id=sp.user_id)
              END AS user_name
            FROM stream_posts sp
            WHERE sp.class_id = :class_id
            ORDER BY sp.created_at DESC
        ");
        $stmt->execute(['class_id'=>$classId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        return [];
    }
}

/**
 * Get all comments for a given post, ordered oldest→newest
 *
 * @param int $postId Post ID
 * @return array Comments
 */
// function getPostComments($postId) {
//     try {
//         $pdo = getDbConnection();
//         $stmt = $pdo->prepare("
//             SELECT sc.*,
//               CASE
//                 WHEN sc.user_type='teacher'
//                   THEN (SELECT first_name||' '||last_name FROM teachers WHERE id=sc.user_id)
//                 WHEN sc.user_type='student'
//                   THEN (SELECT first_name||' '||last_name FROM students WHERE id=sc.user_id)
//               END AS user_name
//             FROM stream_comments sc
//             WHERE sc.post_id = :post_id
//             ORDER BY sc.created_at ASC
//         ");
//         $stmt->execute(['post_id' => $postId]);
//         return $stmt->fetchAll(PDO::FETCH_ASSOC);
//     } catch (PDOException $e) {
//         return [];
//     }
// }

/**
 * Check if student is enrolled in a class
 *
 * @param int $classId Class ID
 * @param int $studentId Student ID
 * @return bool
 */
function isStudentEnrolled($classId, $studentId) {
    try {
        $pdo = getDbConnection();
        $stmt = $pdo->prepare("
            SELECT COUNT(*) FROM class_enrollments
            WHERE class_id = :class_id AND student_id = :student_id
        ");
        $stmt->execute([
            'class_id'   => $classId,
            'student_id' => $studentId
        ]);
        return (int)$stmt->fetchColumn() > 0;
    } catch (PDOException $e) {
        return false;
    }
}

/**
 * Check if class belongs to teacher
 *
 * @param int $classId Class ID
 * @param int $teacherId Teacher ID
 * @return bool
 */
function isTeacherClass($classId, $teacherId) {
    try {
        $pdo = getDbConnection();
        $stmt = $pdo->prepare("
            SELECT COUNT(*) FROM classes
            WHERE id = :class_id AND teacher_id = :teacher_id
        ");
        $stmt->execute([
            'class_id'   => $classId,
            'teacher_id' => $teacherId
        ]);
        return (int)$stmt->fetchColumn() > 0;
    } catch (PDOException $e) {
        return false;
    }
}

/**
 * Get distinct sections for a class
 *
 * @param int $classId Class ID
 * @return array Sections
 */
function getSectionsForClass($classId) {
    try {
        $pdo = getDbConnection();
        $stmt = $pdo->prepare("
            SELECT DISTINCT section FROM class_enrollments
            WHERE class_id = :class_id
            ORDER BY section
        ");
        $stmt->execute(['class_id' => $classId]);
        return $stmt->fetchAll(PDO::FETCH_COLUMN);
    } catch (PDOException $e) {
        return [];
    }
}

/**
 * Get total number of classes (attendance days) for a student
 */
function getTotalClassesForStudent($studentId, $classId) {
    try {
        $pdo = getDbConnection();
        $stmt = $pdo->prepare("
            SELECT COUNT(DISTINCT date)
            FROM attendance
            WHERE student_id = :student_id
              AND class_id   = :class_id
        ");
        $stmt->execute([
            'student_id' => $studentId,
            'class_id'   => $classId
        ]);
        return (int)$stmt->fetchColumn();
    } catch (PDOException $e) {
        return 0;
    }
}

/**
 * Get attendance count by status for a student
 */
function getAttendanceCount($studentId, $classId, $status) {
    try {
        $pdo = getDbConnection();
        $stmt = $pdo->prepare("
            SELECT COUNT(*)
            FROM attendance
            WHERE student_id = :student_id
              AND class_id   = :class_id
              AND status     = :status
        ");
        $stmt->execute([
            'student_id' => $studentId,
            'class_id'   => $classId,
            'status'     => $status
        ]);
        return (int)$stmt->fetchColumn();
    } catch (PDOException $e) {
        return 0;
    }
}

/**
 * Get post details by ID
 * 
 * @param int $post_id Post ID
 * @return array|false Post details or false if not found
 */
function getPostDetails($post_id) {
    $pdo = getDbConnection();
    
    $stmt = $pdo->prepare("
        SELECT *
        FROM stream_posts
        WHERE id = ?
    ");
    $stmt->execute([$post_id]);
    
    return $stmt->fetch();
}

/**
 * Update existing submission
 * 
 * @param int $submission_id Submission ID
 * @param string $content Submission content
 * @param string|null $file_path Path to submitted file
 * @return bool Success status
 */
// function updateSubmission($submission_id, $content, $file_path = null) {
//     $pdo = getDbConnection();
    
//     try {
//         if ($file_path !== null) {
//             $stmt = $pdo->prepare("
//                 UPDATE assignment_submissions
//                 SET content = ?, file_path = ?, submitted_at = CURRENT_TIMESTAMP
//                 WHERE id = ?
//             ");
//             $stmt->execute([$content, $file_path, $submission_id]);
//         } else {
//             $stmt = $pdo->prepare("
//                 UPDATE assignment_submissions
//                 SET content = ?, submitted_at = CURRENT_TIMESTAMP
//                 WHERE id = ?
//             ");
//             $stmt->execute([$content, $submission_id]);
//         }
        
//         return true;
//     } catch (PDOException $e) {
//         error_log("Error updating submission: " . $e->getMessage());
//         return false;
//     }
// }

/**
 * Get students enrolled in a class
 * 
 * @param int $class_id Class ID
 * @return array Students
 */
function getEnrolledStudents($class_id) {
    $pdo = getDbConnection();
    
    $stmt = $pdo->prepare("
        SELECT s.*
        FROM students s
        JOIN class_enrollments ce ON s.id = ce.student_id
        WHERE ce.class_id = ?
        ORDER BY s.last_name, s.first_name
    ");
    $stmt->execute([$class_id]);
    
    return $stmt->fetchAll();
}

/**
 * Fetch all submissions for a given assignment post
 */
function getAssignmentSubmissions($postId) {
    // getDbConnection() is defined in db_config.php
    $pdo = getDbConnection();
    $stmt = $pdo->prepare(
        "SELECT id,
                student_id,
                content,
                file_path,
                submitted_at,
                marks_obtained
         FROM assignment_submissions
         WHERE post_id = :post_id
         ORDER BY submitted_at DESC"
    );
    $stmt->execute(['post_id' => $postId]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

/**
 * Return existing submission row or false
 */
function getSubmissionStatus($postId, $studentId) {
    $pdo = getDbConnection();
    $stmt = $pdo->prepare("
        SELECT * 
        FROM assignment_submissions 
        WHERE post_id = :post_id 
          AND student_id = :student_id
        LIMIT 1
    ");
    $stmt->execute([
        'post_id'    => $postId,
        'student_id' => $studentId
    ]);
    return $stmt->fetch(PDO::FETCH_ASSOC) ?: false;
}

/**
 * Insert a new assignment submission
 */
function submitAssignment($postId, $studentId, $content, $filePath = null) {
    $pdo = getDbConnection();
    $stmt = $pdo->prepare("
        INSERT INTO assignment_submissions 
        (post_id, student_id, content, file_path) 
        VALUES (:post_id, :student_id, :content, :file_path)
    ");
    return $stmt->execute([
        'post_id'    => $postId,
        'student_id' => $studentId,
        'content'    => $content,
        'file_path'  => $filePath
    ]);
}

/**
 * Update an existing submission
 */
function updateSubmission($submissionId, $content, $filePath = null) {
    $pdo = getDbConnection();
    $sql = "UPDATE assignment_submissions SET content = :content";
    $params = ['content' => $content, 'id' => $submissionId];
    if ($filePath !== null) {
        $sql .= ", file_path = :file_path";
        $params['file_path'] = $filePath;
    }
    $sql .= " WHERE id = :id";
    $stmt = $pdo->prepare($sql);
    return $stmt->execute($params);
}
