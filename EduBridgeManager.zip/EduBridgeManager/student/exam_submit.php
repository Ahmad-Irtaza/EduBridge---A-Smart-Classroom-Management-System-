<?php
session_start();
header('Content-Type: application/json');

try {
    // 1. Only POST
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Invalid request method');
    }

    // 2. Was a file sent?
    if (!isset($_FILES['file'])) {
        throw new Exception('No file uploaded');
    }

    // 3. Check PHP upload errors
    switch ($_FILES['file']['error']) {
        case UPLOAD_ERR_OK:
            break;
        case UPLOAD_ERR_INI_SIZE:
        case UPLOAD_ERR_FORM_SIZE:
            throw new Exception('File too large');
        case UPLOAD_ERR_PARTIAL:
            throw new Exception('File only partially uploaded');
        case UPLOAD_ERR_NO_FILE:
            throw new Exception('No file selected');
        default:
            throw new Exception('Upload error code: ' . $_FILES['file']['error']);
    }

    // 4. Validate extension
    $orig    = $_FILES['file']['name'];
    $ext     = strtolower(pathinfo($orig, PATHINFO_EXTENSION));
    $allowed = ['pdf','txt','jpg','jpeg','png','bmp','tiff'];
    if (!in_array($ext, $allowed)) {
        throw new Exception('Unsupported file type: ' . $ext);
    }

    // 5. Ensure upload dir exists
    $uploadDir = __DIR__ . '/uploads/';
    if (!is_dir($uploadDir) && !mkdir($uploadDir, 0777, true)) {
        throw new Exception('Cannot create upload directory');
    }

    // 6. Move uploaded file
    $filename   = uniqid('mat_', true) . '.' . $ext;
    $targetPath = $uploadDir . $filename;
    if (!move_uploaded_file($_FILES['file']['tmp_name'], $targetPath)) {
        throw new Exception('Failed to save uploaded file');
    }

    // 7. Extract text
    $text = '';
    if ($ext === 'txt') {
        $text = file_get_contents($targetPath);
    } elseif (in_array($ext, ['jpg','jpeg','png','bmp','tiff'])) {
        // requires `tesseract` CLI installed
        $text = trim(shell_exec("tesseract " . escapeshellarg($targetPath) . " stdout"));
    } elseif ($ext === 'pdf') {
        // requires `pdftotext` CLI installed
        $tmp = tempnam(sys_get_temp_dir(), 'ocr');
        shell_exec("pdftotext " . escapeshellarg($targetPath) . " " . escapeshellarg($tmp));
        $text = file_get_contents($tmp);
        @unlink($tmp);
    }

    // 8. Chunk into 3000-char pieces
    $chunks = array_filter(str_split($text, 3000), fn($c) => trim($c) !== '');
    $_SESSION['material_chunks'] = $chunks;

    // 9. Success
    echo json_encode([
      'success' => true,
      'message' => 'Uploaded & extracted OK',
      'chunks'  => count($chunks)
    ]);
    exit;

} catch (Exception $e) {
    // any problem will return success:false + real message
    echo json_encode([
      'success' => false,
      'message' => $e->getMessage()
    ]);
    exit;
}
