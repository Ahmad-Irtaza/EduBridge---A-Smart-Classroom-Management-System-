<?php
session_start();
require_once('../includes/db_config.php');
require_once('../includes/functions.php');
require_once('../includes/auth.php');

// Check if user is logged in and is a student
if (!isLoggedIn() || $_SESSION['user_type'] !== 'student') {
    redirect('../login.php?type=student');
}

// Get student information
$studentId = $_SESSION['user_id'];
$studentName = $_SESSION['user_name'];

// Get PDO connection
$pdo = getDbConnection();

// Get enrolled classes
$enrolledClasses = [];
try {
    $stmt = $pdo->prepare("
        SELECT c.id, c.class_name, c.class_code, t.first_name AS teacher_first_name, t.last_name AS teacher_last_name
        FROM classes c
        JOIN class_enrollments ce ON c.id = ce.class_id
        JOIN teachers t ON c.teacher_id = t.id
        WHERE ce.student_id = :student_id
        ORDER BY c.class_name ASC
    ");
    $stmt->execute(['student_id' => $studentId]);
    $enrolledClasses = $stmt->fetchAll();
} catch (PDOException $e) {
    $error = "Database error: " . $e->getMessage();
}

// Selected class
$selectedClassId = isset($_GET['class_id']) ? intval($_GET['class_id']) : (isset($enrolledClasses[0]) ? $enrolledClasses[0]['id'] : 0);
$selectedClassName = '';

// Get marks for selected class
$marks = [];
$totalObtained = 0;
$totalMarks = 0;
$marksByCategory = [];

if ($selectedClassId > 0) {
    try {
        // Get marks
        $stmt = $pdo->prepare("
            SELECT m.id, m.assignment_name, m.marks_obtained, m.total_marks, m.date, 
                   c.class_name, c.class_code,
                   t.first_name AS teacher_first_name, t.last_name AS teacher_last_name
            FROM marks m
            JOIN classes c ON m.class_id = c.id
            JOIN teachers t ON m.recorded_by = t.id
            WHERE m.student_id = :student_id AND m.class_id = :class_id
            ORDER BY m.date DESC
        ");
        $stmt->execute([
            'student_id' => $studentId,
            'class_id' => $selectedClassId
        ]);
        $marks = $stmt->fetchAll();
        
        // Get class name
        foreach ($enrolledClasses as $class) {
            if ($class['id'] == $selectedClassId) {
                $selectedClassName = $class['class_name'];
                break;
            }
        }
        
        // Calculate overall performance
        foreach ($marks as $mark) {
            $totalObtained += $mark['marks_obtained'];
            $totalMarks += $mark['total_marks'];
            
            // Group marks by month (as categories)
            $month = date('M Y', strtotime($mark['date']));
            if (!isset($marksByCategory[$month])) {
                $marksByCategory[$month] = [
                    'obtained' => 0,
                    'total' => 0,
                    'count' => 0
                ];
            }
            
            $marksByCategory[$month]['obtained'] += $mark['marks_obtained'];
            $marksByCategory[$month]['total'] += $mark['total_marks'];
            $marksByCategory[$month]['count']++;
        }
    } catch (PDOException $e) {
        $error = "Database error: " . $e->getMessage();
    }
}

// Calculate overall percentage
$overallPercentage = ($totalMarks > 0) ? ($totalObtained / $totalMarks) * 100 : 0;

// Determine grade based on percentage
function getGrade($percentage) {
    if ($percentage >= 90) return ['A+', 'Outstanding'];
    else if ($percentage >= 80) return ['A', 'Excellent'];
    else if ($percentage >= 70) return ['B', 'Very Good'];
    else if ($percentage >= 60) return ['C', 'Good'];
    else if ($percentage >= 50) return ['D', 'Satisfactory'];
    else return ['F', 'Fail'];
}

$grade = getGrade($overallPercentage);

include __DIR__ . '/../includes/header.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Marks - EduBridge</title>
    <link rel="stylesheet" href="../css/style.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="../js/charts.js" defer></script>
    <script src="../js/main.js" defer></script>
</head>
<body>
    <div class="dashboard-container">
        <?php include('../includes/student_sidebar.php'); ?>
        
        <main class="dashboard-content">
            <header class="dashboard-header">
                <div class="header-info">
                    <h1>My Marks</h1>
                    <p>Review your academic performance and marks</p>
                </div>
<!--                 
                <div class="header-actions">
                    <div class="date-display"><?php echo date('l, F j, Y'); ?></div>
                    <div class="user-profile">
                        <img src="../images/avatars/student.png" alt="Profile" class="avatar">
                        <div class="dropdown">
                            <span class="dropdown-toggle"><?php echo htmlspecialchars($studentName); ?></span>
                            <div class="dropdown-menu">
                                <a href="profile.php">My Profile</a>
                                <a href="../logout.php">Logout</a>
                            </div>
                        </div>
                    </div>
                </div> -->
            </header>
            
            <!-- Class Selector -->
            <div class="page-toolbar">
                <div class="class-selector">
                    <label for="class-select">Select Class:</label>
                    <select id="class-select" onchange="location.href='marks.php?class_id='+this.value">
                        <?php if (empty($enrolledClasses)): ?>
                            <option value="0">No classes enrolled</option>
                        <?php else: ?>
                            <?php foreach ($enrolledClasses as $class): ?>
                                <option value="<?php echo $class['id']; ?>" <?php echo ($class['id'] == $selectedClassId) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($class['class_name'] . ' (' . $class['class_code'] . ')'); ?>
                                </option>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </select>
                </div>
                
                <div class="page-actions">
                    <button class="btn-secondary" onclick="window.print()">
                        <span class="icon">🖨️</span>
                        <span>Print Report</span>
                    </button>
                </div>
            </div>
            
            <?php if (empty($enrolledClasses)): ?>
                <div class="empty-state">
                    <p>You are not enrolled in any classes yet.</p>
                    <a href="join_class.php" class="btn-primary">Join a Class</a>
                </div>
            <?php elseif ($selectedClassId > 0): ?>
                <div class="marks-overview">
                    <div class="marks-summary-card">
                        <div class="card-header">
                            <h2><?php echo htmlspecialchars($selectedClassName); ?> - Performance Summary</h2>
                        </div>
                        
                        <div class="summary-content">
                            <div class="grade-display">
                                <div class="grade <?php echo strtolower(str_replace('+', '-plus', $grade[0])); ?>">
                                    <?php echo $grade[0]; ?>
                                </div>
                                <div class="grade-text">
                                    <p class="grade-label"><?php echo $grade[1]; ?></p>
                                    <p class="grade-percentage"><?php echo number_format($overallPercentage, 1); ?>%</p>
                                </div>
                            </div>
                            
                            <div class="marks-stats">
                                <div class="stat-item">
                                    <span class="value"><?php echo number_format($totalObtained, 1); ?></span>
                                    <span class="label">Marks Obtained</span>
                                </div>
                                <div class="stat-item">
                                    <span class="value"><?php echo number_format($totalMarks, 1); ?></span>
                                    <span class="label">Total Marks</span>
                                </div>
                                <div class="stat-item">
                                    <span class="value"><?php echo count($marks); ?></span>
                                    <span class="label">Assessments</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <?php if (!empty($marks)): ?>
                        <div class="marks-chart-card">
                            <div class="card-header">
                                <h2>Performance Trend</h2>
                            </div>
                            
                            <div class="chart-container">
                                <canvas id="marksChart"></canvas>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
                
                <div class="marks-details">
                    <div class="card-header">
                        <h2>Marks Details</h2>
                    </div>
                    
                    <?php if (empty($marks)): ?>
                        <div class="empty-state">
                            <p>No marks recorded for this class yet.</p>
                        </div>
                    <?php else: ?>
                        <div class="marks-table-container">
                            <table class="marks-table">
                                <thead>
                                    <tr>
                                        <th>Assessment</th>
                                        <th>Date</th>
                                        <th>Marks Obtained</th>
                                        <th>Total Marks</th>
                                        <th>Percentage</th>
                                        <th>Grade</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($marks as $mark): ?>
                                        <?php 
                                        $percentage = ($mark['marks_obtained'] / $mark['total_marks']) * 100;
                                        $markGrade = getGrade($percentage);
                                        $rowClass = $percentage >= 90 ? 'excellent' : ($percentage >= 70 ? 'good' : ($percentage >= 50 ? 'average' : 'poor'));
                                        ?>
                                        <tr class="<?php echo $rowClass; ?>">
                                            <td class="assessment-name"><?php echo htmlspecialchars($mark['assignment_name']); ?></td>
                                            <td class="date"><?php echo date('M j, Y', strtotime($mark['date'])); ?></td>
                                            <td class="marks-obtained"><?php echo $mark['marks_obtained']; ?></td>
                                            <td class="total-marks"><?php echo $mark['total_marks']; ?></td>
                                            <td class="percentage"><?php echo number_format($percentage, 1); ?>%</td>
                                            <td class="grade"><?php echo $markGrade[0]; ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
            
        </main>
    </div>
    
    <?php if (!empty($marksByCategory)): ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const marksCtx = document.getElementById('marksChart').getContext('2d');
            
            createLineChart('marksChart', {
                labels: [<?php 
                    // Get the months in chronological order
                    $months = array_keys($marksByCategory);
                    sort($months, SORT_REGULAR);
                    echo "'" . implode("', '", $months) . "'";
                ?>],
                datasets: [{
                    label: 'Performance (%)',
                    data: [<?php 
                        $performanceData = [];
                        foreach ($months as $month) {
                            $category = $marksByCategory[$month];
                            $performance = ($category['total'] > 0) ? ($category['obtained'] / $category['total']) * 100 : 0;
                            $performanceData[] = number_format($performance, 1);
                        }
                        echo implode(', ', $performanceData);
                    ?>],
                    borderColor: '#4BC0C0',
                    backgroundColor: 'rgba(75, 192, 192, 0.2)',
                    tension: 0.3,
                    fill: true
                }]
            }, {
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 100,
                        title: {
                            display: true,
                            text: 'Percentage (%)'
                        }
                    },
                    x: {
                        title: {
                            display: true,
                            text: 'Month'
                        }
                    }
                },
                plugins: {
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return context.dataset.label + ': ' + context.parsed.y + '%';
                            }
                        }
                    }
                }
            });
        });
    </script>
    <?php endif; ?>
</body>
</html>