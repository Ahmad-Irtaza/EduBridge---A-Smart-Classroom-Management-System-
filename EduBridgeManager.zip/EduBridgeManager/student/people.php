<?php
session_start();
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db_config.php';
require_once __DIR__ . '/../includes/functions.php';
requireStudent();

// class & access
$class_id = isset($_GET['class_id'])?(int)$_GET['class_id']:0;
if (!verifyClassAccess($class_id,$_SESSION['user_id'],$_SESSION['user_type'])) {
  redirect('../dashboard.php');
}
$class = getClassDetails($class_id);
$students = getClassStudents($class_id);

// render
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/student_sidebar.php';
?>
<div class="container-fluid">
  <div class="row justify-content-center">
    <main class="col-lg-8 col-md-10 px-4">
      <div class="content-wrapper">
        <?php include __DIR__ . '/../includes/class_nav.php'; ?>
        <h2 class="section-title"><?= htmlspecialchars($class['class_name']) ?> — People</h2>

        <h3>Teacher</h3>
        <div class="card card-body mb-4">
          <?= htmlspecialchars($class['first_name'].' '.$class['last_name']) ?>
        </div>

        <h3>Students</h3>
        <?php if ($students): ?>
          <?php foreach($students as $s): ?>
            <div class="card card-body mb-2">
              <?= htmlspecialchars($s['first_name'].' '.$s['last_name']) ?>
              <br><small class="text-lighter"><?= htmlspecialchars($s['email']) ?></small>
            </div>
          <?php endforeach; ?>
        <?php else: ?>
          <div class="empty-state">No students enrolled.</div>
        <?php endif; ?>

      </div>
    </main>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
