<?php
// student/attendance.php
session_start();
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db_config.php';
require_once __DIR__ . '/../includes/functions.php';

// only students here
requireStudent();

// get current student
$studentId = $_SESSION['user_id'];

// fetch attendance summary per class
$pdo = getDbConnection();
$attendanceData = [];
try {
    $stmt = $pdo->prepare("
        SELECT
            c.id           AS class_id,
            c.class_name,
            COUNT(a.id)    AS total_sessions,
            SUM(CASE WHEN a.status='present' THEN 1 ELSE 0 END) AS present_count,
            SUM(CASE WHEN a.status='absent'  THEN 1 ELSE 0 END) AS absent_count,
            SUM(CASE WHEN a.status='late'    THEN 1 ELSE 0 END) AS late_count
        FROM classes c
        JOIN class_enrollments ce ON ce.class_id = c.id
        LEFT JOIN attendance a
          ON a.class_id = c.id
         AND a.student_id = :sid
        WHERE ce.student_id = :sid
        GROUP BY c.id, c.class_name
        ORDER BY c.class_name
    ");
    $stmt->execute(['sid' => $studentId]);
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        // compute %: treat each late as half-present
        if ($row['total_sessions'] > 0) {
            $row['percentage'] = round(
                ($row['present_count'] + 0.5 * $row['late_count'])
                / $row['total_sessions'] * 100,
                1
            );
        } else {
            $row['percentage'] = null;
        }
        $attendanceData[] = $row;
    }
} catch (PDOException $e) {
    // log and show a generic error
    error_log("Attendance fetch error: " . $e->getMessage());
    $fetchError = "Sorry, we couldn't load your attendance right now.";
}
?>
<?php include __DIR__ . '/../includes/header.php'; ?>
<div class="dashboard-container">
  <?php include __DIR__ . '/../includes/student_sidebar.php'; ?>
  <main class="dashboard-content">
    <h1>My Attendance</h1>

    <?php if (!empty($fetchError)): ?>
      <div class="alert alert-error"><?= htmlspecialchars($fetchError) ?></div>
    <?php endif; ?>

    <?php if (empty($attendanceData)): ?>
      <div class="info-card">
        <p>No attendance records found. Check back after classes have been marked.</p>
      </div>
    <?php else: ?>
      <div class="card attendance-card">
        <table class="attendance-table">
          <thead>
            <tr>
              <th>Class</th>
              <th>Total</th>
              <th>Present</th>
              <th>Absent</th>
              <th>Late</th>
              <th>Attendance %</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($attendanceData as $r): ?>
              <tr>
                <td>
                  <a href="stream.php?class_id=<?= $r['class_id'] ?>">
                    <?= htmlspecialchars($r['class_name']) ?>
                  </a>
                </td>
                <td><?= $r['total_sessions'] ?></td>
                <td><?= $r['present_count'] ?></td>
                <td><?= $r['absent_count'] ?></td>
                <td><?= $r['late_count'] ?></td>
                <td>
                  <?= $r['percentage'] !== null
                        ? $r['percentage'] . '%'
                        : '—' ?>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </main>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
