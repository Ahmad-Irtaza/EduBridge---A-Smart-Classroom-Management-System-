<?php
// student/exam.php
ini_set('display_errors',1);
ini_set('display_startup_errors',1);
error_reporting(E_ALL);

session_start();
require_once __DIR__.'/../includes/auth.php';
require_once __DIR__.'/../includes/db_config.php';
requireStudent();

$mid = intval($_GET['mid'] ?? 0);
if (!$mid) {
  header('Location: exam_prep.php');
  exit;
}

// fetch content
$pdo = getDbConnection();
$stmt = $pdo->prepare("
  SELECT title,content
    FROM exam_preparation
   WHERE id=:mid AND student_id=:sid
");
$stmt->execute([':mid'=>$mid,':sid'=>$_SESSION['user_id']]);
$mat = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$mat) die("Material not found");

// call HF proxy for JSON quiz
$ch = curl_init('hf_proxy.php');
curl_setopt_array($ch,[
  CURLOPT_RETURNTRANSFER=>true,
  CURLOPT_POST=>true,
  CURLOPT_HTTPHEADER=>['Content-Type:application/json'],
  CURLOPT_POSTFIELDS=>json_encode([
    'action'=>'quiz_json',
    'content'=>$mat['content']
  ])
]);
$resp = curl_exec($ch);
curl_close($ch);
$data = json_decode($resp,true);
$questions = $data['questions'] ?? [];
if (!$questions) die("Quiz failed");

// save quiz in session
$_SESSION['current_quiz'] = $questions;
?>
<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><title>Exam: <?=htmlspecialchars($mat['title'])?></title></head>
<body>
  <h1>Quiz: <?=htmlspecialchars($mat['title'])?></h1>
  <form method="post" action="exam_submit.php">
    <?php foreach($questions as $i=>$q): ?>
      <div style="margin-bottom:1em">
        <strong>Q<?=($i+1)?>:</strong> <?=htmlspecialchars($q['question'])?><br>
        <?php foreach($q['choices'] as $c): ?>
          <label>
            <input type="radio"
                   name="answers[<?=$i?>]"
                   value="<?=htmlspecialchars($c)?>"
                   required>
            <?=htmlspecialchars($c)?>
          </label><br>
        <?php endforeach; ?>
      </div>
    <?php endforeach; ?>
    <button type="submit">Submit Answers</button>
  </form>
</body>
</html>
