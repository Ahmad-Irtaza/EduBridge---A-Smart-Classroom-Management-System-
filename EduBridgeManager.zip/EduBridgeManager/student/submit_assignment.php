<?php
// student/submit_assignment.php
// ----------------------------
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();

// 1) Core includes
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db_config.php';
require_once __DIR__ . '/../includes/functions.php';

// 2) Must be logged in as student
if (!isLoggedIn() || $_SESSION['user_type'] !== 'student') {
    header('Location: ../login.php');
    exit;
}

// 3) Get and validate post_id
$post_id = isset($_GET['post_id']) ? intval($_GET['post_id']) : 0;
if ($post_id <= 0) {
    header('Location: ../dashboard.php');
    exit;
}

// 4) Fetch post details and ensure it's an assignment
$post = getPostDetails($post_id);
if (!$post || $post['post_type'] !== 'assignment') {
    header('Location: ../dashboard.php');
    exit;
}

// 5) Verify student access to the class
if (!verifyClassAccess($post['class_id'], $_SESSION['user_id'], 'student')) {
    header('Location: ../dashboard.php');
    exit;
}

// 6) Check if already submitted
$submission = getSubmissionStatus($post_id, $_SESSION['user_id']);
$hasSubmitted = ($submission !== false);

// 7) Handle POST submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $content = trim($_POST['content'] ?? '');
    $file_path = null;

    // File upload (optional)
    if (!empty($_FILES['attachment']['name']) && $_FILES['attachment']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = __DIR__ . '/../uploads/submissions/post_' . $post_id . '/';
        if (!is_dir($uploadDir)) mkdir($uploadDir, 0777, true);
        $filename = $_SESSION['user_id'] . '_' . time() . '_' . basename($_FILES['attachment']['name']);
        $destination = $uploadDir . $filename;
        if (move_uploaded_file($_FILES['attachment']['tmp_name'], $destination)) {
            $file_path = 'uploads/submissions/post_' . $post_id . '/' . $filename;
        } else {
            $error = 'Error uploading file.';
        }
    }

    if (empty($error)) {
        if ($hasSubmitted) {
            // Update existing submission
            if (updateSubmission($submission['id'], $content, $file_path)) {
                $success = 'Your submission has been updated successfully.';
                $submission = getSubmissionStatus($post_id, $_SESSION['user_id']);
            } else {
                $error = 'Error updating submission.';
            }
        } else {
            // Insert new submission
            if (submitAssignment($post_id, $_SESSION['user_id'], $content, $file_path)) {
                $success = 'Your assignment has been submitted successfully.';
                $submission = getSubmissionStatus($post_id, $_SESSION['user_id']);
                $hasSubmitted = true;
            } else {
                $error = 'Error submitting assignment.';
            }
        }
    }
}

// 8) Fetch class for navigation
$class = getClassDetails($post['class_id']);

// 9) Render page
include __DIR__ . '/../includes/header.php';
?>

<div class="container-fluid">
  <div class="row">
    <?php include __DIR__ . '/../includes/student_sidebar.php'; ?>
    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
      <div class="pt-3 pb-2 mb-3 border-bottom">
        <h1><?= htmlspecialchars($class['class_name']) ?> - Assignment</h1>
      </div>

      <?php if (!empty($error)): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
      <?php endif; ?>
      <?php if (!empty($success)): ?>
        <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
      <?php endif; ?>

      <!-- Assignment Details -->
      <div class="card mb-4">
        <div class="card-header">
          <h5><?= htmlspecialchars($post['title']) ?></h5>
        </div>
        <div class="card-body">
          <p><?= nl2br(htmlspecialchars($post['content'])) ?></p>
          <?php if (!empty($post['file_path'])): ?>
            <p><a href="<?= htmlspecialchars($post['file_path']) ?>" download>Download Attachment</a></p>
          <?php endif; ?>
        </div>
      </div>

      <!-- Submission Form -->
      <div class="card">
        <div class="card-header"><h5>Your Submission</h5></div>
        <div class="card-body">
          <form method="post" enctype="multipart/form-data">
            <div class="mb-3">
              <label for="content" class="form-label">Answer</label>
              <textarea id="content" name="content" rows="5" class="form-control" required><?= $hasSubmitted ? htmlspecialchars($submission['content']) : '' ?></textarea>
            </div>
            <div class="mb-3">
              <label for="attachment" class="form-label">Attachment (optional)</label>
              <input type="file" id="attachment" name="attachment" class="form-control">
              <?php if ($hasSubmitted && !empty($submission['file_path'])): ?>
                <p>Current: <a href="<?= htmlspecialchars($submission['file_path']) ?>" download>View file</a></p>
              <?php endif; ?>
            </div>
            <button type="submit" class="btn btn-primary"><?= $hasSubmitted ? 'Update Submission' : 'Submit Assignment' ?></button>
          </form>
        </div>
      </div>
    </main>
  </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>