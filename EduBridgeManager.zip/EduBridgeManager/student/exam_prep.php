<?php
session_start();
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/student_sidebar.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>  
  <meta charset="UTF-8">
  <title>AI Chat Assistant</title>
  <link rel="stylesheet" href="../css/your-style.css">
  <style>
    /* Main chat container styling */
    .ai-chat-container {
      background-color: #1a1a2e;
      border-radius: 12px;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      width: 90%;
      max-width: 1200px;
      height: 80vh;
      display: flex;
      flex-direction: column;
      z-index: 100;
    }

    .dashboard-content {
      position: relative;
      height: calc(100vh - 60px); /* Adjust based on your header height */
    }

    .chat-header {
      background-color: #222340;
      padding: 15px 20px;
      border-bottom: 1px solid #3a3a5a;
    }

    .chat-header h2 {
      color: #ffffff;
      margin: 0;
      font-size: 1.4rem;
      display: flex;
      align-items: center;
    }

    .chat-header h2 svg {
      margin-right: 10px;
      color: #a580ff;
    }

    /* Chat messages area */
    .chat-messages {
      flex: 1;
      overflow-y: auto;
      padding: 20px;
      display: flex;
      flex-direction: column;
      gap: 15px;
      background-color: #1e1e30;
    }

    /* Message styling */
    .message {
      padding: 12px 16px;
      border-radius: 8px;
      max-width: 80%;
      word-wrap: break-word;
    }

    .bot-message {
      background-color: #73bdc1;
      color: #0c2838;
      align-self: flex-start;
      border-top-left-radius: 2px;
    }

    .user-message {
      background-color: #6c63ff;
      color: white;
      align-self: flex-end;
      border-bottom-right-radius: 2px;
    }

    /* Input area styling */
    .chat-input-container {
      display: flex;
      align-items: center;
      padding: 15px;
      background-color: #222340;
      border-top: 1px solid #3a3a5a;
    }

    .chat-input {
      flex: 1;
      padding: 12px 16px;
      border: 1px solid #3a3a5a;
      border-radius: 24px;
      background-color: #1e1e30;
      color: #ffffff;
      font-size: 0.95rem;
    }

    .chat-input:focus {
      outline: none;
      border-color: #6c63ff;
      box-shadow: 0 0 0 2px rgba(108, 99, 255, 0.2);
    }

    .send-button {
      background-color: #6c63ff;
      color: white;
      border: none;
      border-radius: 50%;
      width: 44px;
      height: 44px;
      margin-left: 10px;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: background-color 0.2s;
    }

    .send-button:hover {
      background-color: #5a52d5;
    }

    /* Hide page title when chat is displayed */
    .page-title {
      display: none;
    }

    /* For smaller screens */
    @media (max-width: 768px) {
      .ai-chat-container {
        width: 100%;
        height: 90vh;
        border-radius: 0;
      }
      
      .message {
        max-width: 90%;
      }
    }
  </style>
</head>
<body>

<div class="dashboard-container">
  <!-- sidebar injected by student_sidebar.php -->

  <div class="dashboard-content">
    <!-- Chat interface -->
    <div class="ai-chat-container">
      <div class="chat-header">
        <h2>
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.926 0 1.648-.746 1.648-1.688 0-.437-.18-.835-.437-1.125-.29-.289-.438-.652-.438-1.125a1.64 1.64 0 0 1 1.668-1.668h1.996c3.051 0 5.555-2.503 5.555-5.554C21.965 6.012 17.461 2 12 2z"></path>
            <circle cx="7.5" cy="11.5" r="1.5"></circle>
            <circle cx="12" cy="11.5" r="1.5"></circle>
            <circle cx="16.5" cy="11.5" r="1.5"></circle>
          </svg>
          AI Chat Assistant
        </h2>
      </div>
      
      <div class="chat-messages" id="chatMessages">
        <!-- Messages will be loaded here -->
      </div>
      
      <div class="chat-input-container">
        <input type="text" class="chat-input" id="userMessage" placeholder="Ask anything..." />
        <button class="send-button" id="sendButton">
          <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <line x1="22" y1="2" x2="11" y2="13"></line>
            <polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>
          </svg>
        </button>
      </div>
    </div>
  </div><!-- /.dashboard-content -->
</div><!-- /.dashboard-container -->

<script>
// Send message when Enter key is pressed
document.getElementById('userMessage').addEventListener('keypress', function(e) {
  if (e.key === 'Enter') {
    sendMessage();
  }
});

// Send message when Send button is clicked
document.getElementById('sendButton').addEventListener('click', function() {
  sendMessage();
});

// Chatbot functionality
async function sendMessage() {
  const input = document.getElementById('userMessage');
  const msg = input.value.trim();
  if (!msg) return;

  const chatMessages = document.getElementById('chatMessages');
  
  // Add user message
  const userDiv = document.createElement('div');
  userDiv.className = 'message user-message';
  userDiv.textContent = msg;
  chatMessages.appendChild(userDiv);
  
  input.value = '';

  // Show typing indicator
  const typingIndicator = document.createElement('div');
  typingIndicator.className = 'typing-indicator';
  typingIndicator.id = 'typing-indicator';
  typingIndicator.innerHTML = '<span></span><span></span><span></span>';
  chatMessages.appendChild(typingIndicator);
  
  chatMessages.scrollTop = chatMessages.scrollHeight;

  try {
    const res = await fetch('chatbot.php', {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({ message: msg })
    });
    
    const { reply } = await res.json();
    
    // Remove typing indicator
    const indicator = document.getElementById('typing-indicator');
    if (indicator) {
      chatMessages.removeChild(indicator);
    }
    
    // Add bot response
    const botDiv = document.createElement('div');
    botDiv.className = 'message bot-message';
    botDiv.textContent = 'AI: ' + reply;
    chatMessages.appendChild(botDiv);
    
  } catch (error) {
    // Remove typing indicator
    const indicator = document.getElementById('typing-indicator');
    if (indicator) {
      chatMessages.removeChild(indicator);
    }
    
    // Add error message
    const errorDiv = document.createElement('div');
    errorDiv.className = 'message bot-message';
    errorDiv.textContent = 'AI: Sorry, I couldn\'t process your request. Please try again.';
    chatMessages.appendChild(errorDiv);
    
    console.error('Error:', error);
  }
  
  chatMessages.scrollTop = chatMessages.scrollHeight;
}

// Add a welcome message when the page loads
window.addEventListener('DOMContentLoaded', () => {
  const chatMessages = document.getElementById('chatMessages');
  const welcomeMsg = document.createElement('div');
  welcomeMsg.className = 'message bot-message';
  welcomeMsg.textContent = 'AI: Hello! How can I help you today?';
  chatMessages.appendChild(welcomeMsg);
});
</script>

</body>
</html>