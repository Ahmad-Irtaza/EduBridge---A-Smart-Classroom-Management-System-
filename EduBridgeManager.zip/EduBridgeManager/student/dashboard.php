<?php
// student/dashboard.php

ini_set('display_errors',1);
ini_set('display_startup_errors',1);
error_reporting(E_ALL);

session_start();

// bring in your shared helpers & DB connection
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db_config.php';
require_once __DIR__ . '/../includes/functions.php';

// ensure only students
requireStudent();

// make sure they're logged in
if (!isLoggedIn() || $_SESSION['user_type'] !== 'student') {
    redirect('../login.php?type=student');
    exit;
}

// fetch basic user info
$studentId   = $_SESSION['user_id'];
$studentInfo = getCurrentUserInfo() ?: [];
$studentName = trim(
    ($studentInfo['first_name'] ?? '') . ' ' . ($studentInfo['last_name'] ?? '')
) ?: ($_SESSION['user_name'] ?? 'Student');

// get a PDO handle
$pdo = getDbConnection();

// 1) My Classes
$enrolledClasses = [];
try {
    $stmt = $pdo->prepare("
        SELECT 
          c.id, c.class_name, c.class_code,
          t.first_name AS teacher_first_name,
          t.last_name  AS teacher_last_name,
          COUNT(DISTINCT sp.id) AS post_count,
          COALESCE(MAX(sp.created_at), c.created_at) AS last_activity
        FROM classes c
        JOIN class_enrollments ce ON c.id = ce.class_id
        JOIN teachers t ON c.teacher_id = t.id
        LEFT JOIN stream_posts sp ON c.id = sp.class_id
        WHERE ce.student_id = :sid
        GROUP BY c.id, c.class_name, c.class_code, 
                 t.first_name, t.last_name, c.created_at
        ORDER BY last_activity DESC
    ");
    $stmt->execute(['sid' => $studentId]);
    $enrolledClasses = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Error fetching classes: ".$e->getMessage());
}

// 2) Upcoming Assignments
$recentAssignments = [];
try {
    $stmt = $pdo->prepare("
        SELECT 
          sp.id, sp.title, sp.content, sp.due_date,
          c.class_name, c.class_code, c.id AS class_id
        FROM stream_posts sp
        JOIN classes c        ON sp.class_id = c.id
        JOIN class_enrollments ce ON c.id = ce.class_id
        WHERE ce.student_id = :sid
          AND sp.post_type = 'assignment'
        ORDER BY sp.due_date ASC
        LIMIT 5
    ");
    $stmt->execute(['sid' => $studentId]);
    $recentAssignments = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Error fetching assignments: ".$e->getMessage());
}

// 3) Attendance stats
$attendanceStats = ['present'=>0,'absent'=>0,'late'=>0,'total'=>0];
try {
    $stmt = $pdo->prepare("
        SELECT status, COUNT(*) AS cnt
        FROM attendance
        WHERE student_id = :sid
        GROUP BY status
    ");
    $stmt->execute(['sid'=>$studentId]);
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        if (isset($attendanceStats[$row['status']])) {
            $attendanceStats[$row['status']] = (int)$row['cnt'];
            $attendanceStats['total'] += (int)$row['cnt'];
        }
    }
} catch (PDOException $e) {
    error_log("Error fetching attendance: ".$e->getMessage());
}

// 4) Recent Marks
$recentMarks = [];
try {
    $stmt = $pdo->prepare("
        SELECT 
          m.assignment_name, m.marks_obtained, m.total_marks, 
          c.class_name, c.class_code, m.date
        FROM marks m
        JOIN classes c ON m.class_id = c.id
        WHERE m.student_id = :sid
        ORDER BY m.date DESC
        LIMIT 5
    ");
    $stmt->execute(['sid'=>$studentId]);
    $recentMarks = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Error fetching recent marks: ".$e->getMessage());
}

// 5) Overall performance
$overallPerformance = 0.0;
try {
    $stmt = $pdo->prepare("
        SELECT 
          SUM(marks_obtained) AS obtained,
          SUM(total_marks)    AS total
        FROM marks
        WHERE student_id = :sid
    ");
    $stmt->execute(['sid'=>$studentId]);
    $res = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!empty($res['total'])) {
        $overallPerformance = ($res['obtained'] / $res['total']) * 100;
    }
} catch (PDOException $e) {
    error_log("Error calculating performance: ".$e->getMessage());
}

// 6) Exam preparation (fix json_decode null warning)
$examPreparation = [];
try {
    $stmt = $pdo->prepare("
        SELECT 
          id,
          title,
          COALESCE(checkpoints,'[]') AS checkpoints,
          created_at
        FROM exam_preparation
        WHERE student_id = :sid
        ORDER BY created_at DESC
        LIMIT 3
    ");
    $stmt->execute(['sid'=>$studentId]);
    $examPreparation = $stmt->fetchAll(PDO::FETCH_ASSOC);

    foreach ($examPreparation as &$exam) {
        // always decode a string, never null
        $raw        = $exam['checkpoints'] ?? '[]';
        $checkpoints = json_decode($raw, true);
        if (!is_array($checkpoints)) {
            $checkpoints = [];
        }
        $completed = 0;
        foreach ($checkpoints as $cp) {
            if (!empty($cp['completed'])) {
                $completed++;
            }
        }
        $total = count($checkpoints);
        $exam['completed'] = $completed;
        $exam['total']     = $total;
        $exam['progress']  = $total > 0 ? ($completed / $total)*100 : 0;
    }
    unset($exam);
} catch (PDOException $e) {
    error_log("Error fetching exam prep: ".$e->getMessage());
}
include __DIR__ . '/../includes/header.php';
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Dashboard – EduBridge</title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <link rel="stylesheet" href="../css/style.css">
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <script src="../js/charts.js" defer></script>
  <script src="../js/main.js" defer></script>
</head>
<body>
  <div class="dashboard-container">
    <?php include __DIR__ . '/../includes/student_sidebar.php'; ?>
    <main class="dashboard-content">

      <header class="dashboard-header">
        <div class="header-info">
          <h1>Dashboard</h1>
          <!-- <p>Welcome back, <?php echo htmlspecialchars($studentName); ?>!</p>
        </div>
        <div class="header-actions">
          <div class="date-display"><?php echo date('l, F j, Y'); ?></div>
          <div class="user-profile">
            <img src="../images/avatars/student.png" class="avatar" alt="">
            <div class="dropdown">
              <span class="dropdown-toggle"><?php echo htmlspecialchars($studentName); ?></span>
              <div class="dropdown-menu">
                <a href="profile.php">My Profile</a>
                <a href="../logout.php">Logout</a>
              </div>
            </div>
          </div>
        </div> -->
      </header>

      <div class="dashboard-grid">
        <!-- Performance Card -->
        <div class="dashboard-card performance-card">
          <div class="card-header"><h2>Performance</h2></div>
          <div class="card-content">
            <canvas id="performanceChart"></canvas>
            <div class="performance-value">
              <span class="value"><?php echo round($overallPerformance,1); ?>%</span>
              <span class="label">Overall</span>
            </div>
          </div>
        </div>

        <!-- Attendance Card -->
        <div class="dashboard-card attendance-card">
          <div class="card-header"><h2>Attendance</h2></div>
          <div class="card-content">
            <canvas id="attendanceChart"></canvas>
            <div class="attendance-stats">
              <div>Present: <?php echo $attendanceStats['present']; ?></div>
              <div>Absent: <?php  echo $attendanceStats['absent']; ?></div>
              <div>Late: <?php    echo $attendanceStats['late']; ?></div>
            </div>
          </div>
        </div>

        <!-- My Classes -->
        <div class="dashboard-card classes-card">
          <div class="card-header">
            <h2>My Classes</h2>
            <a href="classes.php" class="view-all">View All</a>
          </div>
          <div class="card-content">
            <?php if (empty($enrolledClasses)): ?>
              <p class="empty-state">Not enrolled in any classes.</p>
            <?php else: ?>
              <ul class="class-list">
                <?php foreach ($enrolledClasses as $c): ?>
                  <li>
                    <strong><?php echo htmlspecialchars($c['class_name']); ?></strong>
                    by <?php echo htmlspecialchars($c['teacher_first_name'].' '.$c['teacher_last_name']); ?>
                    &mdash; <?php echo (int)$c['post_count']; ?> posts
                    <a class="btn-secondary" 
                       href="stream.php?class_id=<?php echo (int)$c['id']; ?>">
                       Open
                    </a>
                  </li>
                <?php endforeach; ?>
              </ul>
            <?php endif; ?>
          </div>
        </div>

        <!-- Upcoming Assignments -->
        <div class="dashboard-card assignments-card">
          <div class="card-header"><h2>Upcoming Assignments</h2></div>
          <div class="card-content">
            <?php if (empty($recentAssignments)): ?>
              <p class="empty-state">No upcoming assignments.</p>
            <?php else: ?>
              <ul class="assignment-list">
                <?php foreach ($recentAssignments as $a): ?>
                  <li>
                    <strong><?php echo htmlspecialchars($a['title']); ?></strong>
                    <div class="due-date">
                      Due 
                      <?php 
                        echo $a['due_date']
                          ? date('M j, Y', strtotime($a['due_date']))
                          : '—';
                      ?>
                    </div>
                    <a class="btn-secondary" 
                       href="stream.php?class_id=<?php echo (int)$a['class_id']; ?>&post_id=<?php echo (int)$a['id']; ?>">
                      View
                    </a>
                  </li>
                <?php endforeach; ?>
              </ul>
            <?php endif; ?>
          </div>
        </div>

        <!-- Recent Marks -->
        <div class="dashboard-card recent-marks-card">
          <div class="card-header">
            <h2>Recent Marks</h2>
            <a href="marks.php" class="view-all">View All</a>
          </div>
          <div class="card-content">
            <?php if (empty($recentMarks)): ?>
              <p class="empty-state">No marks recorded yet.</p>
            <?php else: ?>
              <ul class="marks-list">
                <?php foreach ($recentMarks as $m): 
                  $pct = $m['total_marks']
                       ? round($m['marks_obtained']/$m['total_marks']*100,1)
                       : 0;
                ?>
                  <li>
                    <?php echo htmlspecialchars($m['assignment_name']); ?> 
                    — <?php echo $pct; ?>%
                  </li>
                <?php endforeach; ?>
              </ul>
            <?php endif; ?>
          </div>
        </div>

        <!-- Exam Prep -->
        <div class="dashboard-card exam-prep-card">
          <div class="card-header">
            <h2>Exam Preparation</h2>
            <a href="exam_prep.php" class="view-all">View All</a>
          </div>
          <div class="card-content">
            <?php if (empty($examPreparation)): ?>
              <p class="empty-state">No exam plans yet.</p>
            <?php else: ?>
              <ul class="exam-prep-list">
                <?php foreach ($examPreparation as $e): ?>
                  <li>
                    <strong><?php echo htmlspecialchars($e['title']); ?></strong>
                    <div class="progress-bar-container">
                      <div class="progress-bar" 
                           style="width:<?php echo $e['progress']; ?>%"></div>
                    </div>
                    <small>
                      <?php echo (int)$e['completed']; ?>/<?php echo (int)$e['total']; ?> 
                      checkpoints
                    </small>
                    <a class="btn-secondary" href="exam_prep.php?id=<?php echo (int)$e['id']; ?>">
                      Continue
                    </a>
                  </li>
                <?php endforeach; ?>
              </ul>
            <?php endif; ?>
          </div>
        </div>

      </div> <!-- .dashboard-grid -->

    </main>
  </div>

  <script>


document.addEventListener('DOMContentLoaded',()=>{
    // Performance chart
    const perfCtx = document.getElementById('performanceChart').getContext('2d');
    new Chart(perfCtx, {
      type: 'doughnut',
      data: {
        datasets:[{
          data:[<?= round($overallPerformance,1) ?>, 100-<?= round($overallPerformance,1) ?>],
          backgroundColor:['#36A2EB','#eee'], borderWidth:0
        }]
      },
      options:{
        circumference:180,rotation:-90,cutout:'75%',plugins:{legend:{display:false},tooltip:{enabled:false}}
      }
    });

    // Attendance chart
    const attCtx = document.getElementById('attendanceChart').getContext('2d');
    new Chart(attCtx, {
      type:'doughnut',
      data:{labels:['Present','Absent','Late'],
        datasets:[{data:[
          <?= $attendanceStats['present'] ?>,
          <?= $attendanceStats['absent'] ?>,
          <?= $attendanceStats['late'] ?>
        ],backgroundColor:['#4BC0C0','#FF6384','#FFCD56']}]},
      options:{cutout:'70%',plugins:{legend:{position:'bottom'}}}
    });
  });  </script>
</body>
</html>










