<?php
session_start();
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db_config.php';
require_once __DIR__ . '/../includes/functions.php';
requireStudent();

// class & access
$class_id = isset($_GET['class_id'])?(int)$_GET['class_id']:0;
if (!verifyClassAccess($class_id,$_SESSION['user_id'],$_SESSION['user_type'])) {
  redirect('../dashboard.php');
}
$class = getClassDetails($class_id);

// fetch assignments & grades matrix
$pdo = getDbConnection();
$stm = $pdo->prepare("
  SELECT * FROM stream_posts
   WHERE class_id=:cid AND post_type='assignment'
   ORDER BY created_at DESC
");
$stm->execute(['cid'=>$class_id]);
$assignments = $stm->fetchAll();

$students = getClassStudents($class_id);
$grades = [];
foreach($students as $s){
  foreach($assignments as $a){
    $q = $pdo->prepare("
      SELECT marks_obtained,total_marks
        FROM assignment_submissions
       WHERE post_id=:pid AND student_id=:sid
    ");
    $q->execute(['pid'=>$a['id'],'sid'=>$s['id']]);
    $r = $q->fetch();
    $grades[$s['id']][$a['id']] = $r
      ? "{$r['marks_obtained']}/{$r['total_marks']}"
      : '–';
  }
}

// render
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/student_sidebar.php';
?>
<div class="container-fluid">
  <div class="row">
    <main class="col-lg-8 col-md-10 px-4">
      <?php include __DIR__ . '/../includes/class_nav.php'; ?>
      <h2 class="section-title"><?= htmlspecialchars($class['class_name']) ?> — Grades</h2>

      <?php if ($assignments): ?>
        <div class="grades-grid mb-4">
          <?php foreach($assignments as $a): ?>
            <div class="grade-card card mb-3 p-3">
              <h5><?= htmlspecialchars($a['title']) ?></h5>
              <small class="text-lighter">
                <?= $a['due_date']? 'Due '.htmlspecialchars(formatDate($a['due_date'])) : 'No due date' ?>
              </small>
            </div>
          <?php endforeach; ?>
        </div>

        <table class="table grades-table">
          <thead>
            <tr>
              <th>Student</th>
              <?php foreach($assignments as $a): ?>
                <th><?= htmlspecialchars($a['title']) ?></th>
              <?php endforeach; ?>
            </tr>
          </thead>
          <tbody>
            <?php foreach($students as $s): ?>
              <tr>
                <td><?= htmlspecialchars($s['first_name'].' '.$s['last_name']) ?></td>
                <?php foreach($assignments as $a): ?>
                  <td><?= htmlspecialchars($grades[$s['id']][$a['id']] ?? '–') ?></td>
                <?php endforeach; ?>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>

      <?php else: ?>
        <div class="empty-state">No assignments yet.</div>
      <?php endif; ?>

    </main>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
