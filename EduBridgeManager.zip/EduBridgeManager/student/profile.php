<?php
session_start();
require_once('../includes/db_config.php');
require_once('../includes/functions.php');
require_once('../includes/auth.php');

// Ensure only logged-in students can access
if (!isLoggedIn() || $_SESSION['user_type'] !== 'student') {
    redirect('../login.php?type=student');
}

// Retrieve current student ID from session
$studentId = $_SESSION['user_id'];

// Attempt to fetch student record from database
$pdo    = getDbConnection();
$student = null;
$error   = '';

try {
    $stmt = $pdo->prepare("SELECT * FROM students WHERE id = :id");
    $stmt->execute(['id' => $studentId]);
    $student = $stmt->fetch();
} catch (PDOException $e) {
    $error = "Database error: " . $e->getMessage();
}

// If no student record is found, set an error
if (!$student && empty($error)) {
    $error = "No student record found for your account.";
}

// Construct student’s display name
$studentName = $student ? $student['first_name'] . ' ' . $student['last_name'] : '';
include __DIR__ . '/../includes/header.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile - EduBridge</title>
    <link rel="stylesheet" href="../css/style.css">
    <!-- Inline CSS for profile layout using flex for three columns -->
    <style>
        /* Header overrides */
        .dashboard-header h1 {
            color:rgb(241, 245, 246); /* Light Blue */
        }

        /* Global resets remain in effect from your global CSS if any */

        /* Dashboard Layout modifications: profile card details */
        .profile-details {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
        }
        
        /* Each column occupies an equal share */
        .profile-column {
            flex: 1;
            min-width: 280px;
            background-color:rgb(167, 159, 188);  /* Light gray container */
            padding: 15px;
            border: 1px solid #dee2e6;
            border-radius: 6px;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
        }
        
        .profile-column h3 {
            font-size: 18px;
            margin-bottom: 10px;
            color: #2563EB;  /* Light blue for section headings */
        }
        
        .profile-column p {
            font-size: 14px;
            margin-bottom: 6px;
            color:rgb(11, 11, 11);
        }
        
        .profile-column p strong {
            color: #212529;
        }
    </style>
    <!-- Optional scripts -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="../js/charts.js" defer></script>
    <script src="../js/main.js" defer></script>
</head>
<body>
    <div class="dashboard-container">
        <!-- Do not change the sidebar; it is included as before -->
        <?php include('../includes/student_sidebar.php'); ?>

        <main class="dashboard-content">
            <!-- Header Section (same as dashboard) -->
            <header class="dashboard-header">
                <div class="header-info">
                    <h1>Profile</h1>
                    <!-- <?php if ($studentName): ?>
                        <p>Welcome back, <?php echo htmlspecialchars($studentName); ?>!</p>
                    <?php endif; ?>
                </div>

                <div class="header-actions">
                    <div class="date-display"><?php echo date('l, F j, Y'); ?></div>
                    <div class="user-profile">
                        <img src="../images/avatars/student.png" alt="Profile" class="avatar">
                        <div class="dropdown">
                            <span class="dropdown-toggle"><?php echo htmlspecialchars($studentName); ?></span>
                            <div class="dropdown-menu">
                                <a href="profile.php">My Profile</a>
                                <a href="../logout.php">Logout</a>
                            </div>
                        </div>
                    </div>
                </div> -->
            </header>

            <!-- Main Profile Content -->
            <div class="dashboard-grid">
                <div class="dashboard-card full-width-card">
                    <div class="card-header">
                        <h2>My Profile Information</h2>
                    </div>
                    <div class="card-content">
                        <?php if (!empty($error)): ?>
                            <div class="error-message">
                                <?php echo $error; ?>
                            </div>
                        <?php elseif ($student): ?>
                            <div class="profile-details">
                                <!-- Left Column: Personal Information -->
                                <div class="profile-column">
                                    <h3>Personal Information</h3>
                                    <p><strong>First Name:</strong> <?php echo htmlspecialchars($student['first_name']); ?></p>
                                    <p><strong>Last Name:</strong> <?php echo htmlspecialchars($student['last_name']); ?></p>
                                    <p><strong>Gender:</strong> <?php echo htmlspecialchars($student['gender']); ?></p>
                                    <p><strong>Date of Birth:</strong> <?php echo htmlspecialchars($student['dob']); ?></p>
                                    <p><strong>CNIC:</strong> <?php echo htmlspecialchars($student['cnic']); ?></p>
                                    <p><strong>Father’s Name:</strong> <?php echo htmlspecialchars($student['father_name']); ?></p>
                                    <p><strong>Father’s CNIC:</strong> <?php echo htmlspecialchars($student['father_cnic']); ?></p>
                                    <p><strong>Nationality:</strong> <?php echo htmlspecialchars($student['nationality']); ?></p>
                                    <p><strong>Blood Group:</strong> <?php echo htmlspecialchars($student['blood_group']); ?></p>
                                </div>
                                
                                <!-- Middle Column: Academic & Account Information -->
                                <div class="profile-column">
                                    <h3>Academic & Account</h3>
                                    <p><strong>Email:</strong> <?php echo htmlspecialchars($student['email']); ?></p>
                                    <p><strong>Username:</strong> <?php echo htmlspecialchars($student['username']); ?></p>
                                    <p><strong>Qualification:</strong> <?php echo htmlspecialchars($student['qualification']); ?></p>
                                    <p><strong>Department:</strong> <?php echo htmlspecialchars($student['department']); ?></p>
                                    <p><strong>Joined On:</strong>
                                        <?php echo !empty($student['created_at']) ? date('F j, Y', strtotime($student['created_at'])) : 'N/A'; ?>
                                    </p>
                                </div>
                                
                                <!-- Right Column: Contact & Address -->
                                <div class="profile-column">
                                    <h3>Contact & Address</h3>
                                    <p><strong>Phone:</strong> <?php echo htmlspecialchars($student['phone']); ?></p>
                                    <p><strong>Address:</strong> <?php echo htmlspecialchars($student['address']); ?></p>
                                    <p><strong>City:</strong> <?php echo htmlspecialchars($student['city']); ?></p>
                                    <p><strong>Postal Code:</strong> <?php echo htmlspecialchars($student['postal_code']); ?></p>
                                    <p><strong>Country:</strong> <?php echo htmlspecialchars($student['country']); ?></p>
                                </div>
                            </div>
                        <?php else: ?>
                            <div class="empty-state">
                                <p>No profile data available.</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </main>
    </div>
</body>
</html>
