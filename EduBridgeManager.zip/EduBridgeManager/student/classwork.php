<?php
session_start();
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db_config.php';
require_once __DIR__ . '/../includes/functions.php';
requireStudent();

// class & access
$class_id = isset($_GET['class_id'])?(int)$_GET['class_id']:0;
if (!verifyClassAccess($class_id,$_SESSION['user_id'],$_SESSION['user_type'])) {
  redirect('../dashboard.php');
}
$class = getClassDetails($class_id);

// fetch posts & split
$all = getStreamPosts($class_id);
$assignments = array_filter($all, fn($p)=> $p['post_type']==='assignment');
$materials   = array_filter($all, fn($p)=> $p['post_type']==='material');

// render
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/student_sidebar.php';
?>
<div class="container-fluid">
  <div class="row justify-content-center">
    <main class="col-lg-8 col-md-10 px-4">
      <div class="content-wrapper">
        <?php include __DIR__ . '/../includes/class_nav.php'; ?>
        <h2 class="section-title"><?= htmlspecialchars($class['class_name']) ?> — Classwork</h2>

        <form method="get" action="classwork.php" class="mb-4">
          <label>Select Class:</label>
          <select name="class_id" onchange="this.form.submit()" class="form-control">
            <?php foreach(getEnrolledClasses($_SESSION['user_id']) as $c): ?>
              <option value="<?= $c['id'] ?>" <?= $c['id']===$class_id?'selected':'' ?>>
                <?= htmlspecialchars($c['class_name']) ?>
              </option>
            <?php endforeach; ?>
          </select>
        </form>

        <?php if ($assignments): ?>
          <h3>Assignments</h3>
          <?php foreach($assignments as $a): ?>
            <div class="card card-body mb-4">
              <h5><?= htmlspecialchars($a['title']) ?></h5>
              <p><?= nl2br(htmlspecialchars($a['content'])) ?></p>
              <?php if (!empty($a['file_path'])): ?>
                <a href="<?= htmlspecialchars($a['file_path']) ?>" download class="btn btn-outline-primary btn-sm">
                  Download
                </a>
              <?php endif; ?>
            </div>
          <?php endforeach; ?>
        <?php endif; ?>

        <?php if ($materials): ?>
          <h3>Study Materials</h3>
          <?php foreach($materials as $m): ?>
            <div class="card card-body mb-4">
              <h5><?= htmlspecialchars($m['title']) ?></h5>
              <p><?= nl2br(htmlspecialchars($m['content'])) ?></p>
              <?php if (!empty($m['file_path'])): ?>
                <a href="<?= htmlspecialchars($m['file_path']) ?>" download class="btn btn-outline-primary btn-sm">
                  Download
                </a>
              <?php endif; ?>
            </div>
          <?php endforeach; ?>
        <?php endif; ?>

      </div>
    </main>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
