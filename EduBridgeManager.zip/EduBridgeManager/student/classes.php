<?php
session_start();
require_once('../includes/db_config.php');
require_once('../includes/functions.php');
require_once('../includes/auth.php');

// Check if user is logged in and is a student
if (!isLoggedIn() || $_SESSION['user_type'] !== 'student') {
    redirect('../login.php?type=student');
}

// Get student information
$studentId = $_SESSION['user_id'];
$studentName = isset($_SESSION['user_name']) ? $_SESSION['user_name'] : '';

// Get complete student information
$studentInfo = getCurrentUserInfo();
if (!empty($studentInfo)) {
    $studentName = $studentInfo['first_name'] . ' ' . $studentInfo['last_name'];
}

// Get PDO connection
$pdo = getDbConnection();

// Function to fetch enrolled classes
function getEnrolledClasses($pdo, $studentId) {
    $stmt = $pdo->prepare("
        SELECT c.id, c.class_name, c.class_code, c.description, 
               t.first_name AS teacher_first_name, t.last_name AS teacher_last_name,
               COUNT(DISTINCT sp.id) AS post_count, MAX(sp.created_at) AS last_activity
        FROM classes c
        JOIN class_enrollments ce ON c.id = ce.class_id
        JOIN teachers t ON c.teacher_id = t.id
        LEFT JOIN stream_posts sp ON c.id = sp.class_id
        WHERE ce.student_id = :student_id
        GROUP BY c.id, c.class_name, c.class_code, c.description, t.first_name, t.last_name
        ORDER BY last_activity DESC
    ");
    $stmt->execute(['student_id' => $studentId]);
    return $stmt->fetchAll();
}

// Fetch enrolled classes
$enrolledClasses = getEnrolledClasses($pdo, $studentId);

// Process class join
$success = $error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['class_code'])) {
    $classCode = sanitize($_POST['class_code']);
    
    try {
        // Check if class exists and if the student is already enrolled
        $stmt = $pdo->prepare("
            SELECT c.id, ce.id AS enrollment_id 
            FROM classes c
            LEFT JOIN class_enrollments ce ON ce.class_id = c.id AND ce.student_id = :student_id
            WHERE c.class_code = :class_code
        ");
        $stmt->execute([
            'student_id' => $studentId,
            'class_code' => $classCode
        ]);
        $class = $stmt->fetch();
        
        if ($class) {
            if ($class['enrollment_id']) {
                $error = "You are already enrolled in this class.";
            } else {
                // Enroll student
                $stmt = $pdo->prepare("
                    INSERT INTO class_enrollments (class_id, student_id)
                    VALUES (:class_id, :student_id)
                ");
                $stmt->execute([
                    'class_id' => $class['id'],
                    'student_id' => $studentId
                ]);
                $success = "Successfully joined class. Refreshing your class list...";
                
                // Refresh enrolled classes
                $enrolledClasses = getEnrolledClasses($pdo, $studentId);
            }
        } else {
            $error = "Invalid class code. Please check and try again.";
        }
    } catch (PDOException $e) {
        $error = "Database error: " . $e->getMessage();
    }
}
include __DIR__ . '/../includes/header.php';

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Classes - EduBridge</title>
    <link rel="stylesheet" href="../css/style.css">
    <script src="../js/main.js" defer></script>
    
    <style>
        /* Initially hide the modal */
        #join-class-form {
            display: none;
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <?php include('../includes/student_sidebar.php'); ?>
        
        <main class="dashboard-content">
            <header class="dashboard-header">
                <div class="header-info">
                    <h1>My Classes</h1>
                    <!-- <p>Manage your enrolled classes</p> -->
                </div>
                
                <!-- <div class="header-actions">
                    <div class="date-display"><?php echo date('l, F j, Y'); ?></div>
                    <div class="user-profile">
                        <img src="../images/avatars/student.png" alt="Profile" class="avatar">
                        <div class="dropdown">
                            <span class="dropdown-toggle"><?php echo htmlspecialchars($studentName); ?></span>
                            <div class="dropdown-menu">
                                <a href="profile.php">My Profile</a>
                                <a href="../logout.php">Logout</a>
                            </div>
                        </div>
                    </div>
                </div> -->
            </header>
            
            <div class="main-content">
                <?php if ($success): ?>
                    <div class="success-message"><?php echo $success; ?></div>
                <?php endif; ?>
                
                <?php if ($error): ?>
                    <div class="error-message"><?php echo $error; ?></div>
                <?php endif; ?>
                
                <div class="actions-bar">
                    <button id="join-class-btn" class="btn-primary">Join a Class</button>
                </div>
                
                <!-- The Join Class Modal Form -->
                <div id="join-class-form" class="modal">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h3 class="modal-title">Join a Class</h3>
                            <span class="close-modal">&times;</span>
                        </div>
                        <div class="modal-body">
                            <form action="classes.php" method="POST">
                                <div class="form-group">
                                    <label for="class_code">Enter Class Code</label>
                                    <input type="text" id="class_code" name="class_code" required>
                                    <p class="form-hint">Ask your teacher for the class code</p>
                                </div>
                                <div class="form-actions">
                                    <button type="submit" class="btn-primary">Join Class</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                
                <h2 class="section-title">Enrolled Classes</h2>
                
                <?php if (empty($enrolledClasses)): ?>
                    <div class="empty-state">
                        <p>You are not enrolled in any classes yet.</p>
                        <p>Use the "Join a Class" button to enter a class code provided by your teacher.</p>
                    </div>
                <?php else: ?>
                    <div class="class-cards">
                        <?php foreach ($enrolledClasses as $class): ?>
                            <div class="class-card">
                                <div class="class-header">
                                    <h3><?php echo htmlspecialchars($class['class_name']); ?></h3>
                                    <p class="class-teacher">Teacher: <?php echo htmlspecialchars($class['teacher_first_name'] . ' ' . $class['teacher_last_name']); ?></p>
                                </div>
                                <div class="class-body">
                                    <div class="class-code">Code: <?php echo htmlspecialchars($class['class_code']); ?></div>
                                    <?php if (!empty($class['description'])): ?>
                                        <p class="class-description"><?php echo htmlspecialchars($class['description']); ?></p>
                                    <?php endif; ?>
                                    <div class="class-stats">
                                        <span class="post-count"><?php echo $class['post_count']; ?> posts</span>
                                        <span class="activity-date">
                                            <?php 
                                            if ($class['last_activity']) {
                                                echo 'Last activity: ' . date('M j, Y', strtotime($class['last_activity']));
                                            } else {
                                                echo 'No activity yet';
                                            }
                                            ?>
                                        </span>
                                    </div>
                                    <div class="class-actions">
                                        <a href="stream.php?class_id=<?php echo $class['id']; ?>" class="class-btn">Open Stream</a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </main>
    </div>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Modal functionality
            const modal = document.getElementById('join-class-form');
            const btn = document.getElementById('join-class-btn');
            const closeBtn = document.querySelector('.close-modal');
            
            // Show modal when "Join a Class" button is clicked
            btn.addEventListener('click', () => {
                modal.style.display = 'block';
            });
            
            // Close modal when "x" button is clicked
            closeBtn.addEventListener('click', () => {
                modal.style.display = 'none';
            });
            
            // Close modal if user clicks outside of the modal content
            window.addEventListener('click', (e) => {
                if (e.target === modal) {
                    modal.style.display = 'none';
                }
            });
        });
    </script>
</body>
</html>
