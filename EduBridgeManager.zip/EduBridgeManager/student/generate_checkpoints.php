<?php
session_start();
header('Content-Type: application/json');

$file = $_SESSION['uploaded_file'] ?? '';
if (!$file || !file_exists($file)) {
    echo json_encode(["success" => false]);
    exit;
}

// Simple fake checkpoint generator
$content = file_get_contents($file);
$sentences = preg_split('/(\.|\n)/', $content);
$chunks = array_chunk($sentences, 5);

$checkpoints = [];
foreach ($chunks as $chunk) {
    $text = implode(' ', $chunk);
    $minutes = rand(5, 8);
    $checkpoints[] = ["text" => $text, "minutes" => $minutes];
}

echo json_encode(["success" => true, "checkpoints" => $checkpoints]);
