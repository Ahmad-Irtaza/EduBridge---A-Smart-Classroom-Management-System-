<?php
session_start();
header('Content-Type: application/json');

// Retrieve the user's message from the POST request
$data = json_decode(file_get_contents('php://input'), true);
$userMessage = $data['message'] ?? '';

// Your Groq API key
$apiKey = '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';

// Prepare the payload for the API request
$payload = [
    'model' => 'meta-llama/llama-4-scout-17b-16e-instruct',
    'messages' => [
        ['role' => 'user', 'content' => $userMessage]
    ],
    'temperature' => 0.7,
    'max_tokens' => 300,
    'stream' => false
];

// Initialize cURL session
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://api.groq.com/openai/v1/chat/completions');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Authorization: Bearer ' . $apiKey,
    'Content-Type: application/json'
]);

// Execute the API request
$response = curl_exec($ch);
$error = curl_error($ch);
curl_close($ch);

// Handle cURL errors
if ($error) {
    echo json_encode(['reply' => 'API Error: ' . $error]);
    exit;
}

// Decode the API response
$result = json_decode($response, true);

// Extract and return the assistant's reply
if (isset($result['choices'][0]['message']['content'])) {
    $reply = $result['choices'][0]['message']['content'];
    echo json_encode(['reply' => $reply]);
} else {
    $rawError = $result['error']['message'] ?? 'Unknown error from AI.';
    echo json_encode(['reply' => 'AI Error: ' . $rawError]);
}
