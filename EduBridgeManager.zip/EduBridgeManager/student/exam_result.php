<?php
// exam_result.php
session_start();
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db_config.php';
require_once __DIR__ . '/../includes/functions.php';
requireStudent();

header('Content-Type: application/json');

$materialId = intval($_GET['materialId'] ?? 0);

if (!$materialId) {
    echo json_encode(['error' => 'Material ID is missing']);
    exit;
}

// You can fetch the material from DB if you want, or fake it
$quiz = [
    ['question' => 'What is the main idea of the material?', 'options' => ['A', 'B', 'C', 'D']],
    ['question' => 'Explain one key concept.', 'options' => ['A', 'B', 'C', 'D']],
    ['question' => 'Summarize the lecture in one line.', 'options' => ['A', 'B', 'C', 'D']]
];

echo json_encode(['quiz' => $quiz]);
