<?php
session_start();
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db_config.php';
require_once __DIR__ . '/../includes/functions.php';

// only students
requireStudent();

// get & verify class
$class_id = isset($_GET['class_id']) ? (int)$_GET['class_id'] : 0;
if (!verifyClassAccess($class_id, $_SESSION['user_id'], $_SESSION['user_type'])) {
    redirect('../dashboard.php');
}

// fetch class & posts, filter out the test stub
$class = getClassDetails($class_id);
$allPosts = getStreamPosts($class_id);
$streamPosts = array_filter($allPosts, fn($p)=> trim($p['content'])!=='This is a test post to confirm everything is working!');

// handle comments
if ($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['action']??'')==='add_comment') {
  $pid = (int)$_POST['post_id'];
  $c = trim($_POST['comment']);
  if (addPostComment($pid, $_SESSION['user_id'], $_SESSION['user_type'], $c)) {
    header("Location: stream.php?class_id={$class_id}");
    exit;
  } else {
    $error = "Error adding comment.";
  }
}

// render
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/student_sidebar.php';
?>
<div class="container-fluid">
  <div class="row justify-content-center">
    <main class="col-lg-8 col-md-10 px-4">
      <div class="content-wrapper">
        <?php include __DIR__ . '/../includes/class_nav.php'; ?>
        <h2 class="section-title"><?= htmlspecialchars($class['class_name']) ?> — Stream</h2>
        <?php if (!empty($error)): ?>
          <div class="notification error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="stream-posts">
          <?php foreach($streamPosts as $post): ?>
            <div class="post-card card mb-5">
              <div class="card-header d-flex justify-content-between align-items-center">
                <strong><?= htmlspecialchars(getUserName($post['user_id'],$post['user_type'])) ?></strong>
                <span class="badge post-type"><?= ucfirst(htmlspecialchars($post['post_type'])) ?></span>
              </div>
              <div class="card-body">
                <h5><?= htmlspecialchars($post['title']) ?></h5>
                <p><?= nl2br(htmlspecialchars($post['content'])) ?></p>

                <?php if (!empty($post['file_path'])): ?>
                  <a href="<?= htmlspecialchars($post['file_path']) ?>" download class="btn btn-outline-primary btn-sm mb-2">
                    Download
                  </a>
                <?php endif; ?>

                <?php if ($post['post_type']==='assignment' && !empty($post['due_date'])): ?>
                  <div class="text-muted mb-2">
                    <strong>Due:</strong> <?= htmlspecialchars(formatDate($post['due_date'])) ?>
                  </div>
                  <?php if ($sub = getSubmissionStatus($post['id'],$_SESSION['user_id'])): ?>
                    <div class="mb-2 text-success">
                      Submitted <?= htmlspecialchars(formatDate($sub['submitted_at'])) ?>
                      <?php if ($sub['marks_obtained']!==null): ?>
                        — Grade <?= htmlspecialchars($sub['marks_obtained']).'/'.htmlspecialchars($sub['total_marks']) ?>
                      <?php endif; ?>
                    </div>
                  <?php else: ?>
                    <a href="submit_assignment.php?post_id=<?= $post['id'] ?>" class="btn btn-secondary btn-sm mb-2">
                      Submit Assignment
                    </a>
                  <?php endif; ?>
                <?php endif; ?>
              </div>
              <div class="card-footer">
                <?php foreach(getPostComments($post['id']) as $c): ?>
                  <div class="mb-3">
                    <strong><?= htmlspecialchars(getUserName($c['user_id'],$c['user_type'])) ?></strong>
                    <small class="text-lighter ms-2"><?= htmlspecialchars(formatDate($c['created_at'])) ?></small>
                    <div><?= nl2br(htmlspecialchars($c['comment'])) ?></div>
                  </div>
                <?php endforeach; ?>

                <form action="stream.php?class_id=<?= $class_id ?>" method="post" class="d-flex gap-2">
                  <input type="hidden" name="action" value="add_comment">
                  <input type="hidden" name="post_id" value="<?= $post['id'] ?>">
                  <input type="text" name="comment" class="form-control" placeholder="Add a comment…" required>
                  <button class="btn btn-secondary">Send</button>
                </form>
              </div>
            </div>
          <?php endforeach; ?>
        </div>

      </div>
    </main>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
