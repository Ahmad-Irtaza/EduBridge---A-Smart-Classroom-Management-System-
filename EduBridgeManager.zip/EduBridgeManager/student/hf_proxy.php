<?php
// hf_proxy.php
session_start();
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db_config.php';
require_once __DIR__ . '/../includes/functions.php';
requireStudent();

header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);

if (!$data || !isset($data['action'])) {
    echo json_encode(['error' => 'Invalid request']);
    exit;
}

$action = $data['action'];

switch ($action) {
    case 'checkpoints':
        $materialId = intval($data['materialId'] ?? 0);
        if (!$materialId) {
            echo json_encode(['error' => 'Material ID missing']);
            exit;
        }

        // Fake checkpoint generation (for now)
        $checkpoints = [
            "Checkpoint 1: Introduction",
            "Checkpoint 2: Important Concepts",
            "Checkpoint 3: Summary Points"
        ];
        echo json_encode(['checkpoints' => $checkpoints]);
        break;

    case 'define':
        $term = sanitize($data['term'] ?? '');
        if (!$term) {
            echo json_encode(['error' => 'Term missing']);
            exit;
        }

        // Fake definition (for now)
        $definition = "Definition of {$term}: This is a placeholder definition.";
        echo json_encode(['definition' => $definition]);
        break;

    default:
        echo json_encode(['error' => 'Unknown action']);
}
