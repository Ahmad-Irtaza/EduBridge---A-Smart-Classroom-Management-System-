/**
 * EduBridge - Exam Preparation Functionality
 */

class ExamPreparationManager {
    constructor() {
        this.initEventListeners();
        this.loadExamMaterials();
    }
    
    /**
     * Initialize event listeners for exam preparation functionality
     */
    initEventListeners() {
        // View material buttons
        const viewMaterialButtons = document.querySelectorAll('.view-material-btn');
        viewMaterialButtons.forEach(button => {
            button.addEventListener('click', (e) => {
                const materialId = e.target.getAttribute('data-id');
                this.viewMaterial(materialId);
            });
        });
        
        // Study with AI buttons
        const studyMaterialButtons = document.querySelectorAll('.study-material-btn');
        studyMaterialButtons.forEach(button => {
            button.addEventListener('click', (e) => {
                const materialId = e.target.getAttribute('data-id');
                this.studyWithAI(materialId);
            });
        });
        
        // Generate checkpoints button
        const generateCheckpointsButton = document.getElementById('generate-checkpoints');
        if (generateCheckpointsButton) {
            generateCheckpointsButton.addEventListener('click', this.generateCheckpoints.bind(this));
        }
        
        // Generate quiz button
        const generateQuizButton = document.getElementById('generate-quiz');
        if (generateQuizButton) {
            generateQuizButton.addEventListener('click', this.generateQuiz.bind(this));
        }
        
        // Ask AI button
        const askAIButton = document.getElementById('ask-ai');
        if (askAIButton) {
            askAIButton.addEventListener('click', this.askAI.bind(this));
        }
        
        // Submit quiz button
        const submitQuizButton = document.getElementById('submit-quiz');
        if (submitQuizButton) {
            submitQuizButton.addEventListener('click', this.submitQuiz.bind(this));
        }
    }
    
    /**
     * Load exam materials from the server
     */
    loadExamMaterials() {
        // This functionality is primarily handled by PHP
        // Materials are loaded server-side and displayed directly
    }
    
    /**
     * View a study material
     * 
     * @param {string} materialId ID of the material to view
     */
    viewMaterial(materialId) {
        fetch(`../api/users.php?action=get_exam_material&id=${materialId}`)
            .then(response => response.json())
            .then(data => {
                if (data.success && data.material) {
                    const modal = document.getElementById('viewMaterialModal');
                    const titleElement = document.getElementById('material-title');
                    const contentElement = document.getElementById('material-content');
                    
                    titleElement.textContent = data.material.title;
                    contentElement.innerHTML = data.material.content.replace(/\n/g, '<br>');
                    
                    modal.style.display = 'block';
                    document.body.style.overflow = 'hidden';
                } else {
                    this.showNotification(data.message || 'Failed to load material', 'error');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                this.showNotification('An error occurred. Please try again.', 'error');
            });
    }
    
    /**
     * Study a material with AI assistance
     * 
     * @param {string} materialId ID of the material to study
     */
    studyWithAI(materialId) {
        fetch(`../api/users.php?action=get_exam_material&id=${materialId}`)
            .then(response => response.json())
            .then(data => {
                if (data.success && data.material) {
                    const modal = document.getElementById('studyMaterialModal');
                    const titleElement = document.getElementById('study-material-title');
                    
                    titleElement.textContent = data.material.title;
                    
                    // Set current material ID for future use
                    this.currentMaterialId = materialId;
                    this.currentMaterial = data.material;
                    
                    // Reset UI
                    document.getElementById('checkpoints-list').innerHTML = '';
                    document.getElementById('chat-container').innerHTML = '';
                    document.getElementById('quiz-container').style.display = 'none';
                    document.getElementById('generate-quiz').style.display = 'none';
                    document.getElementById('quiz-questions').innerHTML = '';
                    document.getElementById('quiz-results').innerHTML = '';
                    
                    // Show any existing checkpoints
                    if (data.material.checkpoints) {
                        try {
                            const checkpoints = JSON.parse(data.material.checkpoints);
                            this.displayCheckpoints(checkpoints);
                            document.getElementById('generate-quiz').style.display = 'block';
                        } catch (e) {
                            console.error('Error parsing checkpoints:', e);
                        }
                    }
                    
                    modal.style.display = 'block';
                    document.body.style.overflow = 'hidden';
                } else {
                    this.showNotification(data.message || 'Failed to load material', 'error');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                this.showNotification('An error occurred. Please try again.', 'error');
            });
    }
    
    /**
     * Generate study checkpoints for the current material
     */
    generateCheckpoints() {
        if (!this.currentMaterialId || !this.currentMaterial) {
            this.showNotification('No material selected', 'error');
            return;
        }
        
        const checkpointsContainer = document.getElementById('checkpoints-list');
        checkpointsContainer.innerHTML = '<p>Generating checkpoints... This may take a moment.</p>';
        
        fetch('../api/users.php?action=generate_checkpoints', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                material_id: this.currentMaterialId,
                content: this.currentMaterial.content
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success && data.checkpoints) {
                this.displayCheckpoints(data.checkpoints);
                document.getElementById('generate-quiz').style.display = 'block';
                
                // Save the checkpoints to the database
                this.saveCheckpoints(data.checkpoints);
            } else {
                checkpointsContainer.innerHTML = '<p>Failed to generate checkpoints. Please try again.</p>';
                this.showNotification(data.message || 'Failed to generate checkpoints', 'error');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            checkpointsContainer.innerHTML = '<p>An error occurred. Please try again.</p>';
            this.showNotification('An error occurred. Please try again.', 'error');
        });
    }
    
    /**
     * Display checkpoints in the UI
     * 
     * @param {Array} checkpoints Array of checkpoint objects
     */
    displayCheckpoints(checkpoints) {
        const checkpointsContainer = document.getElementById('checkpoints-list');
        checkpointsContainer.innerHTML = '';
        
        this.checkpoints = checkpoints;
        
        checkpoints.forEach((checkpoint, index) => {
            const checkpointElement = document.createElement('div');
            checkpointElement.className = 'checkpoint-item';
            checkpointElement.innerHTML = `
                <strong>Checkpoint ${index + 1}:</strong> ${checkpoint.title}
                <p>${checkpoint.description}</p>
            `;
            checkpointsContainer.appendChild(checkpointElement);
        });
    }
    
    /**
     * Save checkpoints to the database
     * 
     * @param {Array} checkpoints Array of checkpoint objects
     */
    saveCheckpoints(checkpoints) {
        fetch('../api/users.php?action=save_checkpoints', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                material_id: this.currentMaterialId,
                checkpoints: JSON.stringify(checkpoints)
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                this.showNotification('Checkpoints saved successfully', 'success');
            } else {
                console.error('Failed to save checkpoints:', data.message);
            }
        })
        .catch(error => {
            console.error('Error saving checkpoints:', error);
        });
    }
    
    /**
     * Generate a quiz for the current material based on the checkpoints
     */
    generateQuiz() {
        if (!this.currentMaterialId || !this.checkpoints) {
            this.showNotification('No checkpoints available. Generate checkpoints first.', 'error');
            return;
        }
        
        const quizContainer = document.getElementById('quiz-container');
        const quizQuestionsContainer = document.getElementById('quiz-questions');
        
        quizQuestionsContainer.innerHTML = '<p>Generating quiz... This may take a moment.</p>';
        quizContainer.style.display = 'block';
        
        fetch('../api/users.php?action=generate_quiz', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                material_id: this.currentMaterialId,
                checkpoints: this.checkpoints
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success && data.quiz && data.quiz.length > 0) {
                this.displayQuiz(data.quiz);
            } else {
                quizQuestionsContainer.innerHTML = '<p>Failed to generate quiz. Please try again.</p>';
                this.showNotification(data.message || 'Failed to generate quiz', 'error');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            quizQuestionsContainer.innerHTML = '<p>An error occurred. Please try again.</p>';
            this.showNotification('An error occurred. Please try again.', 'error');
        });
    }
    
    /**
     * Display quiz questions in the UI
     * 
     * @param {Array} questions Array of quiz question objects
     */
    displayQuiz(questions) {
        const quizQuestionsContainer = document.getElementById('quiz-questions');
        quizQuestionsContainer.innerHTML = '';
        
        this.quizQuestions = questions;
        
        questions.forEach((question, index) => {
            const questionElement = document.createElement('div');
            questionElement.className = 'quiz-question';
            
            let optionsHtml = '';
            question.options.forEach((option, optionIndex) => {
                optionsHtml += `
                    <div class="quiz-option">
                        <input type="radio" id="q${index}_o${optionIndex}" name="q${index}" value="${optionIndex}">
                        <label for="q${index}_o${optionIndex}">${option}</label>
                    </div>
                `;
            });
            
            questionElement.innerHTML = `
                <p><strong>Question ${index + 1}:</strong> ${question.question}</p>
                <div class="quiz-options">
                    ${optionsHtml}
                </div>
            `;
            
            quizQuestionsContainer.appendChild(questionElement);
        });
    }
    
    /**
     * Submit the quiz answers and show results
     */
    submitQuiz() {
        if (!this.quizQuestions) {
            this.showNotification('No quiz questions available', 'error');
            return;
        }
        
        const resultsContainer = document.getElementById('quiz-results');
        resultsContainer.innerHTML = '';
        
        let score = 0;
        const answers = [];
        
        this.quizQuestions.forEach((question, index) => {
            const selectedOption = document.querySelector(`input[name="q${index}"]:checked`);
            
            if (selectedOption) {
                const userAnswer = parseInt(selectedOption.value);
                const isCorrect = userAnswer === question.correctAnswer;
                
                if (isCorrect) {
                    score++;
                }
                
                answers.push({
                    question: question.question,
                    userAnswer: userAnswer,
                    correctAnswer: question.correctAnswer,
                    isCorrect: isCorrect
                });
            } else {
                answers.push({
                    question: question.question,
                    userAnswer: null,
                    correctAnswer: question.correctAnswer,
                    isCorrect: false
                });
            }
        });
        
        const percentage = (score / this.quizQuestions.length) * 100;
        
        // Display results
        let resultsHtml = `
            <div class="quiz-score">
                <h4>Your Score: ${score}/${this.quizQuestions.length} (${percentage.toFixed(2)}%)</h4>
            </div>
            <div class="quiz-answers">
                <h4>Review:</h4>
        `;
        
        answers.forEach((answer, index) => {
            resultsHtml += `
                <div class="quiz-answer ${answer.isCorrect ? 'correct' : 'incorrect'}">
                    <p><strong>Question ${index + 1}:</strong> ${answer.question}</p>
                    <p>Your answer: ${answer.userAnswer !== null ? this.quizQuestions[index].options[answer.userAnswer] : 'Not answered'}</p>
                    <p>Correct answer: ${this.quizQuestions[index].options[answer.correctAnswer]}</p>
                </div>
            `;
        });
        
        resultsHtml += '</div>';
        resultsContainer.innerHTML = resultsHtml;
    }
    
    /**
     * Ask the AI a question about the current material
     */
    askAI() {
        if (!this.currentMaterialId || !this.currentMaterial) {
            this.showNotification('No material selected', 'error');
            return;
        }
        
        const questionInput = document.getElementById('user-question');
        const question = questionInput.value.trim();
        
        if (!question) {
            this.showNotification('Please enter a question', 'error');
            return;
        }
        
        const chatContainer = document.getElementById('chat-container');
        
        // Add user question to chat
        const userMessageElement = document.createElement('div');
        userMessageElement.className = 'chat-message user-message';
        userMessageElement.innerHTML = `
            <div class="message-content">
                <p>${question}</p>
            </div>
        `;
        chatContainer.appendChild(userMessageElement);
        
        // Add AI response placeholder
        const aiMessageElement = document.createElement('div');
        aiMessageElement.className = 'chat-message ai-message';
        aiMessageElement.innerHTML = `
            <div class="message-content">
                <p>Thinking...</p>
            </div>
        `;
        chatContainer.appendChild(aiMessageElement);
        
        // Scroll to bottom of chat
        chatContainer.scrollTop = chatContainer.scrollHeight;
        
        // Clear input
        questionInput.value = '';
        
        // Send question to AI
        fetch('../api/users.php?action=ask_ai', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                material_id: this.currentMaterialId,
                content: this.currentMaterial.content,
                question: question
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success && data.answer) {
                // Update AI response
                aiMessageElement.innerHTML = `
                    <div class="message-content">
                        <p>${data.answer}</p>
                    </div>
                `;
            } else {
                aiMessageElement.innerHTML = `
                    <div class="message-content">
                        <p>I'm sorry, I couldn't answer that question. Please try asking something else.</p>
                    </div>
                `;
                this.showNotification(data.message || 'Failed to get answer', 'error');
            }
            
            // Scroll to bottom of chat
            chatContainer.scrollTop = chatContainer.scrollHeight;
        })
        .catch(error => {
            console.error('Error:', error);
            aiMessageElement.innerHTML = `
                <div class="message-content">
                    <p>I'm sorry, an error occurred. Please try again.</p>
                </div>
            `;
            this.showNotification('An error occurred. Please try again.', 'error');
            
            // Scroll to bottom of chat
            chatContainer.scrollTop = chatContainer.scrollHeight;
        });
    }
    
    /**
     * Display a notification to the user
     * 
     * @param {string} message Message to display
     * @param {string} type Type of notification ('success' or 'error')
     */
    showNotification(message, type) {
        // Create notification element
        const notification = document.createElement('div');
        notification.classList.add('notification', type);
        notification.textContent = message;
        
        // Add notification to the page
        document.body.appendChild(notification);
        
        // Remove notification after 3 seconds
        setTimeout(() => {
            notification.classList.add('fade-out');
            
            setTimeout(() => {
                notification.remove();
            }, 500);
        }, 3000);
    }
}

// Initialize Exam Preparation Manager when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new ExamPreparationManager();
    
    // Add CSS for chat, notifications and quiz
    const style = document.createElement('style');
    style.textContent = `
        .notification {
            position: fixed;
            top: 1rem;
            right: 1rem;
            padding: 1rem;
            border-radius: 0.5rem;
            color: white;
            z-index: 1000;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            transition: opacity 0.5s ease;
        }
        
        .notification.success {
            background-color: #2ecc71;
        }
        
        .notification.error {
            background-color: #e74c3c;
        }
        
        .notification.fade-out {
            opacity: 0;
        }
        
        #chat-container {
            max-height: 300px;
            overflow-y: auto;
            margin-bottom: 1rem;
            padding: 1rem;
            background-color: #f8f9fa;
            border-radius: 0.5rem;
        }
        
        .chat-message {
            margin-bottom: 1rem;
            display: flex;
        }
        
        .user-message {
            justify-content: flex-end;
        }
        
        .ai-message {
            justify-content: flex-start;
        }
        
        .message-content {
            max-width: 80%;
            padding: 0.75rem;
            border-radius: 0.5rem;
        }
        
        .user-message .message-content {
            background-color: #3498db;
            color: white;
            border-bottom-right-radius: 0;
        }
        
        .ai-message .message-content {
            background-color: #e0e0e0;
            border-bottom-left-radius: 0;
        }
        
        .quiz-question {
            margin-bottom: 1.5rem;
            padding: 1rem;
            background-color: #f8f9fa;
            border-radius: 0.5rem;
        }
        
        .quiz-options {
            margin-top: 0.5rem;
        }
        
        .quiz-option {
            margin-bottom: 0.5rem;
        }
        
        .quiz-answer {
            padding: 0.75rem;
            margin-bottom: 0.75rem;
            border-radius: 0.5rem;
        }
        
        .quiz-answer.correct {
            background-color: rgba(46, 204, 113, 0.1);
            border-left: 4px solid #2ecc71;
        }
        
        .quiz-answer.incorrect {
            background-color: rgba(231, 76, 60, 0.1);
            border-left: 4px solid #e74c3c;
        }
        
        .quiz-score {
            margin-bottom: 1.5rem;
            padding: 1rem;
            background-color: #f8f9fa;
            border-radius: 0.5rem;
            text-align: center;
        }
    `;
    document.head.appendChild(style);
});
