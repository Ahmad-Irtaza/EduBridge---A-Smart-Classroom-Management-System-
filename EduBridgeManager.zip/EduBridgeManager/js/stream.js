// /**
//  * EduBridge - Stream Functionality
//  */

// class StreamManager {
//     constructor() {
//         this.initEventListeners();
//     }
    
//     /**
//      * Initialize event listeners for stream functionality
//      */
//     initEventListeners() {
//         // Create post form
//         const createPostForm = document.querySelector('.create-post-form');
//         if (createPostForm) {
//             createPostForm.addEventListener('submit', this.handleCreatePost.bind(this));
//         }
        
//         // Edit post form
//         const editPostForm = document.querySelector('.edit-post-form');
//         if (editPostForm) {
//             editPostForm.addEventListener('submit', this.handleEditPost.bind(this));
//         }
        
//         // Delete post form
//         const deletePostForm = document.querySelector('.delete-post-form');
//         if (deletePostForm) {
//             deletePostForm.addEventListener('submit', this.handleDeletePost.bind(this));
//         }
        
//         // Comment form
//         const commentForm = document.querySelector('.comment-form');
//         if (commentForm) {
//             commentForm.addEventListener('submit', this.handleComment.bind(this));
//         }
        
//         // Assignment submission form
//         const assignmentSubmitForm = document.querySelector('.assignment-submit-form');
//         if (assignmentSubmitForm) {
//             assignmentSubmitForm.addEventListener('submit', this.handleAssignmentSubmit.bind(this));
//         }
//     }
    
//     /**
//      * Handle creation of a new post
//      * 
//      * @param {Event} e Form submit event
//      */
//     handleCreatePost(e) {
//         e.preventDefault();
        
//         const form = e.currentTarget;
//         const formData = new FormData(form);
        
//         // Send AJAX request to create post
//         fetch('../api/stream.php?action=create_post', {
//             method: 'POST',
//             body: formData
//         })
//         .then(response => response.json())
//         .then(data => {
//             if (data.success) {
//                 // Show success notification
//                 this.showNotification('Post created successfully', 'success');
                
//                 // Reset form
//                 form.reset();
                
//                 // Close modal
//                 const modal = document.getElementById('createPostModal');
//                 if (modal) {
//                     modal.style.display = 'none';
//                     document.body.style.overflow = '';
//                 }
                
//                 // Reload page to see the new post
//                 window.location.reload();
//             } else {
//                 // Show error notification
//                 this.showNotification(data.message || 'Failed to create post', 'error');
//             }
//         })
//         .catch(error => {
//             console.error('Error:', error);
//             this.showNotification('An error occurred. Please try again.', 'error');
//         });
//     }
    
//     /**
//      * Handle editing of an existing post
//      * 
//      * @param {Event} e Form submit event
//      */
//     handleEditPost(e) {
//         e.preventDefault();
        
//         const form = e.currentTarget;
//         const formData = new FormData(form);
        
//         // Send AJAX request to edit post
//         fetch('../api/stream.php?action=edit_post', {
//             method: 'POST',
//             body: formData
//         })
//         .then(response => response.json())
//         .then(data => {
//             if (data.success) {
//                 // Show success notification
//                 this.showNotification('Post updated successfully', 'success');
                
//                 // Close modal
//                 const modal = document.getElementById('editPostModal');
//                 if (modal) {
//                     modal.style.display = 'none';
//                     document.body.style.overflow = '';
//                 }
                
//                 // Reload page to see the updated post
//                 window.location.reload();
//             } else {
//                 // Show error notification
//                 this.showNotification(data.message || 'Failed to update post', 'error');
//             }
//         })
//         .catch(error => {
//             console.error('Error:', error);
//             this.showNotification('An error occurred. Please try again.', 'error');
//         });
//     }
    
//     /**
//      * Handle deletion of a post
//      * 
//      * @param {Event} e Form submit event
//      */
//     handleDeletePost(e) {
//         e.preventDefault();
        
//         const form = e.currentTarget;
//         const formData = new FormData(form);
        
//         // Send AJAX request to delete post
//         fetch('../api/stream.php?action=delete_post', {
//             method: 'POST',
//             body: formData
//         })
//         .then(response => response.json())
//         .then(data => {
//             if (data.success) {
//                 // Show success notification
//                 this.showNotification('Post deleted successfully', 'success');
                
//                 // Close modal
//                 const modal = document.getElementById('deletePostModal');
//                 if (modal) {
//                     modal.style.display = 'none';
//                     document.body.style.overflow = '';
//                 }
                
//                 // Reload page
//                 window.location.reload();
//             } else {
//                 // Show error notification
//                 this.showNotification(data.message || 'Failed to delete post', 'error');
//             }
//         })
//         .catch(error => {
//             console.error('Error:', error);
//             this.showNotification('An error occurred. Please try again.', 'error');
//         });
//     }
    
//     /**
//      * Handle adding a comment to a post
//      * 
//      * @param {Event} e Form submit event
//      */
//     handleComment(e) {
//         e.preventDefault();
        
//         const form = e.currentTarget;
//         const formData = new FormData(form);
        
//         // Send AJAX request to add comment
//         fetch('../api/stream.php?action=add_comment', {
//             method: 'POST',
//             body: formData
//         })
//         .then(response => response.json())
//         .then(data => {
//             if (data.success) {
//                 // Show success notification
//                 this.showNotification('Comment added successfully', 'success');
                
//                 // Reset form
//                 form.reset();
                
//                 // Close modal
//                 const modal = document.getElementById('commentModal');
//                 if (modal) {
//                     modal.style.display = 'none';
//                     document.body.style.overflow = '';
//                 }
                
//                 // Reload page to see the new comment
//                 window.location.reload();
//             } else {
//                 // Show error notification
//                 this.showNotification(data.message || 'Failed to add comment', 'error');
//             }
//         })
//         .catch(error => {
//             console.error('Error:', error);
//             this.showNotification('An error occurred. Please try again.', 'error');
//         });
//     }
    
//     /**
//      * Handle submitting an assignment
//      * 
//      * @param {Event} e Form submit event
//      */
//     handleAssignmentSubmit(e) {
//         e.preventDefault();
        
//         const form = e.currentTarget;
//         const formData = new FormData(form);
        
//         // Send AJAX request to submit assignment
//         fetch('../api/stream.php?action=submit_assignment', {
//             method: 'POST',
//             body: formData
//         })
//         .then(response => response.json())
//         .then(data => {
//             if (data.success) {
//                 // Show success notification
//                 this.showNotification('Assignment submitted successfully', 'success');
                
//                 // Reset form
//                 form.reset();
                
//                 // Close modal
//                 const modal = document.getElementById('assignmentSubmitModal');
//                 if (modal) {
//                     modal.style.display = 'none';
//                     document.body.style.overflow = '';
//                 }
                
//                 // Reload page
//                 window.location.reload();
//             } else {
//                 // Show error notification
//                 this.showNotification(data.message || 'Failed to submit assignment', 'error');
//             }
//         })
//         .catch(error => {
//             console.error('Error:', error);
//             this.showNotification('An error occurred. Please try again.', 'error');
//         });
//     }
    
//     /**
//      * Display a notification to the user
//      * 
//      * @param {string} message Message to display
//      * @param {string} type Type of notification ('success' or 'error')
//      */
//     showNotification(message, type) {
//         // Create notification element
//         const notification = document.createElement('div');
//         notification.classList.add('notification', type);
//         notification.textContent = message;
        
//         // Add notification to the page
//         document.body.appendChild(notification);
        
//         // Remove notification after 3 seconds
//         setTimeout(() => {
//             notification.classList.add('fade-out');
            
//             setTimeout(() => {
//                 notification.remove();
//             }, 500);
//         }, 3000);
//     }
// }

// // Initialize Stream Manager when DOM is loaded
// document.addEventListener('DOMContentLoaded', () => {
//     new StreamManager();
    
//     // Load comments for posts
//     const streamPosts = document.querySelectorAll('.stream-post');
//     streamPosts.forEach(post => {
//         const postId = post.querySelector('[data-post-id]')?.getAttribute('data-post-id');
//         if (postId) {
//             loadComments(postId, post);
//         }
//     });
// });

// /**
//  * Load comments for a post and append them to the post element
//  * 
//  * @param {string} postId Post ID to load comments for
//  * @param {HTMLElement} postElement Post element to append comments to
//  */
// function loadComments(postId, postElement) {
//     fetch(`../api/stream.php?action=get_comments&post_id=${postId}`)
//         .then(response => response.json())
//         .then(data => {
//             if (data.success && data.comments && data.comments.length > 0) {
//                 // Create comments container if it doesn't exist
//                 let commentsContainer = postElement.querySelector('.stream-post-comments');
//                 if (!commentsContainer) {
//                     commentsContainer = document.createElement('div');
//                     commentsContainer.className = 'stream-post-comments';
//                     postElement.appendChild(commentsContainer);
//                 }
                
//                 // Clear existing comments
//                 commentsContainer.innerHTML = '';
                
//                 // Add comments header
//                 const commentsHeader = document.createElement('h5');
//                 commentsHeader.textContent = 'Comments';
//                 commentsContainer.appendChild(commentsHeader);
                
//                 // Add comments
//                 data.comments.forEach(comment => {
//                     const commentElement = document.createElement('div');
//                     commentElement.className = 'stream-comment';
                    
//                     commentElement.innerHTML = `
//                         <div class="comment-header">
//                             <span class="comment-author">${comment.user_name}</span>
//                             <span class="comment-date">${comment.created_at}</span>
//                         </div>
//                         <div class="comment-content">${comment.comment}</div>
//                     `;
                    
//                     commentsContainer.appendChild(commentElement);
//                 });
//             }
//         })
//         .catch(error => {
//             console.error('Error loading comments:', error);
//         });
// }

// /**
//  * Handle joining a class with a class code (for students)
//  */
// class ClassEnrollment {
//     constructor() {
//         this.init();
//     }
    
//     init() {
//         const enrollForm = document.querySelector('.enroll-class-form');
//         if (enrollForm) {
//             enrollForm.addEventListener('submit', this.handleEnroll.bind(this));
//         }
//     }
    
//     handleEnroll(e) {
//         e.preventDefault();
        
//         const form = e.currentTarget;
//         const formData = new FormData(form);
        
//         fetch('../api/stream.php?action=enroll_class', {
//             method: 'POST',
//             body: formData
//         })
//         .then(response => response.json())
//         .then(data => {
//             if (data.success) {
//                 // Show success notification
//                 this.showNotification('Successfully enrolled in class', 'success');
                
//                 // Reset form
//                 form.reset();
                
//                 // Close modal
//                 const modal = document.getElementById('enrollClassModal');
//                 if (modal) {
//                     modal.style.display = 'none';
//                     document.body.style.overflow = '';
//                 }
                
//                 // Reload page after a delay
//                 setTimeout(() => {
//                     window.location.reload();
//                 }, 1500);
//             } else {
//                 // Show error notification
//                 this.showNotification(data.message || 'Failed to enroll in class', 'error');
//             }
//         })
//         .catch(error => {
//             console.error('Error:', error);
//             this.showNotification('An error occurred. Please try again.', 'error');
//         });
//     }
    
//     showNotification(message, type) {
//         // Create notification element
//         const notification = document.createElement('div');
//         notification.classList.add('notification', type);
//         notification.textContent = message;
        
//         // Add notification to the page
//         document.body.appendChild(notification);
        
//         // Remove notification after 3 seconds
//         setTimeout(() => {
//             notification.classList.add('fade-out');
            
//             setTimeout(() => {
//                 notification.remove();
//             }, 500);
//         }, 3000);
//     }
// }

// // Initialize Class Enrollment when DOM is loaded
// document.addEventListener('DOMContentLoaded', () => {
//     new ClassEnrollment();
    
//     // Add CSS for notifications and comments
//     const style = document.createElement('style');
//     style.textContent = `
//         .notification {
//             position: fixed;
//             top: 1rem;
//             right: 1rem;
//             padding: 1rem;
//             border-radius: 0.5rem;
//             color: white;
//             z-index: 1000;
//             box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
//             transition: opacity 0.5s ease;
//         }
        
//         .notification.success {
//             background-color: #2ecc71;
//         }
        
//         .notification.error {
//             background-color: #e74c3c;
//         }
        
//         .notification.fade-out {
//             opacity: 0;
//         }
        
//         .stream-post-comments {
//             padding: 1rem;
//             border-top: 1px solid #e0e0e0;
//             margin-top: 1rem;
//         }
        
//         .stream-comment {
//             padding: 0.75rem;
//             margin-bottom: 0.75rem;
//             background-color: #f8f9fa;
//             border-radius: 0.5rem;
//         }
        
//         .comment-header {
//             display: flex;
//             justify-content: space-between;
//             margin-bottom: 0.5rem;
//         }
        
//         .comment-author {
//             font-weight: bold;
//         }
        
//         .comment-date {
//             font-size: 0.8rem;
//             color: #6c757d;
//         }
        
//         .comment-content {
//             margin-top: 0.5rem;
//             white-space: pre-line;
//         }
//     `;
//     document.head.appendChild(style);
// });




// Stream.js - Safe IIFE wrapped version

(function () {
    if (!window.StreamManager) {
        class StreamManager {
            constructor() {
                this.initEventListeners();
            }
            // ... All methods remain unchanged
        }

        window.StreamManager = StreamManager;
        document.addEventListener('DOMContentLoaded', () => {
            new StreamManager();
        });
    }

    if (!window.ClassEnrollment) {
        class ClassEnrollment {
            constructor() {
                this.init();
            }
            // ... All methods remain unchanged
        }

        window.ClassEnrollment = ClassEnrollment;
        document.addEventListener('DOMContentLoaded', () => {
            new ClassEnrollment();

            // Inject CSS if needed
            const style = document.createElement('style');
            style.textContent = `
                .notification { position: fixed; top: 1rem; right: 1rem; padding: 1rem;
                border-radius: 0.5rem; color: white; z-index: 1000; box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1); transition: opacity 0.5s ease; }
                .notification.success { background-color: #2ecc71; }
                .notification.error { background-color: #e74c3c; }
                .notification.fade-out { opacity: 0; }
                .stream-post-comments { padding: 1rem; border-top: 1px solid #e0e0e0; margin-top: 1rem; }
                .stream-comment { padding: 0.75rem; margin-bottom: 0.75rem; background-color: #f8f9fa; border-radius: 0.5rem; }
                .comment-header { display: flex; justify-content: space-between; margin-bottom: 0.5rem; }
                .comment-author { font-weight: bold; }
                .comment-date { font-size: 0.8rem; color: #6c757d; }
                .comment-content { margin-top: 0.5rem; white-space: pre-line; }
            `;
            document.head.appendChild(style);
        });
    }
})();
