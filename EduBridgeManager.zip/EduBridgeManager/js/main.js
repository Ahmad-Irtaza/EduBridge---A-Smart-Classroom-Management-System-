/**
 * EduBridge - Smart Classroom Management System
 * Main JavaScript File
 */

// Wait for DOM to be fully loaded
document.addEventListener('DOMContentLoaded', function() {
    // Initialize dropdown functionality
    initDropdowns();
    
    // Initialize modal functionality
    initModals();
    
    // Initialize notifications
    initNotifications();
    
    // Initialize form validation
    initFormValidation();
});

/**
 * Initialize dropdown functionality
 */
function initDropdowns() {
    // This is handled by CSS, but we can add additional functionality here if needed
    const dropdowns = document.querySelectorAll('.dropdown');
    
    dropdowns.forEach(dropdown => {
        const btn = dropdown.querySelector('.dropdown-btn');
        const content = dropdown.querySelector('.dropdown-content');
        
        if (btn && content) {
            // Make dropdowns accessible via keyboard
            btn.addEventListener('keydown', function(e) {
                if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    content.style.display = content.style.display === 'block' ? 'none' : 'block';
                }
            });
            
            // Close dropdown when clicking outside
            document.addEventListener('click', function(e) {
                if (!dropdown.contains(e.target)) {
                    content.style.display = 'none';
                }
            });
        }
    });
}

/**
 * Initialize modal functionality
 */
function initModals() {
    // Get all modal triggers
    const modalTriggers = document.querySelectorAll('[data-modal]');
    
    modalTriggers.forEach(trigger => {
        const modalId = trigger.getAttribute('data-modal');
        const modal = document.getElementById(modalId);
        
        if (modal) {
            const closeBtn = modal.querySelector('.close-modal');
            
            // Open modal when clicking trigger
            trigger.addEventListener('click', function() {
                modal.style.display = 'block';
                // Set focus to the first input in the modal for accessibility
                const firstInput = modal.querySelector('input, button, select, textarea');
                if (firstInput) {
                    firstInput.focus();
                }
                // Prevent background scrolling
                document.body.style.overflow = 'hidden';
            });
            
            // Close modal when clicking close button
            if (closeBtn) {
                closeBtn.addEventListener('click', function() {
                    modal.style.display = 'none';
                    document.body.style.overflow = '';
                });
            }
            
            // Close modal when clicking outside the modal content
            modal.addEventListener('click', function(e) {
                if (e.target === modal) {
                    modal.style.display = 'none';
                    document.body.style.overflow = '';
                }
            });
            
            // Close modal when pressing Escape key
            document.addEventListener('keydown', function(e) {
                if (e.key === 'Escape' && modal.style.display === 'block') {
                    modal.style.display = 'none';
                    document.body.style.overflow = '';
                }
            });
        }
    });
}

/**
 * Initialize notifications
 */
function initNotifications() {
    // Auto-hide notifications after 5 seconds
    const notifications = document.querySelectorAll('.error-message, .success-message');
    
    notifications.forEach(notification => {
        setTimeout(() => {
            notification.classList.add('fade-out');
            
            // Remove notification after fade out animation
            setTimeout(() => {
                notification.style.display = 'none';
            }, 500);
        }, 5000);
    });
}

/**
 * Initialize form validation
 */
function initFormValidation() {
    const forms = document.querySelectorAll('form');
    
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            const requiredFields = form.querySelectorAll('[required]');
            let isValid = true;
            
            requiredFields.forEach(field => {
                if (!field.value.trim()) {
                    isValid = false;
                    field.classList.add('error');
                    
                    // Add error message if it doesn't exist
                    let errorMessage = field.nextElementSibling;
                    if (!errorMessage || !errorMessage.classList.contains('field-error')) {
                        errorMessage = document.createElement('div');
                        errorMessage.classList.add('field-error');
                        errorMessage.textContent = 'This field is required';
                        field.parentNode.insertBefore(errorMessage, field.nextSibling);
                    }
                } else {
                    field.classList.remove('error');
                    
                    // Remove error message if it exists
                    const errorMessage = field.nextElementSibling;
                    if (errorMessage && errorMessage.classList.contains('field-error')) {
                        errorMessage.remove();
                    }
                }
            });
            
            if (!isValid) {
                e.preventDefault();
                
                // Scroll to the first error field
                const firstErrorField = form.querySelector('.error');
                if (firstErrorField) {
                    firstErrorField.focus();
                    firstErrorField.scrollIntoView({
                        behavior: 'smooth',
                        block: 'center'
                    });
                }
            }
        });
    });
}

/**
 * Class for managing the attendance functionality
 */
class AttendanceManager {
    constructor() {
        this.initEventListeners();
    }
    
    initEventListeners() {
        // Add event listeners for attendance buttons
        const attendanceButtons = document.querySelectorAll('.attendance-btn');
        
        attendanceButtons.forEach(button => {
            button.addEventListener('click', this.handleAttendanceClick.bind(this));
        });
    }
    
    handleAttendanceClick(e) {
        const button = e.currentTarget;
        const studentId = button.getAttribute('data-student-id');
        const classId = button.getAttribute('data-class-id');
        const status = button.getAttribute('data-status');
        const date = button.getAttribute('data-date');
        
        // Send AJAX request to update attendance
        this.updateAttendance(studentId, classId, status, date);
    }
    
    updateAttendance(studentId, classId, status, date) {
        // Create form data
        const formData = new FormData();
        formData.append('student_id', studentId);
        formData.append('class_id', classId);
        formData.append('status', status);
        formData.append('date', date);
        
        // Send AJAX request
        fetch('../api/attendance.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Update UI
                this.updateAttendanceUI(studentId, status, date);
                
                // Show success message
                this.showNotification('Attendance updated successfully', 'success');
            } else {
                // Show error message
                this.showNotification(data.message || 'Failed to update attendance', 'error');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            this.showNotification('An error occurred. Please try again.', 'error');
        });
    }
    
    updateAttendanceUI(studentId, status, date) {
        // Get all buttons for this student and date
        const buttons = document.querySelectorAll(`.attendance-btn[data-student-id="${studentId}"][data-date="${date}"]`);
        
        // Remove active class from all buttons
        buttons.forEach(button => {
            button.classList.remove('active');
        });
        
        // Add active class to the clicked button
        const activeButton = document.querySelector(`.attendance-btn[data-student-id="${studentId}"][data-date="${date}"][data-status="${status}"]`);
        if (activeButton) {
            activeButton.classList.add('active');
        }
        
        // Update status text if it exists
        const statusText = document.querySelector(`.attendance-status[data-student-id="${studentId}"][data-date="${date}"]`);
        if (statusText) {
            statusText.textContent = status.charAt(0).toUpperCase() + status.slice(1);
            statusText.className = 'attendance-status ' + status;
        }
    }
    
    showNotification(message, type) {
        // Create notification element
        const notification = document.createElement('div');
        notification.classList.add('notification', type);
        notification.textContent = message;
        
        // Add notification to the page
        document.body.appendChild(notification);
        
        // Remove notification after 3 seconds
        setTimeout(() => {
            notification.classList.add('fade-out');
            
            setTimeout(() => {
                notification.remove();
            }, 500);
        }, 3000);
    }
}

/**
 * Class for managing the marks functionality
 */
class MarksManager {
    constructor() {
        this.initEventListeners();
    }
    
    initEventListeners() {
        // Add event listeners for marks form
        const marksForm = document.querySelector('.marks-form');
        
        if (marksForm) {
            marksForm.addEventListener('submit', this.handleMarksSubmit.bind(this));
        }
    }
    
    handleMarksSubmit(e) {
        e.preventDefault();
        
        const form = e.currentTarget;
        const formData = new FormData(form);
        
        // Send AJAX request to update marks
        fetch('../api/marks.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Show success message
                this.showNotification('Marks updated successfully', 'success');
                
                // Reset form
                form.reset();
                
                // Reload marks table if it exists
                const marksTable = document.querySelector('.marks-table');
                if (marksTable && data.marksHtml) {
                    marksTable.innerHTML = data.marksHtml;
                }
            } else {
                // Show error message
                this.showNotification(data.message || 'Failed to update marks', 'error');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            this.showNotification('An error occurred. Please try again.', 'error');
        });
    }
    
    showNotification(message, type) {
        // Create notification element
        const notification = document.createElement('div');
        notification.classList.add('notification', type);
        notification.textContent = message;
        
        // Add notification to the page
        document.body.appendChild(notification);
        
        // Remove notification after 3 seconds
        setTimeout(() => {
            notification.classList.add('fade-out');
            
            setTimeout(() => {
                notification.remove();
            }, 500);
        }, 3000);
    }
}

/**
 * Class for managing the stream functionality
 */
class StreamManager {
    constructor() {
        this.initEventListeners();
    }
    
    initEventListeners() {
        // Add event listeners for create post form
        const createPostForm = document.querySelector('.create-post-form');
        
        if (createPostForm) {
            createPostForm.addEventListener('submit', this.handleCreatePost.bind(this));
        }
        
        // Add event listeners for post type select
        const postTypeSelect = document.querySelector('#post_type');
        
        if (postTypeSelect) {
            postTypeSelect.addEventListener('change', this.handlePostTypeChange.bind(this));
        }
    }
    
    handlePostTypeChange(e) {
        const postType = e.target.value;
        const dueDateContainer = document.querySelector('.due-date-container');
        
        // Show due date field only for assignments
        if (postType === 'assignment') {
            dueDateContainer.style.display = 'block';
        } else {
            dueDateContainer.style.display = 'none';
        }
    }
    
    handleCreatePost(e) {
        e.preventDefault();
        
        const form = e.currentTarget;
        const formData = new FormData(form);
        
        // Send AJAX request to create post
        fetch('../api/stream.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Show success message
                this.showNotification('Post created successfully', 'success');
                
                // Reset form
                form.reset();
                
                // Close modal if it exists
                const modal = document.querySelector('.modal');
                if (modal) {
                    modal.style.display = 'none';
                    document.body.style.overflow = '';
                }
                
                // Reload stream if it exists
                const stream = document.querySelector('.stream-posts');
                if (stream && data.postHtml) {
                    // Prepend new post to stream
                    stream.innerHTML = data.postHtml + stream.innerHTML;
                }
            } else {
                // Show error message
                this.showNotification(data.message || 'Failed to create post', 'error');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            this.showNotification('An error occurred. Please try again.', 'error');
        });
    }
    
    showNotification(message, type) {
        // Create notification element
        const notification = document.createElement('div');
        notification.classList.add('notification', type);
        notification.textContent = message;
        
        // Add notification to the page
        document.body.appendChild(notification);
        
        // Remove notification after 3 seconds
        setTimeout(() => {
            notification.classList.add('fade-out');
            
            setTimeout(() => {
                notification.remove();
            }, 500);
        }, 3000);
    }
}

/**
 * Class for managing the class enrollment functionality
 */
class ClassEnrollment {
    constructor() {
        this.initEventListeners();
    }
    
    initEventListeners() {
        // Add event listeners for enroll class form
        const enrollClassForm = document.querySelector('.enroll-class-form');
        
        if (enrollClassForm) {
            enrollClassForm.addEventListener('submit', this.handleEnrollClass.bind(this));
        }
    }
    
    handleEnrollClass(e) {
        e.preventDefault();
        
        const form = e.currentTarget;
        const formData = new FormData(form);
        
        // Send AJAX request to enroll in class
        fetch('../api/stream.php?action=enroll', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Show success message
                this.showNotification('Enrolled in class successfully', 'success');
                
                // Reset form
                form.reset();
                
                // Close modal if it exists
                const modal = document.querySelector('.modal');
                if (modal) {
                    modal.style.display = 'none';
                    document.body.style.overflow = '';
                }
                
                // Refresh page to show new class
                window.location.reload();
            } else {
                // Show error message
                this.showNotification(data.message || 'Failed to enroll in class', 'error');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            this.showNotification('An error occurred. Please try again.', 'error');
        });
    }
    
    showNotification(message, type) {
        // Create notification element
        const notification = document.createElement('div');
        notification.classList.add('notification', type);
        notification.textContent = message;
        
        // Add notification to the page
        document.body.appendChild(notification);
        
        // Remove notification after 3 seconds
        setTimeout(() => {
            notification.classList.add('fade-out');
            
            setTimeout(() => {
                notification.remove();
            }, 500);
        }, 3000);
    }
}

// Initialize classes when needed on specific pages
if (document.querySelector('.attendance-btn')) {
    new AttendanceManager();
}

if (document.querySelector('.marks-form')) {
    new MarksManager();
}

if (document.querySelector('.create-post-form') || document.querySelector('.stream-posts')) {
    new StreamManager();
}

if (document.querySelector('.enroll-class-form')) {
    new ClassEnrollment();
}
