/**
 * EduBridge - Charts Helper Library
 * 
 * A lightweight wrapper around Chart.js with some predefined configurations
 */

/**
 * Create a bar chart with default configurations
 * 
 * @param {string} elementId ID of the canvas element
 * @param {object} chartData Chart data object
 * @param {object} options Additional chart options
 * @returns {Chart} Chart.js instance
 */
function createBarChart(elementId, chartData, options = {}) {
    const ctx = document.getElementById(elementId).getContext('2d');
    
    const defaultOptions = {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
            y: {
                beginAtZero: true
            }
        },
        plugins: {
            legend: {
                position: 'top'
            }
        }
    };
    
    const mergedOptions = { ...defaultOptions, ...options };
    
    return new Chart(ctx, {
        type: 'bar',
        data: chartData,
        options: mergedOptions
    });
}

/**
 * Create a line chart with default configurations
 * 
 * @param {string} elementId ID of the canvas element
 * @param {object} chartData Chart data object
 * @param {object} options Additional chart options
 * @returns {Chart} Chart.js instance
 */
function createLineChart(elementId, chartData, options = {}) {
    const ctx = document.getElementById(elementId).getContext('2d');
    
    const defaultOptions = {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
            y: {
                beginAtZero: true
            }
        },
        plugins: {
            legend: {
                position: 'top'
            }
        },
        elements: {
            line: {
                tension: 0.4
            }
        }
    };
    
    const mergedOptions = { ...defaultOptions, ...options };
    
    return new Chart(ctx, {
        type: 'line',
        data: chartData,
        options: mergedOptions
    });
}

/**
 * Create a pie chart with default configurations
 * 
 * @param {string} elementId ID of the canvas element
 * @param {object} chartData Chart data object
 * @param {object} options Additional chart options
 * @returns {Chart} Chart.js instance
 */
function createPieChart(elementId, chartData, options = {}) {
    const ctx = document.getElementById(elementId).getContext('2d');
    
    const defaultOptions = {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                position: 'bottom'
            }
        }
    };
    
    const mergedOptions = { ...defaultOptions, ...options };
    
    return new Chart(ctx, {
        type: 'pie',
        data: chartData,
        options: mergedOptions
    });
}

/**
 * Create a doughnut chart with default configurations
 * 
 * @param {string} elementId ID of the canvas element
 * @param {object} chartData Chart data object
 * @param {object} options Additional chart options
 * @returns {Chart} Chart.js instance
 */
function createDoughnutChart(elementId, chartData, options = {}) {
    const ctx = document.getElementById(elementId).getContext('2d');
    
    const defaultOptions = {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                position: 'bottom'
            }
        },
        cutout: '70%'
    };
    
    const mergedOptions = { ...defaultOptions, ...options };
    
    return new Chart(ctx, {
        type: 'doughnut',
        data: chartData,
        options: mergedOptions
    });
}

/**
 * Generate predefined color palettes for charts
 * 
 * @param {string} paletteType Type of palette: 'sequential', 'qualitative', or 'diverging'
 * @param {number} count Number of colors needed
 * @returns {array} Array of color strings
 */
function generateColorPalette(paletteType = 'qualitative', count = 5) {
    const palettes = {
        sequential: [
            'rgba(52, 152, 219, 1)',
            'rgba(41, 128, 185, 1)',
            'rgba(31, 97, 141, 1)',
            'rgba(21, 67, 96, 1)',
            'rgba(11, 36, 52, 1)'
        ],
        qualitative: [
            'rgba(52, 152, 219, 1)',
            'rgba(46, 204, 113, 1)',
            'rgba(155, 89, 182, 1)',
            'rgba(241, 196, 15, 1)',
            'rgba(230, 126, 34, 1)',
            'rgba(231, 76, 60, 1)',
            'rgba(149, 165, 166, 1)',
            'rgba(52, 73, 94, 1)'
        ],
        diverging: [
            'rgba(231, 76, 60, 1)',
            'rgba(241, 148, 138, 1)',
            'rgba(149, 165, 166, 1)',
            'rgba(133, 193, 233, 1)',
            'rgba(52, 152, 219, 1)'
        ],
        performance: [
            'rgba(231, 76, 60, 0.7)',  // Red (F)
            'rgba(230, 126, 34, 0.7)',  // Orange (D)
            'rgba(241, 196, 15, 0.7)',  // Yellow (C)
            'rgba(46, 204, 113, 0.7)',  // Green (B)
            'rgba(52, 152, 219, 0.7)'   // Blue (A)
        ],
        attendance: [
            'rgba(231, 76, 60, 0.7)',  // Red (Absent)
            'rgba(241, 196, 15, 0.7)',  // Yellow (Late)
            'rgba(46, 204, 113, 0.7)'   // Green (Present)
        ]
    };
    
    // If requested count is more than available, repeat colors
    const palette = palettes[paletteType] || palettes.qualitative;
    const result = [];
    
    for (let i = 0; i < count; i++) {
        result.push(palette[i % palette.length]);
    }
    
    return result;
}

/**
 * Generate transparent versions of colors for backgrounds
 * 
 * @param {array} colors Array of color strings
 * @param {number} opacity Opacity value (0-1)
 * @returns {array} Array of color strings with modified opacity
 */
function generateTransparentColors(colors, opacity = 0.2) {
    return colors.map(color => {
        return color.replace(/rgba?\(([^)]+)\)/, (match, p1) => {
            const parts = p1.split(',');
            if (parts.length >= 3) {
                return `rgba(${parts[0].trim()}, ${parts[1].trim()}, ${parts[2].trim()}, ${opacity})`;
            }
            return match;
        });
    });
}

/**
 * Format percentage values for chart tooltips
 * 
 * @param {number} value Value to format
 * @returns {string} Formatted percentage string
 */
function formatPercentage(value) {
    return value.toFixed(2) + '%';
}

/**
 * Create a gaugeChart using doughnut chart to show a single value
 * 
 * @param {string} elementId ID of the canvas element
 * @param {number} value The value to display (0-100)
 * @param {string} label Label for the value
 * @param {object} options Additional chart options
 * @returns {Chart} Chart.js instance
 */
function createGaugeChart(elementId, value, label, options = {}) {
    const ctx = document.getElementById(elementId).getContext('2d');
    
    // Determine color based on value
    let color;
    if (value < 60) {
        color = 'rgba(231, 76, 60, 1)'; // Red
    } else if (value < 80) {
        color = 'rgba(241, 196, 15, 1)'; // Yellow
    } else {
        color = 'rgba(46, 204, 113, 1)'; // Green
    }
    
    const chartData = {
        datasets: [{
            data: [value, 100 - value],
            backgroundColor: [color, 'rgba(234, 236, 238, 1)'],
            borderWidth: 0,
            circumference: 180,
            rotation: 270
        }]
    };
    
    const defaultOptions = {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                display: false
            },
            tooltip: {
                enabled: false
            }
        },
        cutout: '75%'
    };
    
    const mergedOptions = { ...defaultOptions, ...options };
    
    const chart = new Chart(ctx, {
        type: 'doughnut',
        data: chartData,
        options: mergedOptions,
        plugins: [{
            id: 'gaugeText',
            afterDraw: (chart) => {
                const {ctx, chartArea: {top, bottom, left, right, width, height}} = chart;
                
                ctx.save();
                
                // Draw value text
                const fontSize = Math.min(width, height) / 8;
                ctx.font = `bold ${fontSize}px ${mergedOptions.font?.family || 'Arial'}`;
                ctx.textBaseline = 'middle';
                ctx.textAlign = 'center';
                ctx.fillStyle = color;
                
                const textY = top + height * 0.8;
                ctx.fillText(`${value}%`, left + width / 2, textY);
                
                // Draw label text
                const labelFontSize = fontSize * 0.5;
                ctx.font = `${labelFontSize}px ${mergedOptions.font?.family || 'Arial'}`;
                ctx.fillStyle = '#666666';
                ctx.fillText(label, left + width / 2, textY + fontSize);
                
                ctx.restore();
            }
        }]
    });
    
    return chart;
}
