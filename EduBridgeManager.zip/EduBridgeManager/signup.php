<?php
session_start();
require_once('includes/db_config.php');
require_once('includes/functions.php');
require_once('includes/auth.php');

// Check if already logged in
if (isLoggedIn()) {
    $userType = $_SESSION['user_type'];
    redirect($userType . '/dashboard.php');
}

// Get user type from URL parameter
$userType = isset($_GET['type']) ? sanitize($_GET['type']) : 'student';
$userType = ($userType === 'teacher') ? 'teacher' : 'student';

$error = '';
$success = '';

// Process signup form
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collect personal info
    $firstName = sanitize($_POST['first_name']);
    $lastName = sanitize($_POST['last_name']);
    $gender = sanitize($_POST['gender']);
    $dob = sanitize($_POST['dob']);
    $cnic = sanitize($_POST['cnic']);
    $nationality = sanitize($_POST['nationality']);
    
    // Collect account credentials
    $email = sanitize($_POST['email']);
    $username = sanitize($_POST['username']);
    $password = $_POST['password'];
    $confirmPassword = $_POST['confirm_password'];
    
    // Collect academic info
    $qualification = sanitize($_POST['qualification']);
    $department = sanitize($_POST['department']);
    if ($department === 'Other') {
        $department = sanitize($_POST['department_other']);
    }
    
    // Collect contact info
    $address = sanitize($_POST['address']);
    $phone = sanitize($_POST['phone']);
    $postalCode = sanitize($_POST['postal_code']);
    $city = sanitize($_POST['city']);
    $country = sanitize($_POST['country']);
    
    // Collect family info
    $fatherName = sanitize($_POST['father_name']);
    $fatherCnic = sanitize($_POST['father_cnic']);
    
    // Collect blood group
    $bloodGroup = sanitize($_POST['blood_group']);
    
    // Validate form data
    if (empty($firstName) || empty($lastName) || empty($email) || empty($username) || empty($password)) {
        $error = "All required fields must be filled";
    } else if ($password !== $confirmPassword) {
        $error = "Passwords do not match";
    } else if (strlen($password) < 8) {
        $error = "Password must be at least 8 characters long";
    } else if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email format";
    } else {
        try {
            $pdo = getDbConnection();
            
            // Check if username or email already exists
            $stmt = $pdo->prepare("SELECT id FROM {$userType}s WHERE username = :username OR email = :email");
            $stmt->execute([
                'username' => $username,
                'email' => $email
            ]);
            
            if ($stmt->rowCount() > 0) {
                $error = "Username or email already exists";
            } else {
                // Hash the password
                $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
                
                // Insert new user
                $stmt = $pdo->prepare(
                    "INSERT INTO {$userType}s (
                        first_name, last_name, gender, dob, cnic, nationality, 
                        email, username, password, qualification, department, 
                        address, phone, postal_code, city, country, 
                        father_name, father_cnic, blood_group
                    ) VALUES (
                        :first_name, :last_name, :gender, :dob, :cnic, :nationality, 
                        :email, :username, :password, :qualification, :department, 
                        :address, :phone, :postal_code, :city, :country, 
                        :father_name, :father_cnic, :blood_group
                    )"
                );
                
                $stmt->execute([
                    'first_name' => $firstName,
                    'last_name' => $lastName,
                    'gender' => $gender,
                    'dob' => $dob,
                    'cnic' => $cnic,
                    'nationality' => $nationality,
                    'email' => $email,
                    'username' => $username,
                    'password' => $hashedPassword,
                    'qualification' => $qualification,
                    'department' => $department,
                    'address' => $address,
                    'phone' => $phone,
                    'postal_code' => $postalCode,
                    'city' => $city,
                    'country' => $country,
                    'father_name' => $fatherName,
                    'father_cnic' => $fatherCnic,
                    'blood_group' => $bloodGroup
                ]);
                
                $success = "Account created successfully! Please log in.";
            }
        } catch (PDOException $e) {
            $error = "Database error: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo ucfirst($userType); ?> Sign Up - EduBridge</title>
    <link rel="stylesheet" href="css/style.css">
    <meta name="description" content="Create a new EduBridge <?php echo $userType; ?> account">
</head>
<body>
    <div class="auth-container signup-container">
        <header>
            <div class="logo-container">
                <h1>EduBridge</h1>
            </div>
            <p class="tagline">A Smart Classroom Management System</p>
        </header>
        
        <main class="auth-form-container signup-form-container">
            <h2><?php echo ucfirst($userType); ?> Sign Up</h2>
            
            <?php if (!empty($error)): ?>
                <div class="error-message">
                    <?php echo $error; ?>
                </div>
            <?php endif; ?>
            
            <?php if (!empty($success)): ?>
                <div class="success-message">
                    <?php echo $success; ?>
                    <p><a href="login.php?type=<?php echo $userType; ?>">Click here to login</a></p>
                </div>
            <?php else: ?>
                <form method="post" action="signup.php?type=<?php echo $userType; ?>" class="signup-form">
                    <fieldset>
                        <legend>👤 Personal Information</legend>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label for="first_name">First Name <span class="required">*</span></label>
                                <input type="text" id="first_name" name="first_name" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="last_name">Last Name <span class="required">*</span></label>
                                <input type="text" id="last_name" name="last_name" required>
                            </div>
                        </div>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label for="gender">Gender <span class="required">*</span></label>
                                <select id="gender" name="gender" required>
                                    <option value="">Select Gender</option>
                                    <option value="Male">Male</option>
                                    <option value="Female">Female</option>
                                </select>
                            </div>
                            
                            <div class="form-group">
                                <label for="dob">Date of Birth <span class="required">*</span></label>
                                <input type="date" id="dob" name="dob" required>
                            </div>
                        </div>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label for="cnic">CNIC Number <span class="required">*</span></label>
                                <input type="text" id="cnic" name="cnic" required pattern="[0-9]{5}-[0-9]{7}-[0-9]{1}" placeholder="12345-1234567-1">
                            </div>
                            
                            <div class="form-group">
                                <label for="nationality">Nationality</label>
                                <input type="text" id="nationality" name="nationality" value="Pakistani">
                            </div>
                        </div>
                    </fieldset>
                    
                    <fieldset>
                        <legend>🔑 Account Credentials</legend>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label for="email">Email <span class="required">*</span></label>
                                <input type="email" id="email" name="email" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="username">Username <span class="required">*</span></label>
                                <input type="text" id="username" name="username" required>
                            </div>
                        </div>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label for="password">Password <span class="required">*</span></label>
                                <input type="password" id="password" name="password" required minlength="8">
                            </div>
                            
                            <div class="form-group">
                                <label for="confirm_password">Confirm Password <span class="required">*</span></label>
                                <input type="password" id="confirm_password" name="confirm_password" required minlength="8">
                            </div>
                        </div>
                    </fieldset>
                    
                    <fieldset>
                        <legend>🎓 Academic Information</legend>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label for="qualification">Qualification <span class="required">*</span></label>
                                <input type="text" id="qualification" name="qualification" required placeholder="e.g., BS">
                            </div>
                            
                            <div class="form-group">
                                <label for="department">Department <span class="required">*</span></label>
                                <select id="department" name="department" required>
                                    <option value="">Select Department</option>
                                    <option value="Computer Science">Computer Science</option>
                                    <option value="Electrical Engineering">Electrical Engineering</option>
                                    <option value="Business Administration">Business Administration</option>
                                    <option value="Mathematics">Mathematics</option>
                                    <option value="Physics">Physics</option>
                                    <option value="Chemistry">Chemistry</option>
                                    <option value="Biology">Biology</option>
                                    <option value="Other">Other</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="form-row department-other-container" style="display: none;">
                            <div class="form-group">
                                <label for="department_other">Specify Department <span class="required">*</span></label>
                                <input type="text" id="department_other" name="department_other">
                            </div>
                        </div>
                    </fieldset>
                    
                    <fieldset>
                        <legend>📞 Contact Information</legend>
                        
                        <div class="form-group">
                            <label for="address">Home Address <span class="required">*</span></label>
                            <input type="text" id="address" name="address" required>
                        </div>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label for="phone">Home Phone</label>
                                <input type="tel" id="phone" name="phone" placeholder="Optional">
                            </div>
                            
                            <div class="form-group">
                                <label for="postal_code">Postal Code <span class="required">*</span></label>
                                <input type="text" id="postal_code" name="postal_code" required>
                            </div>
                        </div>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label for="city">City <span class="required">*</span></label>
                                <input type="text" id="city" name="city" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="country">Country <span class="required">*</span></label>
                                <input type="text" id="country" name="country" required value="Pakistan">
                            </div>
                        </div>
                    </fieldset>
                    
                    <fieldset>
                        <legend>👨‍👩‍👦 Family Information</legend>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label for="father_name">Father's Name <span class="required">*</span></label>
                                <input type="text" id="father_name" name="father_name" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="father_cnic">Father's CNIC <span class="required">*</span></label>
                                <input type="text" id="father_cnic" name="father_cnic" required pattern="[0-9]{5}-[0-9]{7}-[0-9]{1}" placeholder="12345-1234567-1">
                            </div>
                        </div>
                    </fieldset>
                    
                    <fieldset>
                        <legend>🩸 Blood Group</legend>
                        
                        <div class="form-group">
                            <label for="blood_group">Select Blood Group <span class="required">*</span></label>
                            <select id="blood_group" name="blood_group" required>
                                <option value="">Select Blood Group</option>
                                <option value="A+">A+</option>
                                <option value="A-">A-</option>
                                <option value="B+">B+</option>
                                <option value="B-">B-</option>
                                <option value="AB+">AB+</option>
                                <option value="AB-">AB-</option>
                                <option value="O+">O+</option>
                                <option value="O-">O-</option>
                            </select>
                        </div>
                    </fieldset>
                    
                    <div class="form-actions">
                        <button type="submit" class="btn-primary">Sign Up</button>
                        <button type="reset" class="btn-secondary">Reset Form</button>
                    </div>
                </form>
                
                <div class="auth-links">
                    <p>Already have an account? <a href="login.php?type=<?php echo $userType; ?>">Login</a></p>
                    <p><a href="portal.html">Back to Portal Selection</a></p>
                </div>
            <?php endif; ?>
        </main>
        
        <footer>
            <p>&copy; 2023 EduBridge - A Smart Classroom Management System</p>
        </footer>
    </div>
    
    <script>
        // Show/hide department other field based on selection
        document.getElementById('department').addEventListener('change', function() {
            const departmentOtherContainer = document.querySelector('.department-other-container');
            if (this.value === 'Other') {
                departmentOtherContainer.style.display = 'block';
                document.getElementById('department_other').setAttribute('required', 'required');
            } else {
                departmentOtherContainer.style.display = 'none';
                document.getElementById('department_other').removeAttribute('required');
            }
        });
    </script>
    <script src="js/main.js"></script>
</body>
</html>
